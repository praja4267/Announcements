//
//  googleSignInDataModal.h
//  
//
//  Created by ActiveMac03 on 07/12/15.
//
//

#import <Foundation/Foundation.h>

@interface googleSignInDataModal : NSObject

@end
