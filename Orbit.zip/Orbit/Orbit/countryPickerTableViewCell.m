//
//  countryPickerTableViewCell.m
//  
//
//  Created by ActiveMac03 on 29/12/15.
//
//

#import "countryPickerTableViewCell.h"

@implementation countryPickerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
