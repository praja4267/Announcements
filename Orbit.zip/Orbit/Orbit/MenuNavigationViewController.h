//
//  MenuNavigationViewController.h
//  
//
//  Created by ActiveMac03 on 17/12/15.
//
//

#import <UIKit/UIKit.h>

#import "REFrostedViewController.h"

@interface MenuNavigationViewController : UINavigationController

- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender;
@end
