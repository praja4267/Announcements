//
//  googleSignInDataModal.h
//  
//
//  Created by ActiveMac03 on 07/12/15.
//
//

#import <Foundation/Foundation.h>

@interface googleSignInDataModal : NSObject

@property (nonatomic,strong) NSString *userID;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *userEmail;

@end
