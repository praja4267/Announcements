//
//  MenuListTableViewCell.m
//  Orbit
//
//  Created by Active Mac05 on 16/06/16.
//  Copyright © 2016 techActive. All rights reserved.
//

#import "MenuListTableViewCell.h"

@implementation MenuListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
