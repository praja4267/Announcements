//
//  notificationViewController.h
//  
//
//  Created by ActiveMac03 on 21/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface notificationViewController : UIViewController <CustomIOSAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

@property (weak, nonatomic) IBOutlet UITableView *notificationTableView;
- (IBAction)menuBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *noNotificationsView;

@end
