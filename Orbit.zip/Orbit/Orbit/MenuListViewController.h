//
//  MenuListViewController.h
//  
//
//  Created by Active Mac06 on 04/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface MenuListViewController : UIViewController <UITableViewDataSource,UITableViewDelegate, CustomIOSAlertViewDelegate>
{
     CustomIOSAlertView *customAlertView;
}

@property (weak, nonatomic) IBOutlet UIView *menuProfileView;
@property (weak, nonatomic) IBOutlet UIImageView *menuProfileIcon;
@property (weak, nonatomic) IBOutlet UILabel *menuProfileNameLbl;

@end
