//
//  CardDeleteViewController.h
//  
//
//  Created by Active Mac06 on 14/01/16.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface CardDeleteViewController : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}



@property (strong, nonatomic) NSString *toDeleteCardName;
@property (strong, nonatomic) NSString *toDeleteCardNumber;
@property (strong, nonatomic) NSString *toDeleteCardIcon;
@property (strong, nonatomic) NSString *toDeleteCardID;
@property (strong, nonatomic) NSString *toDeleteCardExpiryDate;
@property (strong, nonatomic) NSString *toDeleteCardDefault;


- (IBAction)deleteCardDeleteBtn:(id)sender;
- (IBAction)deleteCardBackBtn:(id)sender;
- (IBAction)deleteCardDefaultBtn:(id)sender;

@property (strong, nonatomic) IBOutlet UILabel *expiryDateLabel;
@property (strong, nonatomic) IBOutlet UIButton *deleteCardDefaultBtn;

@property (strong, nonatomic) IBOutlet UILabel *deletCardNumberLbl;
@property (strong, nonatomic) IBOutlet UIImageView *deleteCardIconImg;
@property (strong, nonatomic) IBOutlet UILabel *deleteCardNameLbl;
@property (strong, nonatomic) IBOutlet UIView *line1;
@property (strong, nonatomic) IBOutlet UIView *line2;
@property (strong, nonatomic) IBOutlet UIView *line3;
@property (strong, nonatomic) IBOutlet UILabel *expiryStaticLabel;
@end
