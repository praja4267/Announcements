//
//  MenuCardViewController.h
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface MenuCardViewController : UIViewController<CustomIOSAlertViewDelegate>{
    CustomIOSAlertView *customAlertView;
}
@property (weak, nonatomic) IBOutlet UITableView *menuCardTableView;
@property (weak, nonatomic) IBOutlet UIView *menuCardEmptyView;

@end
