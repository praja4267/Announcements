//
//  loyalityViewController.m
//  
//
//  Created by ActiveMac03 on 24/12/15.
//
//

#import "loyalityViewController.h"
#import "loyalityTableViewCell.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "REFrostedViewController.h"

@interface loyalityViewController (){
    NSString *loyaltyCount;
    NSMutableArray *arrTag1,*arrTag2,*arrTag3,*arrTag4,*arrTag5,*arrTag6,*arrType;
    BOOL isLoyaltyEmpty;
}
@end

@implementation loyalityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    arrTag1=[[NSMutableArray alloc]init];
    arrTag2=[[NSMutableArray alloc]init];
    arrTag3=[[NSMutableArray alloc]init];
    arrTag4=[[NSMutableArray alloc]init];
    arrTag5=[[NSMutableArray alloc]init];
    arrTag6=[[NSMutableArray alloc]init];
    arrType=[[NSMutableArray alloc]init];
    
     _loyalityTableView.tableFooterView = [UIView new];
    
    [self getLoyaltyData];
    
    _loyalityEmptyView.hidden=YES;
    _loyalityTableView.hidden=YES;
    isLoyaltyEmpty=NO;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
      
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([arrTag1 count]==0) {
        return 1;
    }
    return arrTag1.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
    loyalityTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"loyaltyCell" forIndexPath:indexPath];
    
    if (cell == nil) {
        cell=[[loyalityTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"loyaltyCell"];
    }
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if ([arrTag1 count]>0) {
        _loyalityEmptyView.hidden=YES;
        _loyalityTableView.hidden=NO;
        cell.tag1.text=arrTag1[indexPath.row];
        cell.tag2.text=arrTag2[indexPath.row];
        cell.tag3.text=arrTag3[indexPath.row];
        cell.tag4.text=arrTag4[indexPath.row];
        cell.tag5.text=arrTag5[indexPath.row];
        cell.tag6.text=arrTag6[indexPath.row];
        
        if([arrType[indexPath.row] intValue]==0){
            cell.tag4.textColor=[UIColor colorWithRed:0.075 green:0.431 blue:0 alpha:1];
        }else{
            cell.tag4.textColor=[UIColor colorWithRed:0.843 green:0 blue:0 alpha:1];
        }
    }else{
        if (isLoyaltyEmpty) {
        _loyalityEmptyView.hidden=NO;
        }
        _loyalityTableView.hidden=YES;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 105;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}

#pragma mark - Loyality API

- (void)getLoyaltyData{
    if([APPDELEGATE connected]){
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_LOYALTY withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getLoyaltyData];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response){
                isLoyaltyEmpty=YES;
                if([[response valueForKey:@"success"]boolValue]){
                    _balanceLbl.text=[response valueForKey:@"balance"];
                    loyaltyCount=[response valueForKey:@"count"];
                    NSMutableArray *loyalty=[response valueForKey:@"loyalty"];
                    for(NSMutableDictionary *loyaltyTags in loyalty){
                        [arrTag1 addObject:[loyaltyTags valueForKey:@"tag1"]];
                        [arrTag2 addObject:[loyaltyTags valueForKey:@"tag2"]];
                        [arrTag3 addObject:[loyaltyTags valueForKey:@"tag3"]];
                        [arrTag4 addObject:[loyaltyTags valueForKey:@"tag4"]];
                        [arrTag5 addObject:[loyaltyTags valueForKey:@"tag5"]];
                        [arrTag6 addObject:[loyaltyTags valueForKey:@"tag6"]];
                        [arrType addObject:[loyaltyTags valueForKey:@"type"]];
                    }
            }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
            }
            [_loyalityTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)menuBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}
@end
