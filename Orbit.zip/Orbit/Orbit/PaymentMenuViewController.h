//
//  PaymentMenuViewController.h
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CAPSPageMenu.h"

#import "MenuCardViewController.h"
#import "MenuWalletViewController.h"
#import "addCardViewController.h"
#import "CustomIOSAlertView.h"

@interface PaymentMenuViewController : UIViewController<AddCardViewControllerDelegate, CustomIOSAlertViewDelegate> {
     CustomIOSAlertView *customAlertView;
}
- (IBAction)menuBtn:(id)sender;
- (IBAction)paymentAddNewBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *PaymentAddBtn;

@end
