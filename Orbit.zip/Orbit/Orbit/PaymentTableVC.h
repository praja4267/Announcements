//
//  PaymentTableVC.h
//  
//
//  Created by Active Mac06 on 23/11/15.
//
//

#import <UIKit/UIKit.h>
#import "addCardViewController.h"
#import "CustomIOSAlertView.h"

@interface PaymentTableVC : UIViewController <UITableViewDataSource,UITableViewDelegate, AddCardViewControllerDelegate, CustomIOSAlertViewDelegate> {
    CustomIOSAlertView *customAlertView;
}
- (IBAction)paymentBackBtn:(id)sender;

@end
