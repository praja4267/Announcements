//
//  myRideTableViewCell.h
//  
//
//  Created by ActiveMac03 on 11/12/15.
//
//

#import <UIKit/UIKit.h>

@interface myRideTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *myRideDateLbl;
@property (weak, nonatomic) IBOutlet UILabel *myRideStatusLbl;
@property (weak, nonatomic) IBOutlet UILabel *myRideOriginLbl;
@property (weak, nonatomic) IBOutlet UILabel *myRideDestinationLbl;
@property (weak, nonatomic) IBOutlet UIImageView *myRideOriginIcon;
@property (weak, nonatomic) IBOutlet UIImageView *myRideDestinationIcon;
@property (weak, nonatomic) IBOutlet UILabel *myRideAmountLbl;

@end
