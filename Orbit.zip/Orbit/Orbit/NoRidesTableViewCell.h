//
//  NoRidesTableViewCell.h
//  Lymo
//
//  Created by Active Mac05 on 02/03/16.
//  Copyright © 2016 techactive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoRidesTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *noRidesLabel;

@end
