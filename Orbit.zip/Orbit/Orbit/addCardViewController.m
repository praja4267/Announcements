//
//  addCardViewController.m
//  
//
//  Created by ActiveMac03 on 07/01/16.
//
//

#import "addCardViewController.h"
#import "NTMonthYearPicker.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"

#import "Worldpay.h"
#import "APMController.h"
#import "WorldpayAPMViewController.h"
#import "ThreeDSController.h"
#import "WorldpayCardViewController.h"
#import "Worldpay+ApplePay.h"
#import "AFNetworking.h"


#import "StringEncryption.h"

@interface addCardViewController (){
    NTMonthYearPicker *datePicker;
    UIToolbar *datePickerToolbar;
    NSString *token;
    NSString *selectedMonth;
    NSString *selectedYear;
    NSString *worldPayClientKey;
    NSString *AESKey;
    NSString *paymentType;
    NSInteger selectedTag;
}

@end

@implementation addCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _addCardCVVTxt.delegate=self;
    _addCardMonthTxt.delegate=self;
    _addCardNameTxt.delegate=self;
    _addCardNumberTxt.delegate=self;
    _addCardNameTxt.tag=1;
    _addCardNumberTxt.tag= 2;
    _addCardMonthTxt.tag=3;
    _addCardCVVTxt.tag=4;
    selectedTag=0;
    _addCardCVVTxt.secureTextEntry=YES;
    // Do any additional setup after loading the view.
    [_addCardNumberTxt addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    
    //KeyBoard done button
    UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
    [keyboardDoneButtonView sizeToFit];
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                   style:UIBarButtonItemStylePlain target:self
                                                                  action:@selector(doneClicked:)];
    [doneButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];

    UIBarButtonItem* nextButton = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleDone target:self action:@selector(addCardNextButton)];
    [nextButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];
    
    [keyboardDoneButtonView setItems:[NSArray arrayWithObjects:nextButton, flexibleSpaceLeft,doneButton, nil]];
    _addCardNameTxt.inputAccessoryView=keyboardDoneButtonView;
    _addCardNumberTxt.inputAccessoryView = keyboardDoneButtonView;
    _addCardCVVTxt.inputAccessoryView = keyboardDoneButtonView;
    datePicker= [[NTMonthYearPicker alloc] init];
    
    //Create picker
    
    [self addCardDatePickerView];
    _addCardMonthTxt.inputView=datePicker;
    [datePicker removeFromSuperview];
    [datePickerToolbar removeFromSuperview];
    [_addCardSaveBtn setExclusiveTouch:YES];
    [_addCardBackBtn setExclusiveTouch:YES];
    
    //get worldpay token and aes key
    
    [self getTokenAndAesKey];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
}


-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"AddedCard"]) {
//        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"AddedCard"];
//        [customAlertView setContainerView:[APPDELEGATE createDemoView:[[NSUserDefaults standardUserDefaults] valueForKey:@"AddcardMessage"] view:self.view]];
//        [customAlertView show];
//        
//    }
}
-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Picker

-(void)addCardDatePickerView {
    // Set initial date to last month
    // This is optional; default is current month/year
/*    [comps setDay:0];
    [comps setMonth:-1];
    [comps setYear:0];
    datePicker.date = [cal dateByAddingComponents:comps toDate:[NSDate date] options:0];*/
    
    /*Picker View for date and time*/
//    datePicker =[[NTMonthYearPicker alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-200, self.view.frame.size.width,200)];
     CGSize pickerSize = [datePicker sizeThatFits:CGSizeZero];
    datePicker.frame = CGRectMake( 0, [[UIScreen mainScreen] bounds].size.height - pickerSize.height, pickerSize.width, pickerSize.height);
    datePicker.datePickerMode = NTMonthYearPickerModeMonthAndYear;
    [datePicker setBackgroundColor:[UIColor whiteColor]];
    
    // Set mode to month + year
    // This is optional; default is month + year
    datePicker.datePickerMode = NTMonthYearPickerModeMonthAndYear;
    
    
    NSDate *currentDate = [NSDate date];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comps = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:currentDate];
    
    datePicker.minimumDate = [calendar dateFromComponents:comps];
    
    // Set maximum date to next month
    // This is optional; default is no max date
    [comps setDay:0];
    [comps setMonth:1];
    [comps setYear:2036];
    
    datePicker.maximumDate = [calendar dateByAddingComponents:comps toDate:[NSDate date] options:0];
    
    datePickerToolbar= [[UIToolbar alloc] initWithFrame:CGRectMake(0,self.view.frame.size.height-(pickerSize.height+44),self.view.frame.size.width,44)];
    [datePickerToolbar setBackgroundColor:[UIColor whiteColor]];
    datePickerToolbar.barStyle = UIBarStyleDefault;
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem* doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(addCardpickerDone)];
    UIBarButtonItem* cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(addCardpickerCancel)];
        UIBarButtonItem* nextButton = [[UIBarButtonItem alloc] initWithTitle:@"Next" style:UIBarButtonItemStyleDone target:self action:@selector(addCardNextButton)];
        [nextButton setTitleTextAttributes:
         [NSDictionary dictionaryWithObjectsAndKeys:
          [UIColor blackColor], NSForegroundColorAttributeName,nil]
                                  forState:UIControlStateNormal];
    [doneButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];
    [cancelButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                                forState:UIControlStateNormal];
    
    [datePickerToolbar setItems:[NSArray arrayWithObjects:nextButton, flexibleSpaceLeft, doneButton, nil]];
    datePickerToolbar.userInteractionEnabled = true;
    _addCardMonthTxt.inputAccessoryView=datePickerToolbar;
    
    [self.tpScrlView addSubview:datePickerToolbar];
    [self.tpScrlView addSubview:datePicker];
    
}

-(void)addCardpickerDone {
    [_addCardMonthTxt resignFirstResponder];
}


-(void)addCardpickerCancel {
    [datePicker removeFromSuperview];
    [datePickerToolbar removeFromSuperview];
    [_addCardMonthTxt resignFirstResponder];
}

-(void)addCardNextButton {
    switch (selectedTag) {
        case 1:
            [_addCardNumberTxt becomeFirstResponder];
            break;
        case 2:
            [_addCardMonthTxt becomeFirstResponder];
            break;
        case 3:
            [self addCardpickerDone];
            [_addCardCVVTxt becomeFirstResponder];
            break;
        default:
            [_addCardNameTxt becomeFirstResponder];
            break;
    }
}

#pragma mark - Button Actions

- (IBAction)addCardBackBtn:(id)sender {
    [self.view endEditing:YES];
    [datePicker removeFromSuperview];
    [datePickerToolbar removeFromSuperview];
    if (self.navigationController) {
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (IBAction)addCardSaveBtn:(id)sender {
    [self.view endEditing:YES];
    [datePicker removeFromSuperview];
    [datePickerToolbar removeFromSuperview];
    if([APPDELEGATE connected])  {
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        if(_addCardNameTxt.text.length<1 || _addCardNumberTxt.text.length<14 || _addCardMonthTxt.text.length<1 || _addCardCVVTxt.text.length<1 || selectedMonth == nil || selectedYear ==nil){
            if(_addCardNameTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_CARD_NAME view:self.view]];
                [customAlertView show];
            }
            else if(_addCardNumberTxt.text.length<14)
            {
                if (_addCardNumberTxt.text.length<1) {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_CARD_NUMBER view:self.view]];
                    [customAlertView show];
                }else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_CARD_NUMBER view:self.view]];
                    [customAlertView show];
                }
            } else if(_addCardMonthTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_MONTH_YEAR view:self.view]];
                [customAlertView show];
            } else if(_addCardCVVTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_CVV view:self.view]];
                [customAlertView show];
            }else if (selectedYear == nil || selectedMonth == nil){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_MONTH_YEAR view:self.view]];
                [customAlertView show];
            }
            [APPDELEGATE stopLoader:self.view];
        }else{
            if ([paymentType  isEqual: @"worldpay"]) {
                [self saveCardUsingWorldPay];
            } else {
                [self saveCardUsingTelr];
            }
        }
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


-(void)saveCardUsingTelr {
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
    [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
    [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
    
    [dictParam setValue:[self encryptStringUsingAES256:_addCardNumberTxt.text] forKey:PARAM_CARD_NUMBER];
    //[dictParam setValue:[self removeWhitespacesinString:_addCardNumberTxt.text] forKey:PARAM_CARD_NUMBER];
    [dictParam setValue:[self encryptStringUsingAES256:_addCardMonthTxt.text] forKey:PARAM_VALIDITY];
    [dictParam setValue:[self encryptStringUsingAES256:_addCardCVVTxt.text] forKey:PARAM_CVV];
    [dictParam setValue:[self encryptStringUsingAES256:_addCardNameTxt.text] forKey:PARAM_CARD_NAME];
    ALog(@"the save card data is %@", dictParam);
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:FILE_STORE_CARD withParamData:dictParam withBlock:^(id response, NSError *error)
     {
         ALog(@"Card Response ---> %@",response);
         if (response == Nil){
             [APPDELEGATE stopLoader:self.view];
             if (error.code == -1005 ) {
                 [self saveCardUsingTelr];
                 ALog(@"network error so call destiantion change again again");
             }else {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                 });
//                 [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                [customAlertView show];
             }
         }else if (response)
         {
             if([[response valueForKey:@"success"]boolValue])
             {
                 [APPDELEGATE stopLoader:self.view];
                 if([_strForCurrentPage isEqualToString:@"login"]){
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [self performSegueWithIdentifier:STRING_SEGUE_ADD_CARD_TO_GET_STARTED sender:self];
                     });
                     
                 }else{
                     [[NSNotificationCenter defaultCenter]postNotificationName:@"CardDetails" object:nil];
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [self.navigationController popViewControllerAnimated:YES];
                     });
                     
                 }
             }
             else{
                 [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                 [customAlertView show];
             }
              [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
         }
         [APPDELEGATE stopLoader:self.view];
     }];
}

-(void)saveCardUsingWorldPay {
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    [[Worldpay sharedInstance] createTokenWithNameOnCard:_addCardNameTxt.text cardNumber:_addCardNumberTxt.text  expirationMonth:selectedMonth expirationYear:selectedYear CVC:_addCardCVVTxt.text success:^(int code, NSDictionary *responseDictionary) {
        ALog(@"the response dictionary from world paty is %@", responseDictionary);
        token = [responseDictionary valueForKey:@"token"];
        NSDictionary *newDict = [responseDictionary valueForKey:@"paymentMethod"];
//        NSString *str=[NSString stringWithFormat:@"json data is %@", responseDictionary];
       NSString *urlString = [NSString stringWithFormat:@"%@%@", API_URL, FILE_WORLDPAY_STORE_CARD];
//        @"http://taxi.active.agency/user/wp_store_card?";
        /*
         NSString *body = [NSString stringWithFormat: @"cardClass=%@&cardIssuer=%@&cardProductTypeDescContactless=%@&cardProductTypeDescNonContactless=%@&cardSchemeName=%@&cardSchemeType=%@&cardType=%@&countryCode=%@&expiryMonth=%@&expiryYear=%@&card_number=%@&card_name=%@&prepaid=%@&card_type=%@&reusable=%@&card_token=%@&lymo_device_id=%@&id=%@&token=%@",
         
         [newDict valueForKey:@"cardClass"],
         [newDict valueForKey:@"cardIssuer"],
         [newDict valueForKey:@"cardProductTypeDescContactless"],
         [newDict valueForKey:@"cardProductTypeDescNonContactless"],
         [newDict valueForKey:@"cardSchemeName"],
         [newDict valueForKey:@"cardSchemeType"],
         [newDict valueForKey:@"cardType"],
         [newDict valueForKey:@"countryCode"],
         [newDict valueForKey:@"expiryMonth"],
         [newDict valueForKey:@"expiryYear"],
         [newDict valueForKey:@"maskedCardNumber"],
         [newDict valueForKey:@"name"],
         [newDict valueForKey:@"prepaid"],
         [newDict valueForKey:@"type"] ,
         [responseDictionary valueForKey:@"reusable"],
         [responseDictionary valueForKey:@"token"],
         [pref objectForKey:PREF_LYMO_DEVICE_ID],
         [pref objectForKey:PREF_USER_ID],
         [pref objectForKey:PREF_USER_TOKEN]];
         */
        /* AES ENCrypted data ***********************  */
        
        NSString *body = [NSString stringWithFormat: @"token=%@&id=%@&lymo_device_id=%@&card_token=%@&card_name=%@&card_type=%@&card_number=%@&countryCode=%@&expiryMonth=%@&expiryYear=%@",
                          [pref objectForKey:PREF_USER_TOKEN],
                          [pref objectForKey:PREF_USER_ID],
                          [pref objectForKey:PREF_LYMO_DEVICE_ID],
                          [self encryptStringUsingAES256AndURLEncode:[responseDictionary valueForKey:@"token"]],
                          [self encryptStringUsingAES256AndURLEncode:[newDict valueForKey:@"name"]],
                          [self encryptStringUsingAES256AndURLEncode:[newDict valueForKey:@"cardType"]],
                          [self encryptStringUsingAES256AndURLEncode:[newDict valueForKey:@"maskedCardNumber"]],
                          [self encryptStringUsingAES256AndURLEncode:[newDict valueForKey:@"countryCode"]],
                          [self encryptStringUsingAES256AndURLEncode:[[newDict valueForKey:@"expiryMonth"] stringValue]],
                          [self encryptStringUsingAES256AndURLEncode:[[newDict valueForKey:@"expiryYear"] stringValue]]];
        ALog(@"webViewUrl is = %@", urlString);
        ALog(@"the encrypted string is %@", body);
        WebViewController *cntl = [[WebViewController alloc] initWithNibName:@"WebViewController" bundle:nil];
        cntl.url = urlString;
        cntl.bodydata = body;
        cntl.webViewCntlDelegate=self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [APPDELEGATE stopLoader:self.view];
            if ([self navigationController]) {
                [self.navigationController pushViewController:cntl animated:YES];
            }else {
                UINavigationController *navcntl = [[UINavigationController alloc] initWithRootViewController:cntl];
                navcntl.navigationBarHidden=YES;
                [self presentViewController:navcntl animated:NO completion:nil];
            }
        });
        
        
        //        [self presentViewController:cntl animated:YES completion:nil];
    } failure:^(NSDictionary *responseDictionary, NSArray *errors) {
        [APPDELEGATE stopLoader:self.view];
        if (errors.count) {
            ALog(@"the error is %@",errors);
            NSString * errorMessage=@"";
            if ([responseDictionary valueForKey:@"message"]) {
                errorMessage=[responseDictionary valueForKey:@"message"];
            }else{
                errorMessage = [errors.firstObject localizedDescription];
            }
            [customAlertView setContainerView:[APPDELEGATE createDemoView:errorMessage view:self.view]];
            [customAlertView show];
            
        }else{
            ALog(@"no errors");
        }
        [APPDELEGATE stopLoader:self.view];
        return ;
    }];
}

- (IBAction)doneClicked:(id)sender
{
    [self.view endEditing:YES];
}

-(void)getTokenAndAesKey{
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
    [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
    [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    
    [afn getDataFromPath:FILE_WORLD_PAY_AES_KEY withParamData:dictParam withBlock:^(id response, NSError *error)
     {
         ALog(@"Card Response ---> %@",response);
         if (response == Nil){
             [APPDELEGATE stopLoader:self.view];
             if (error.code == -1005 ) {
                 [self getTokenAndAesKey];
                 ALog(@"network error so call destiantion change again again");
             }else {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                 });
//                 [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                 [customAlertView show];
             }
         }else if (response)
         {
             if([[response valueForKey:@"success"]boolValue])
             {
                 [APPDELEGATE stopLoader:self.view];
                 AESKey = [response valueForKey:@"aes_key"];
                 paymentType = [response valueForKey:@"payment_type"];
                 if ([paymentType  isEqual: @"worldpay"]) {
                     worldPayClientKey = [response valueForKey:@"worldpay_client_key"];
                     //WORLD PAY ADD CARD AND GET token
                     ALog(@"worldpay client key = %@", worldPayClientKey);
                     [ [Worldpay sharedInstance] setClientKey: worldPayClientKey];
                     
                     // decide whether you want to charge this card multiple times or only once
                     [ [Worldpay sharedInstance] setReusable:YES ];
                     
                     // set validation type advanced (WorldpayValidationTypeAdvanced) orbasic(WorldpayValidationTypeBasic).
                     // Basic validation just checks that is a numeric value and not empty. Advanced checks thatis a valid card number.
                     
                     [ [Worldpay sharedInstance] setValidationType:WorldpayValidationTypeAdvanced ];
                 }
             } else{
                 [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                 [customAlertView show];
             }
             
         }
     }];
}

#pragma mark - TextView Delegate


- (void)textFieldDidChange:(id)sender {
    
//    NSString *cc_num_string = ((UITextField*)sender).text;
//    int cc_length = [cc_num_string length];
//
//    if (cc_length >= 1 && [cc_num_string characterAtIndex:0] == '4') {
//
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKVisa.png"];
//    }
//    else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '5' && ([cc_num_string characterAtIndex:1] == '1' || [cc_num_string characterAtIndex:1] == '2' || [cc_num_string characterAtIndex:1] == '3' || [cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '5')) {
//        
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKMastercard.png"];
//    }
//    else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '6' && ([cc_num_string characterAtIndex:1] == '5' || (cc_length > 2 &&cc_length > 1 && [cc_num_string characterAtIndex:1] == '4' && [cc_num_string characterAtIndex:2] == '4') || (cc_length > 3 && [cc_num_string characterAtIndex:1] == '0' && [cc_num_string characterAtIndex:2] == '1' && [cc_num_string characterAtIndex:3] == '1' ))) {
//        
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKDiscover.png"];
//    }
//    else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '3' && ([cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '7')) {
//        
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKAmex.png"];
//    }
//    else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '5' && ([cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '5')) {
//        
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKDinersClub.png"];
//    }
//    else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '3' && ([cc_num_string characterAtIndex:1] == '5')) {
//        
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKJCB.png"];
//    }
//    else {
//        _addCardImageIcon.image = [UIImage imageNamed:@"VDKGenericCard.png"];
//    }
}


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    selectedTag=textField.tag;
    if(textField == _addCardMonthTxt){
        datePicker.hidden=NO;
        datePickerToolbar.hidden=NO;
    }else {
        [datePicker removeFromSuperview];
        [datePickerToolbar removeFromSuperview];
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == _addCardNameTxt) {
        [_addCardNumberTxt becomeFirstResponder];
    }else {
        [self.view endEditing:YES];
    }
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [textField layoutIfNeeded]; //Fixes iOS 9 text bounce glitch
    if(textField == _addCardMonthTxt){
        datePicker.hidden=YES;
        datePickerToolbar.hidden=YES;
//        [datePicker removeFromSuperview];
//        [datePickerToolbar removeFromSuperview];
        
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        
        if( datePicker.datePickerMode == NTMonthYearPickerModeMonthAndYear ) {
            [df setDateFormat:@"MM/yyyy"];
        } else {
            [df setDateFormat:@"yyyy"];
        }
        
        NSString *dateStr = [df stringFromDate:datePicker.date];
        NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear fromDate:datePicker.date];
        
        NSInteger month = [components month];
        selectedMonth = [NSString stringWithFormat:@"%ld", (long)month];
        NSInteger year = [components year];
        selectedYear = [NSString stringWithFormat:@"%ld", (long)year];
        
        ALog(@"%@",[NSString stringWithFormat:@"Selected: %@", dateStr]);
        _addCardMonthTxt.text=dateStr;
        ALog(@"selected date = %@, selected month = %@ and year = %@ ", _addCardMonthTxt.text, selectedMonth, selectedYear);
        [datePicker setDate:datePicker.date];
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (range.location == 0 && [string isEqualToString:@" "]) {
        return NO;
    }
    
    if(textField==_addCardCVVTxt){
    NSString *newString = [_addCardCVVTxt.text stringByReplacingCharactersInRange:range withString:string];
        return ([newString length] < 5);
    }else if (textField==_addCardNumberTxt){
        
        if (_addCardNumberTxt.text.length>2) {
            
            NSString *cc_num_string = textField.text;
            int cc_length = [cc_num_string length];
            
            if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '4') {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKVisa.png"];
            }
            else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '5' && ([cc_num_string characterAtIndex:1] == '1' || [cc_num_string characterAtIndex:1] == '2' || [cc_num_string characterAtIndex:1] == '3' || [cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '5')) {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKMastercard.png"];
            }
            else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '6' && ([cc_num_string characterAtIndex:1] == '5' || (cc_length > 2 &&cc_length > 1 && [cc_num_string characterAtIndex:1] == '4' && [cc_num_string characterAtIndex:2] == '4') || (cc_length > 3 && [cc_num_string characterAtIndex:1] == '0' && [cc_num_string characterAtIndex:2] == '1' && [cc_num_string characterAtIndex:3] == '1' ))) {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKDiscover.png"];
            }
            else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '3' && ([cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '7')) {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKAmex.png"];
            }
            else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '5' && ([cc_num_string characterAtIndex:1] == '4' || [cc_num_string characterAtIndex:1] == '5')) {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKDinersClub.png"];
            }
            else if (cc_length > 1 && [cc_num_string characterAtIndex:0] == '3' && ([cc_num_string characterAtIndex:1] == '5')) {
                
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKJCB.png"];
            }
            else {
                _addCardImageIcon.image = [UIImage imageNamed:@"VDKGenericCard.png"];
            }
        } else {
            _addCardImageIcon.image = [UIImage imageNamed:@"VDKGenericCard.png"];
            return YES;
        }
        __block NSString *text = [textField text];
        
        textField.font=[UIFont fontWithName:@"Dinpro-Regular" size:18.0];
        
        NSCharacterSet *characterSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789\b"];
        string = [string stringByReplacingOccurrencesOfString:@" " withString:@""];
        if ([string rangeOfCharacterFromSet:[characterSet invertedSet]].location != NSNotFound) {
            return NO;
        }
        
        text = [text stringByReplacingCharactersInRange:range withString:string];
        text = [text stringByReplacingOccurrencesOfString:@" " withString:@""];
        
        NSString *newString = @"";
        while (text.length > 0) {
            NSString *subString = [text substringToIndex:MIN(text.length, 4)];
            newString = [newString stringByAppendingString:subString];
            if (subString.length == 4) {
                newString = [newString stringByAppendingString:@" "];
            }
            text = [text substringFromIndex:MIN(text.length, 4)];
        }
        
        newString = [newString stringByTrimmingCharactersInSet:[characterSet invertedSet]];
        
        if (newString.length >= 24) {
            return NO;
        }
        
        [textField setText:newString];
        
        return NO;
    }
    else{
        return YES;
    }
}


- (NSString *)removeWhitespacesinString : (NSString *)targetString {
    return [[targetString componentsSeparatedByCharactersInSet:
             [NSCharacterSet whitespaceCharacterSet]]
            componentsJoinedByString:@""];
}


//-->     a22!@#$s8523key!a22bytes8523key!

-(NSString*)encryptStringUsingAES256 :(NSString*)actualString
{
//    ALog(@"before encrypted-- %@",actualString);
    NSString *key = AESKey ;    //@"a22!@#$s8523key!a22bytes8523key!";
    NSString *ensryptedString=[StringEncryption encWithString:actualString key:key];
//    ALog(@"after encrypted-- %@",ensryptedString);
    return ensryptedString;
  /*  NSString *key = @"a22!@#$s8523key!a22bytes8523key!";
    
    NSString *siva=[StringEncryption encWithString:@"4242424242424242" key:key];
    
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setValue:siva forKey:@"name"];
    ALog(@"prathima-- %@",siva);
    
    
     AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
     [afn getDataFromPath:@"aes_android" withParamData:dictParam withBlock:^(id response, NSError *error){
     if (response == Nil){
     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
     [customAlertView show];
     }else if (response){
     
     }
     }];
     */
}

-(NSString*)encryptStringUsingAES256AndURLEncode :(NSString*)actualString
{
//    ALog(@"before encrypted-- %@",actualString);
    NSString *key = AESKey ;    //@"a22!@#$s8523key!a22bytes8523key!";
    NSString *ensryptedString=[StringEncryption encWithString:actualString key:key];
//    ALog(@"after encrypted-- %@",ensryptedString);
    
    NSString *charactersToEscape = @"!*'();:@&=+$,/?%#[]\" ";
    NSCharacterSet *allowedCharacters = [[NSCharacterSet characterSetWithCharactersInString:charactersToEscape] invertedSet];
    
    NSString *encodedString = [ensryptedString stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacters];
    
    return encodedString;
}

#pragma mark - WebViewController delegate method

-(void) cardAddedInWebView:(UIViewController *)sender withString:(NSString *)message AndWithStatus:(BOOL)status
{
    if ([_addcardDelegate respondsToSelector:@selector(cardAddedFromWebViewWithMessage:)]) {
        ALog(@"addcard protocol delegate is working");
        if (status) {
            [self.navigationController popViewControllerAnimated:NO];
            [_addcardDelegate cardAddedFromWebViewWithMessage:message];
        }else{
            [customAlertView setContainerView:[APPDELEGATE createDemoView:message view:self.view]];
            [customAlertView show];
        }

    } else if (_isFromOutStanding){
        [self.navigationController popViewControllerAnimated:NO];
        if ([_addcardDelegate respondsToSelector:@selector(cardAddedFromWebViewWithMessage:)]) {
            [_addcardDelegate cardAddedFromWebViewWithMessage:message];
        }
        
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
