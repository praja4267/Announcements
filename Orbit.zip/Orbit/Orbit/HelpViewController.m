//
//  HelpViewController.m
//  
//
//  Created by ActiveMac03 on 18/12/15.
//
//

#import "HelpViewController.h"
#import "REFrostedViewController.h"
#import "myRideTableViewCell.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "HelpTripDetailVC.h"

@interface HelpViewController (){
    NSMutableArray *helpRideDateArray,*helpRideStatusArray,*helpRideStatusIDArray,*helpRideOriginArray,*helpRideDestinationArray,*helpRideTypeID,*helpRideAmount;
    NSString *helpRideRequestID;
    BOOL isFirst;
}
@end

@implementation HelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    helpRideDateArray=[[NSMutableArray alloc]init];
    helpRideStatusArray=[[NSMutableArray alloc]init];
    helpRideStatusIDArray=[[NSMutableArray alloc]init];
    helpRideOriginArray=[[NSMutableArray alloc]init];
    helpRideDestinationArray=[[NSMutableArray alloc]init];
    helpRideTypeID=[[NSMutableArray alloc]init];
    helpRideAmount=[[NSMutableArray alloc]init];
    [self getMyHelpRideData];
    _helpTableView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    // Do any additional setup after loading the view.
    
    _helpEmptyView.hidden=YES;
    _helpTableView.hidden=YES;
    isFirst=YES;
    [_helpFAQBtn setExclusiveTouch:YES];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getMyHelpRideData{
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:@"3" forKey:PARAM_TYPE];
         [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_HISTORY withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getMyHelpRideData];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
//                [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                [customAlertView show];
                }
            }else if (response){
                isFirst=NO;
                if([[response valueForKey:@"success"]boolValue]){
                    NSMutableArray *requestDetails=[response valueForKey:@"requests"];
                    if(requestDetails.count>0){
                        for(NSMutableDictionary *places in requestDetails){
                            [helpRideStatusIDArray addObject:[places objectForKey:@"id"]];
                            [helpRideTypeID addObject:[places objectForKey:@"type_id"]];
                            [helpRideStatusArray addObject:[places objectForKey:@"status"]];
                            [helpRideOriginArray addObject:[places objectForKey:@"source_address"]];
                            [helpRideDestinationArray addObject:[places objectForKey:@"destination_address"]];
                            [helpRideDateArray addObject:[places objectForKey:@"date"]];
                            [helpRideAmount addObject:[places objectForKey:@"total"]];
                        }
                    }
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
            }
            [_helpTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (helpRideStatusIDArray.count==0) {
        return 1;
    }
    return helpRideStatusIDArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"myRideTableViewCell";
    
    myRideTableViewCell *cell = (myRideTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        [tableView registerNib:[UINib nibWithNibName:@"myRideTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(myRideTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
    
    if(helpRideStatusIDArray.count>0){
        _helpEmptyView.hidden=YES;
        _helpTableView.hidden=NO;
        cell.myRideDestinationLbl.hidden=NO;
        cell.myRideOriginLbl.hidden=NO;
        cell.myRideDateLbl.hidden=NO;
        cell.myRideStatusLbl.hidden=NO;
        cell.myRideOriginIcon.hidden=NO;
        cell.myRideDestinationIcon.hidden=NO;
        cell.myRideAmountLbl.hidden=NO;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        
        cell.myRideDateLbl.text=[NSString stringWithFormat:@"%@  -",helpRideDateArray[indexPath.row]];
        cell.myRideStatusLbl.text=helpRideStatusArray[indexPath.row];
        cell.myRideOriginLbl.text=helpRideOriginArray[indexPath.row];
        cell.myRideDestinationLbl.text=helpRideDestinationArray[indexPath.row];
        ALog(@"HelpView controller currency symbol = %@", [pref objectForKey:PREF_SETTING_CURRENCY_TEXT]);
         cell.myRideAmountLbl.text=[NSString stringWithFormat:@"%@ %@",[pref objectForKey:PREF_SETTING_CURRENCY_TEXT],helpRideAmount[indexPath.row]];
        if([helpRideTypeID[indexPath.row]isEqualToString:@"2"]){
            cell.myRideStatusLbl.textColor= [UIColor colorWithRed:1 green:0.749 blue:0 alpha:1];
        }else if ([helpRideTypeID[indexPath.row]isEqualToString:@"4"]){
            cell.myRideStatusLbl.textColor= [UIColor colorWithRed:1 green:0.02 blue:0.02 alpha:1];
        }else if ([helpRideTypeID[indexPath.row]isEqualToString:@"5"]){
            cell.myRideStatusLbl.textColor= [UIColor colorWithRed:0 green:0.071 blue:1 alpha:1];
        }else{
            cell.myRideStatusLbl.textColor= [UIColor blackColor];
        }
    }else{
        if(!isFirst){
        _helpEmptyView.hidden=NO;
        }
        _helpTableView.hidden=YES;
        cell.myRideDestinationLbl.hidden=YES;
        cell.myRideOriginLbl.hidden=YES;
        cell.myRideDateLbl.hidden=YES;
        cell.myRideStatusLbl.hidden=YES;
        cell.myRideOriginIcon.hidden=YES;
        cell.myRideDestinationIcon.hidden=YES;
        cell.myRideAmountLbl.hidden=YES;
    }
   
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return 120;
    return 143;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([APPDELEGATE connected]) {
        if([helpRideTypeID[indexPath.row]isEqualToString:@"2"]){
            ALog(@"siva");
        }else{
            //ALog(@"%@",helpRideStatusIDArray[indexPath.row]);
            helpRideRequestID=helpRideStatusIDArray[indexPath.row];
            [self performSegueWithIdentifier:STRING_SEGUE_HELP_TRIP_DETAIL sender:self];
        }
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Segue Action

//In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_HELP_TRIP_DETAIL]) {
        HelpTripDetailVC *rideDetailsactivity = (HelpTripDetailVC *)segue.destinationViewController;
        rideDetailsactivity.request_id=helpRideRequestID;
        rideDetailsactivity.strForCurrentPage=@"helpList";
    }
}


#pragma mark - Button actions

- (IBAction)helpMenuBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}

- (IBAction)helpFAQBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    
    if ([APPDELEGATE connected]) {
        [self performSegueWithIdentifier:STRING_SEGUE_FAQ sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
    
}
#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
