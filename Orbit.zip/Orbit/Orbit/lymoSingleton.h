//
//  lymoSingleton.h
//  
//
//  Created by ActiveMac03 on 14/11/15.
//
//

#import <Foundation/Foundation.h>

@interface lymoSingleton : NSObject

+(lymoSingleton*)sharedInstance;
- (void) reset;

@property(nonatomic,strong) NSMutableDictionary *globaldictionary;

@property (nonatomic,strong) NSMutableArray *arrCarDetails;
@property (nonatomic,strong) NSMutableArray *arrCarCatID;
@property (nonatomic,strong) NSMutableArray *arrCarTypeCount;
@property (nonatomic,strong) NSMutableArray *arrCarTypeDetails;
@property (nonatomic,strong) NSString *arrivalTime;

@end
