//
//  currentRideViewController.m
//
//
//  Created by ActiveMac03 on 05/01/16.
//
//

#import "currentRideViewController.h"
//#import <GoogleMapsM4B/GoogleMaps.h>

#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"
#import "CancelTableViewCell.h"
#import "UIImageView+Download.h"
#import "RideCompleteVC.h"
#import "SearchViewController.h"
#import <GoogleMaps/GoogleMaps.h>
#import "OutStandingPaymentsViewController.h"
#import "RideCancelledPaymentViewController.h"
#import "UIImage+ResizeTheImage.h"
#import "TPKeyboardAvoidingScrollView.h"
static dispatch_once_t onceToken;

@interface currentRideViewController ()<GMSMapViewDelegate, rideCompleteVCDelegate, RideCancelledPaymentViewControllerDelegate, UITextViewDelegate>{
    GMSMapView *mapView_;
    NSMutableArray *cancelReasonID,*cancelReasonText,*arrPath;
    GMSMutablePath *pathpoliline,*pathUpdates;
    GMSMarker *client_marker,*driver_marker,*markerOwnerDest,*markerOwner;
    CLLocationManager *locationManager;
    NSUserDefaults *pref;
    NSString *strForCurLatitude,*strForCurLongitude,*strForWalkerPhone,*strForSourceAddress,*strForDestinationAddress,*strForDesLatitude,*strForDesLongitude, *strForLatitude, *strForLongitude, *strForLatLongID, *currentDestinationAddress;
    
    NSTimer *timerForCheckReqStatus;
    
    //String for Cancel ride
    NSString *strForCancelReasonID,*strForCancelReasonText;
    
    //String for Ride complete
    NSString *rideCompleteTripID,*rideCompleteCarCatorgery,*rideCompleteDate,*rideCompleteTime,*rideCompletePayment,*rideCompletePrice,*rideCompleteMessage,*rideCompleteDriveIcon,*rideCompleteDriverName,*rideCompleteDriverCarCategory,*rideCompleteDriverCarNumber, *rideCompleteRequestId;
    
    NSMutableDictionary *dictWalker,*resp;
    NSString *enableLocationAccessMessage;
    BOOL isResponse, timerIsStopped, isLater;
    UIView* clearViewOnGoogleButton;
    NSIndexPath *cancelTVCellSelectedIndexpath;
    float animationTime, getRequestCallTime;
    double zoom;
    UIImage* driverCarIcon;
    SearchViewController *searchController;
    BOOL checkForDestinationServiceAvailability;
    TPKeyboardAvoidingScrollView *scrlview;
    UIView *moreBigView, *tempViewForScrlView;
    UITextView *commentTextView;
}

@end

@implementation currentRideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    strForLatLongID = @"0";
    timerIsStopped=NO;
    checkForDestinationServiceAvailability=NO;
    _lymoArrivingLbl.text=@"";
    animationTime=0.2;
    if ([[pref valueForKey:PREF_SETTING_GET_REQUEST_TIMER] floatValue]) {
        getRequestCallTime = [[pref valueForKey:PREF_SETTING_GET_REQUEST_TIMER] floatValue];
    }else{
        getRequestCallTime=10.0;
    }
    
    cancelTVCellSelectedIndexpath=nil;
    pref=[NSUserDefaults standardUserDefaults];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    enableLocationAccessMessage = [NSString stringWithFormat:@"Please Enable location access from Setting -> %@ -> Privacy -> Location services", [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey]];
    // location manager initialization.
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    CLLocationCoordinate2D coordinate = [self getLocation];
    strForCurLatitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
    strForCurLongitude= [NSString stringWithFormat:@"%f", coordinate.longitude];
    
    cancelReasonID=[[NSMutableArray alloc]init];
    cancelReasonText=[[NSMutableArray alloc]init];
    arrPath=[[NSMutableArray alloc]init];
    dictWalker = [[NSMutableDictionary alloc]init];
    resp = [[NSMutableDictionary alloc]init];
    
    //Start ride view hidden
    _currentStartRideDetailBigView.hidden=YES;
    _currentStartRideView.hidden=NO;
    _currentCancelAlertBigView.hidden=YES;
    _currentDriverCallBigView.hidden=YES;
    
    //Driver call view
    _currentDriverCallView.layer.borderColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    _currentDriverCallView.layer.borderWidth = 0.5f;
    _currentDriverCallView.layer.cornerRadius = 2;
    _currentDriverCallView.clipsToBounds=YES;
    
    //start ride cornor radius
    _currentStartRideView.layer.borderColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    _currentStartRideView.layer.borderWidth = 0.5f;
    _currentStartRideView.layer.cornerRadius = 2;
    _currentStartRideView.clipsToBounds=YES;
    
    _currentStartRideDetailBigView.layer.borderColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    _currentStartRideDetailBigView.layer.borderWidth = 0.5f;
    _currentStartRideDetailBigView.layer.cornerRadius = 2;
    _currentStartRideDetailBigView.clipsToBounds=YES;
    
    _currentStartRideDetailIcon.layer.cornerRadius = 2;
    _currentStartRideDetailIcon.clipsToBounds=YES;
    
    _currentStartRideIcon.layer.cornerRadius = 2;
    _currentStartRideIcon.clipsToBounds=YES;
    
    [pref setValue:_requestID forKey:PREF_REQ_ID];
    [self requestPath];
    isResponse=YES;
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:[strForCurLatitude doubleValue] longitude:[strForCurLongitude doubleValue] zoom:16.0];
    mapView_ = [GMSMapView mapWithFrame:self.viewGoogleMap.bounds camera:camera];
    mapView_.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    mapView_.myLocationEnabled =  YES;
    mapView_.settings.myLocationButton =  NO;
    mapView_.settings.rotateGestures =  NO;
    mapView_.settings.tiltGestures = NO;
    //mapView_.settings.zoomGestures=YES;
    //mapView_.settings.scrollGestures=YES;
    mapView_.delegate=self;
    [self.viewGoogleMap addSubview:mapView_];
    
    pathpoliline=[GMSMutablePath path];
    pathpoliline=[[GMSMutablePath alloc] init];
    pathUpdates = [GMSMutablePath path];
    pathUpdates = [[GMSMutablePath alloc]init];
    
    //Enable gesture action for Search Bar
    UITapGestureRecognizer *searchDestinationGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openDestinationSearchBarController:)];
    [_destinationHolderView addGestureRecognizer: searchDestinationGesture];
    _destinationHolderView.userInteractionEnabled = YES;
    
    //Enable Gesture action for Start ride page walker details
    UITapGestureRecognizer *startRideDetailsViewtapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(currentSelectStartRideWalkerGesture:)];
    _currentStartRideView.userInteractionEnabled = YES;
    [_currentStartRideView addGestureRecognizer:startRideDetailsViewtapRecognizer];
    
    UITapGestureRecognizer *startRideViewtapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(currentSelectStartRideWalkerDetailsGesture:)];
    _currentStartRideDetailView.userInteractionEnabled = YES;
    [_currentStartRideDetailView addGestureRecognizer:startRideViewtapRecognizer];
    
    UITapGestureRecognizer *startRideDetailsNumbertapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(currentSelectStartRideDetailsNumberGesture:)];
    _currentStartRideDetailCallDriverView.userInteractionEnabled = YES;
    [_currentStartRideDetailCallDriverView addGestureRecognizer:startRideDetailsNumbertapRecognizer];
    
    UITapGestureRecognizer *startRideDetailsCanceltapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(currentSelectStartRideDetailsCancelGesture:)];
    _currentStartRideDetailCancelView.userInteractionEnabled = YES;
    [_currentStartRideDetailCancelView addGestureRecognizer:startRideDetailsCanceltapRecognizer];
    
    UITapGestureRecognizer *startRideDetailsSharetapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(currentSelectStartRideDetailsShareGesture:)];
    _currentStartRideDetailShareView.userInteractionEnabled = YES;
    [_currentStartRideDetailShareView addGestureRecognizer:startRideDetailsSharetapRecognizer];
    UITapGestureRecognizer *hidekeyBoardgesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideCommentTextviewKeyBoard:)];
    moreBigView.userInteractionEnabled=YES;
    [moreBigView addGestureRecognizer:hidekeyBoardgesture];
    mapView_.padding = UIEdgeInsetsMake(0, 0, 50, 0);
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    driverCarIcon=[UIImage imageNamed:@"Executive"];
    
    _currentCancelTableView.tableFooterView = [UIView new];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    onceToken=0;
    markerOwner=nil;
    markerOwnerDest.map=nil;
    markerOwnerDest=nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"currentRideDataFromSearch" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(currentSearchPageNotification:) name:@"currentRideDataFromSearch" object:nil];
//    [mapView_ addObserver:self forKeyPath:@"myLocation" options:0 context:nil];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    clearViewOnGoogleButton.frame = CGRectMake(0, self.view.frame.size.height, 100, 40);
    clearViewOnGoogleButton.backgroundColor=[UIColor magentaColor];
    [self.view addSubview:clearViewOnGoogleButton];
    [self.view bringSubviewToFront:clearViewOnGoogleButton];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    
}

-(void)dealloc
{
    mapView_=nil;
    cancelReasonID = nil;
    cancelReasonText=nil;
    arrPath = nil;
    dictWalker=nil;
    resp=nil;
//    [mapView_ removeObserver:self forKeyPath:@"myLocation"];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"currentRideDataFromSearch" object:nil];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [timerForCheckReqStatus invalidate];
    timerForCheckReqStatus = nil;
    timerIsStopped=YES;
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    [timerForCheckReqStatus invalidate];
    timerForCheckReqStatus=nil;
    timerIsStopped=YES;
    ALog(@"The memory error is in currentride page");
    // Dispose of any resources that can be recreated.
}

#pragma mark -Button Action

- (IBAction)currentBackBtn:(id)sender {
    timerIsStopped=YES;
    [timerForCheckReqStatus invalidate];
    timerForCheckReqStatus=nil;
    [customAlertView close];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)openDestinationSearchBarController:(UITapGestureRecognizer*)sender{
    if ([APPDELEGATE connected]) {
        [pref setObject:_currentDestinationSearchTxt.text forKey:PREF_SEARCH_EDIT_ADDRESS];
        [pref setObject:@"destination" forKey:PREF_FROM_DESTINATION];
        [self performSegueWithIdentifier:STRING_SEGUE_SEARCH_PAGE sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }


}

#pragma mark - Start Ride Gesture actions

- (void)currentSelectStartRideWalkerGesture:(UITapGestureRecognizer*)sender {
    [self setView:_currentStartRideDetailBigView hidden:NO];
    _currentStartRideView.hidden=YES;
//    _currentLocationButton.hidden=YES;
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:mapView_
                      duration:0.2
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self animateViewHeight:_currentNavigationView withAnimationType:kCATransitionFromTop hidden:YES animationDuration:0.3];
                        [self animateViewHeight:_currentDestinationView withAnimationType:kCATransitionFromTop hidden:YES animationDuration:0.2];
                        self.view.userInteractionEnabled=YES;
                    }];
}

- (void)currentSelectStartRideWalkerDetailsGesture:(UITapGestureRecognizer*)sender {
    _currentStartRideDetailBigView.hidden=YES;
//    _currentLocationButton.hidden=NO;
    [self setView:_currentStartRideView hidden:NO];
    [UIView transitionWithView:mapView_
                      duration:0.2
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        
                        [self animateViewHeight:_currentNavigationView withAnimationType:kCATransitionFromBottom hidden:NO animationDuration:0.3];
                    }
                    completion:^(BOOL finished){
                        [self animateViewHeight:_currentDestinationView withAnimationType:kCATransitionFromBottom hidden:NO animationDuration:0.1];
                        
                        //                        [self animateBottomViewHeight:_currentNavigationView withAnimationType:kCATransitionFromBottom hidden:NO];
                        //                        [self animateViewHeight:_currentDestinationView withAnimationType:kCATransitionFromBottom hidden:NO animationDuration:0.2];
                        self.view.userInteractionEnabled=YES;
                    }];
}

- (void)currentSelectStartRideDetailsNumberGesture:(UITapGestureRecognizer*)sender {
    _currentDriverCallPhoneLbl.text=[NSString stringWithFormat:@"%@",strForWalkerPhone];
    _currentDriverCallBigView.hidden=NO;
}

- (void)currentSelectStartRideDetailsCancelGesture:(UITapGestureRecognizer*)sender {
    if([APPDELEGATE connected])  {
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:@"reason" forKey:PARAM_TYPE];
        [dictParam setValue:[pref objectForKey:PREF_REQ_ID] forKey:PARAM_REQUEST_ID];
        
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_CANCEL_REQUEST withParamData:dictParam withBlock:^(id response, NSError *error)
         {
             ALog(@"REFERAL Response ---> %@",response);
             if (response == Nil){
                 if (error.code == -1005) {
                     [APPDELEGATE stopLoader:self.view];
                     [self currentSelectStartRideDetailsCancelGesture:sender];
                     
                 }else {
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPDELEGATE stopLoader:self.view];
                         [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                     });
//                 [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                 [customAlertView show];
                 }
             }else if (response)
             {
                 if([[response valueForKey:@"success"]boolValue])
                 {
                     [cancelReasonText removeAllObjects];
                     [cancelReasonID removeAllObjects];
                     _currentCancelAlertBigView.hidden=NO;
                     _currentCancelAlertYesBtn.enabled=NO;
                     [_currentCancelAlertYesBtn setTitleColor:[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1] forState:UIControlStateNormal];
                     NSMutableArray *reasons = [response valueForKey:@"reason"];
                     for(NSMutableDictionary *reasonContent in reasons){
                         [cancelReasonID addObject:[reasonContent valueForKey:@"id"]];
                         [cancelReasonText addObject:[reasonContent valueForKey:@"reason"]];
                     }
                 }
                 else{
                     [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                     [customAlertView show];
                 }
                  [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
             }
             [_currentCancelTableView reloadData];
         }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}

- (void)currentSelectStartRideDetailsShareGesture:(UITapGestureRecognizer*)sender {
    if([[pref valueForKey:PREF_SETTING_RIDE_NOW_DESTINATION] boolValue] || _currentDestinationSearchTxt.text.length > 1){
        [self shareText:[NSString stringWithFormat:@"Hey there !! I'm travelling Orbit in Car %@ with Driver %@ from %@ to %@",_currentStartRideDetailCarNumber.text,_currentStartRideDetailName.text,strForSourceAddress,strForDestinationAddress] andImage:nil andUrl:nil];
    }else{
        [self shareText:[NSString stringWithFormat:@"Hey there !! I'm travelling Orbit in Car %@ with Driver %@ from %@",_currentStartRideDetailCarNumber.text,_currentStartRideDetailName.text,strForSourceAddress] andImage:nil andUrl:nil];
    }
}
- (void)currentSelectStartRideDetailsMoreGesture:(UITapGestureRecognizer*)sender {
    tempViewForScrlView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width , self.view.frame.size.height)];
    [self.view addSubview:tempViewForScrlView];
    scrlview = [[TPKeyboardAvoidingScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [tempViewForScrlView addSubview:scrlview];
    moreBigView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width , self.view.frame.size.height)];
    moreBigView.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.7];
    [scrlview addSubview:moreBigView];
    UIView *noteAndShareView =[[UIView alloc] initWithFrame:CGRectMake(20, (self.view.frame.size.height/2 - 125), self.view.frame.size.width - 40,250)];
    noteAndShareView.backgroundColor=[UIColor whiteColor];
    noteAndShareView.layer.cornerRadius=5.0;
    UILabel *addNoteLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, noteAndShareView.frame.size.width - 40, 40)];
    addNoteLabel.text = @"Add a note";
    commentTextView = [[UITextView alloc] initWithFrame:CGRectMake(20, 60, noteAndShareView.frame.size.width - 90, 90)];
    commentTextView.text = @"I am near to ...";
    commentTextView.textColor=[UIColor orbitBlackColorhex7];
    commentTextView.delegate=self;
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(20, 150 , noteAndShareView.frame.size.width - 30, 2)];
    line.backgroundColor=[UIColor orbitBlackColorhex7];
    UILabel *informLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 152, noteAndShareView.frame.size.width - 40, 40)];
    informLabel.text = @"Inform";
    UIButton *informButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 192, noteAndShareView.frame.size.width - 40, 40)];
    [informButton setTitle:@"Tap here to share your booking details to friends" forState:UIControlStateNormal];
    [informButton setTitleColor:[UIColor orbitBlackColorhex7] forState:UIControlStateNormal];
    [informButton addTarget:self action:@selector(informToYourFriendsButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *shareButton = [[UIButton alloc] initWithFrame:CGRectMake(noteAndShareView.frame.size.width - 60, 60, 50, 40)];
    [shareButton setTitle:@"Share" forState:UIControlStateNormal];
    [shareButton setTitleColor:[UIColor orbitYellowColor] forState:UIControlStateNormal];
    shareButton.titleLabel.font = [UIFont fontWithName:@"Dinpro-Regular" size:15.0];
    [shareButton addTarget:self action:@selector(shareToDriverButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [moreBigView addSubview:noteAndShareView];
    [noteAndShareView addSubview:addNoteLabel];
    [noteAndShareView addSubview:commentTextView];
    [noteAndShareView addSubview:line];
    [noteAndShareView addSubview:shareButton];
    [noteAndShareView addSubview:informLabel];
    [noteAndShareView addSubview:informButton];
//    [moreBigView addSubview:self.view];
}

-(void)informToYourFriendsButtonAction {
    [tempViewForScrlView removeFromSuperview];
    if([[pref valueForKey:PREF_SETTING_RIDE_NOW_DESTINATION] boolValue] || _currentDestinationSearchTxt.text.length > 1){
        [self shareText:[NSString stringWithFormat:@"Hey there !! I'm travelling Orbit in Car %@ with Driver %@ from %@ to %@",_currentStartRideDetailCarNumber.text,_currentStartRideDetailName.text,strForSourceAddress,strForDestinationAddress] andImage:nil andUrl:nil];
    }else{
        [self shareText:[NSString stringWithFormat:@"Hey there !! I'm travelling Orbit in Car %@ with Driver %@ from %@",_currentStartRideDetailCarNumber.text,_currentStartRideDetailName.text,strForSourceAddress] andImage:nil andUrl:nil];
    }
}

-(void)shareToDriverButtonAction : (UIButton*) sender{
    sender.hidden=YES;
    [commentTextView resignFirstResponder];
    commentTextView.text=@"Your note has been sent.";
    commentTextView.userInteractionEnabled=NO;
    ALog(@"sharing to driver failed code is not written here");
}

-(void)hideCommentTextviewKeyBoard:(UITapGestureRecognizer* )sender {
    ALog(@"Innner view is called so hide keyboard");
    [commentTextView resignFirstResponder];
}

#pragma mark - TextView Delegate
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"I am near to ..."]) {
        textView.text = @"";
        textView.textColor = [UIColor blackColor]; //optional
    }
    [textView becomeFirstResponder];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@""]) {
        textView.text = @"I am near to ...";
        textView.textColor = [UIColor lightGrayColor]; //optional
    }
    [textView resignFirstResponder];
}

#pragma mark - cancel ride button Actions

- (IBAction)currentCancelAlertYesBtn:(id)sender {
    
    cancelTVCellSelectedIndexpath=nil;
    [timerForCheckReqStatus invalidate];
    timerForCheckReqStatus = nil;

    if([strForCancelReasonID isEqualToString:@""]){
        
    }
    if([CLLocationManager locationServicesEnabled])
    {
        if([APPDELEGATE connected]){
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:[pref objectForKey:PREF_REQ_ID] forKey:PARAM_REQUEST_ID];
            [dictParam setValue:strForCancelReasonID forKey:PARAM_REASON_ID];
            [dictParam setValue:strForCancelReasonText forKey:PARAM_REASON];
            [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
            [dictParam setValue:@"trip_cancel" forKey:PARAM_TYPE];
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_CANCEL_REQUEST withParamData:dictParam withBlock:^(id response, NSError *error)
             {
                 if (response == Nil){
                      [APPDELEGATE stopLoader:self.view];
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self currentCancelAlertYesBtn:sender];
                         
                     }else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                     }
                 }else if (response)
                 {
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         [timerForCheckReqStatus invalidate];
                         timerForCheckReqStatus=nil;
                         _currentCancelAlertBigView.hidden=YES;
                         strForCancelReasonText=@"";
                         strForCancelReasonID=@"";
                         markerOwner=nil;
                         markerOwnerDest=nil;
                         isResponse=NO;
                         [pref removeObjectForKey:PARAM_REQUEST_ID];
                         if ([[response valueForKey:@"cancel_amount_status"] boolValue])
                         {
                             if ([[response valueForKey:@"cancel_amount"] doubleValue] > 0) {
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                     OutStandingPaymentsViewController *paymentVC = [[OutStandingPaymentsViewController alloc] initWithNibName:@"OutStandingPaymentsViewController" bundle:nil];
                                     paymentVC.isPushed=NO;
                                     paymentVC.request_id=[pref stringForKey:PREF_REQ_ID];
                                     paymentVC.outStandingAmount = [response valueForKey:@"cancel_amount"];
                                     paymentVC.isPresentedFromCurrentRide=YES;
                                     paymentVC.isPresentedFromBookingPage= NO;
                                     [self.navigationController pushViewController:paymentVC animated:NO];
                                     [APPDELEGATE showAlertOnTopMostControllerWithText:RIDE_CANCELLED_BY_CUSTOMER];
                                 });
                             } else {
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                     [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_CUSTOMER view:self.view]];
                                     customAlertView.tag=101;
                                     [customAlertView show];
                                 });
                             }
                             // unpaid amount is there so show outstanding payment screen
                                 ALog(@"Showing payment screen in current ride because ride complete is not available and old balance is %@ ., \nresponse = %@", [response valueForKey:@"cancel_amount"], response);
                         } else {
                             // the cancelled amount is paid (amount deducted from card automatically or other means) so show ride cancelled screen
                             
                              if ([[response valueForKey:@"cancel_amount"] boolValue]) {
                                  ALog(@"Showing cancel payment screen because ride is cancelled and amount paid from cancelled ride =  %@ . and \nresponse = %@", [response valueForKey:@"cancel_amount"], response);
                                  NSMutableDictionary *cancelDict = [[NSMutableDictionary alloc] init];
                                  [cancelDict setObject:[NSString stringWithFormat:@"%@ %@", [pref valueForKey:PREF_SETTING_CURRENCY_TEXT], [response valueForKey:@"cancel_amount"]] forKey:@"cancel_amount"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"trip_id"] forKey:@"trip_id"];
                                  [cancelDict setObject:[response valueForKey:@"walker_data"] forKey:@"walker_data"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"cancellation_date"] forKey:@"cancellation_date"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"cancellation_date"] forKey:@"cancellation_time"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"payment_type"] forKey:@"payment_type"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"payment_mode"] forKey:@"payment_mode"];
                                  [cancelDict setObject:[[response valueForKey:@"request_data"] valueForKey:@"payment_message"] forKey:@"payment_message"];
                                  [cancelDict setValue:@YES forKey:@"is_customer"];
                                  if ([response valueForKey:@"payment_description"]) {
                                      [cancelDict setObject:[response valueForKey:@"payment_description"] forKey:@"payment_description"];
                                  }
                                  
                                  dispatch_async(dispatch_get_main_queue(), ^{
                                      [self showCancelledTripAmountPaidScreenWithresponse:cancelDict AndShowAlert:YES];
                                  });
                              }else {
                                  dispatch_async(dispatch_get_main_queue(), ^{
                                      [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_CUSTOMER view:self.view]];
                                      customAlertView.tag=101;
                                      [customAlertView show];
                                  });
                              }
                         }
                         
                         [APPDELEGATE stopLoader:self.view];
                     }
                     else {
                         isResponse=YES;
                         [APPDELEGATE stopLoader:self.view];
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                         [customAlertView show];
                         [self setTimerToCheckDriverStatus];
                          _currentCancelAlertBigView.hidden=YES;
                     }
                 }
             }];
        }
        else
        {
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
        }
        
    }
    else
    {   //
        [customAlertView setContainerView:[APPDELEGATE createDemoView:enableLocationAccessMessage view:self.view]];
        [customAlertView show];
    }
}


-(void)sendCancelledRequestAmountPaidEmailWithId: (NSString*)requestId {
    ALog(@"request id in cancel email = %@", requestId);
    if (![requestId  isEqual: @""]) {
        NSString *strForUrl=[NSString stringWithFormat:@"%@?%@=%@",FILE_SEND_CANCEL_EMAIL,PARAM_REQUEST_ID,requestId];
        ALog(@"The cancel email url in landing page is = %@", strForUrl);
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
        [afn getDataFromPath:strForUrl withParamData:nil withBlock:^(id response, NSError *error){
            ALog(@"response in cencel email = %@", response);
        }];
    }
}

- (IBAction)currentCancelAlertNoBtn:(id)sender {
    _currentCancelAlertBigView.hidden=YES;
    strForCancelReasonText=@"";
    strForCancelReasonID=@"";
    cancelTVCellSelectedIndexpath=nil;
     [self setTimerToCheckDriverStatus];
}

#pragma mark search page Delegate methods

- (void) currentSearchPageNotification:(NSNotification *)notification {
    if([[notification object]isEqualToString:@"currentLocation"]){
        [self getMyLocationIsPressed];
    }else{
        _currentDestinationSearchTxt.text=[notification object];
        currentDestinationAddress=[notification object];
        if ( [[notification object]  isEqual: @""]) {
            if (isLater && [[pref valueForKey:PREF_SETTING_RIDE_LATER_DESTINATION] boolValue]) {
                ALog(@"Ride later is mandatory but given empty address ======================");
                return;
            }else if (!isLater && [[pref valueForKey:PREF_SETTING_RIDE_NOW_DESTINATION] boolValue]){
                ALog(@"Ride now is mandatory but given empty address==========================");
                return;
            }else{
                markerOwnerDest.map=nil;
                markerOwnerDest=nil;
                strForDesLatitude=@"";
                strForDesLongitude=@"";
                markerOwner=nil;
                markerOwner.map=nil;
                [self startRideDestinationChangeWithLat:@"" andLong:@"" andAddress:@""];
            }
        }else {
            [self getLocationFromAddressString:[notification object]];
        }
        
    }
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return cancelReasonID.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Configure the cell...
    CancelTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cancelCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell=[[CancelTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cancelCell"];
    }
//    cell.selectedBackgroundView = [UIView new];
//    cell.selectedBackgroundView.backgroundColor = [UIColor orbitYellowColor];
    cell.cancelBGImgView.image=nil;
    cell.cancelReasonCell.textColor = [UIColor blackColor];
    cell.cancelReasonCell.highlightedTextColor = [UIColor whiteColor];
     cell.cancelBGImgView.image=nil;
    if(cancelReasonText.count > 0){
        cell.cancelReasonCell.text=[cancelReasonText objectAtIndex:indexPath.row];
        if (cancelTVCellSelectedIndexpath) {
            if (indexPath.row == cancelTVCellSelectedIndexpath.row) {
                cell.cancelBGImgView.image=[UIImage imageNamed:@"TVCell_selecetd"];
                _currentCancelAlertYesBtn.enabled=YES;
                [_currentCancelAlertYesBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            }
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.separatorInset = UIEdgeInsetsZero;
    if(IS_OS_8_OR_LATER>8.0){
        cell.preservesSuperviewLayoutMargins = false;
    }
    
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}


# pragma mark -TableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    strForCancelReasonID=[cancelReasonID objectAtIndex:indexPath.row];
    strForCancelReasonText=[cancelReasonText objectAtIndex:indexPath.row];
    _currentCancelAlertYesBtn.enabled=YES;
    [_currentCancelAlertYesBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    cancelTVCellSelectedIndexpath=indexPath;
    [_currentCancelTableView reloadData];

}


#pragma mark -start ride driver call button Actions

- (IBAction)currentDriverCallBtn:(id)sender {
    if(![strForWalkerPhone isEqualToString:@""]){
        NSString *urlstring=[NSString stringWithFormat:@"tel:%@",strForWalkerPhone];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlstring]];
    }
    _currentDriverCallBigView.hidden=YES;
}

- (IBAction)currentDriverCallCancelBtn:(id)sender {
    _currentDriverCallBigView.hidden=YES;
}

#pragma mark - share actions

- (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url
{
    NSMutableArray *sharingItems = [NSMutableArray new];
    
    if (text) {
        [sharingItems addObject:text];
    }
    if (image) {
        [sharingItems addObject:image];
    }
    if (url) {
        [sharingItems addObject:url];
    }
    
    UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:sharingItems applicationActivities:nil];
    [self presentViewController:activityController animated:YES completion:nil];
}

#pragma mark - Segue Actions
-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_RIDE_COMPLETE]){
        RideCompleteVC *rideController = (RideCompleteVC *)segue.destinationViewController;
        rideController.rideCompleteDelegate=self;
        rideController.calledFromVc=@"currentRideViewController";
        rideController.strRideCompleteTripID=rideCompleteTripID;
        rideController.strRideCompleteTime=rideCompleteTime;
        rideController.strRideCompleteDate=rideCompleteDate;
        rideController.strRideCompleteCarCatorgery=rideCompleteCarCatorgery;
        rideController.strRideCompletePayment=rideCompletePayment;
        rideController.strRideCompletePrice=rideCompletePrice;
        rideController.strRideCompleteMessage=rideCompleteMessage;
        rideController.strRideCompleteDriverName=rideCompleteDriverName;
        rideController.strRideCompleteDriverCarCategory=rideCompleteDriverCarCategory;
        rideController.strRideCompleteDriveIcon=rideCompleteDriveIcon;
        rideController.strRideCompleteDriverCarNumber=rideCompleteDriverCarNumber;
        rideController.lastWalkId=strForLatLongID;
        rideController.strRideCompleteRequestId=[NSString stringWithFormat:@"%@", rideCompleteRequestId];
        ALog(@"Ride complete request id is %@", rideCompleteRequestId);
    }else if([segue.identifier isEqualToString:STRING_SEGUE_SEARCH_PAGE]){
        searchController = (SearchViewController *)segue.destinationViewController;
        searchController.strForCurrentPage=@"concurrentRide";
        searchController.originOrDestination=@"destination";
        searchController.latLongString = [NSString stringWithFormat:@"%@, %@", strForCurLatitude, strForCurLongitude];
    }
}


#pragma mark -Delegate animate bottom to top

- (void)animateViewHeight:(UIView*)animateView withAnimationType:(NSString*)animType hidden:(BOOL)hidden animationDuration :(CFTimeInterval) duration {
    CATransition *animation = [CATransition animation];
    [animation setType:kCATransitionPush];
    [animation setSubtype:animType];
    [animation setDuration:duration];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn]];
    [[animateView layer] addAnimation:animation forKey:kCATransition];
    animateView.hidden = hidden;
}

- (void)setView:(UIView*)view hidden:(BOOL)hidden {
    CATransition *transition = [CATransition animation];
    transition.type =kCATransitionFromTop;
    transition.duration = 0.0f;
    transition.delegate = self;
    [view.layer addAnimation:transition forKey:nil];
    view.hidden=hidden;
}



#pragma mark- Google Map Delegate

- (void)mapView:(GMSMapView *)mapView didChangeCameraPosition:(GMSCameraPosition *)position
{
    zoom= mapView.camera.zoom;
    strForLatitude=[NSString stringWithFormat:@"%f",position.target.latitude];
    strForLongitude=[NSString stringWithFormat:@"%f",position.target.longitude];
}

- (void) mapView:(GMSMapView *)mapView idleAtCameraPosition:(GMSCameraPosition *)position
{
    if([CLLocationManager locationServicesEnabled]&&
       [CLLocationManager authorizationStatus] != kCLAuthorizationStatusDenied)
    {
        
    }
    else if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusDenied ){

    }
}


#pragma mark - Location Delegate

-(CLLocationCoordinate2D) getLocation
{
    if (locationManager == nil) {
        locationManager = [[CLLocationManager alloc] init];
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        locationManager.distanceFilter = kCLDistanceFilterNone;
        if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
            [locationManager requestWhenInUseAuthorization];
        }
        [locationManager startUpdatingLocation];
    } else {
        [locationManager startUpdatingLocation];
    }
    CLLocation *location = [locationManager location];
    CLLocationCoordinate2D coordinate = [location coordinate];
    dispatch_async(dispatch_get_main_queue(), ^{
        ALog(@"cllocation manager coordinates are  %f, %f", coordinate.latitude, coordinate.longitude);
    });
    [locationManager stopUpdatingLocation];
    return coordinate;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    ALog(@"location manager didUpdateLocations  is called %@",[locations lastObject] );
    // CLLoclocation manager ation *currentLocation = [locations objectAtIndex:0];
        CLLocation *location = [locations lastObject];
//        CLLocationCoordinate2D coordinate = [location coordinate];
        ALog(@"test location = %f, %f ",[location coordinate].latitude, [location coordinate].longitude);
//        strForCurLatitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
//        strForCurLongitude= [NSString stringWithFormat:@"%f", coordinate.longitude];
        [locationManager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    ALog(@"didFailWithError: %@", error);
    
}

-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    
    if (status == kCLAuthorizationStatusAuthorizedAlways || status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        [pref setBool:NO forKey:@"locationStatus"];
        ALog(@"test location");
        CLLocation *location = [manager location];
        CLLocationCoordinate2D coordinate = [location coordinate];
        strForCurLatitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
        strForCurLongitude= [NSString stringWithFormat:@"%f", coordinate.longitude];
        ALog(@"current loaction of customer = %@ , %@", strForCurLatitude, strForCurLongitude);
//        [self getAllApplicationType:strForCurLatitude longitude:strForCurLongitude];
        [self getAddress];
        
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:[strForCurLatitude doubleValue] longitude:[strForCurLongitude doubleValue] zoom:16.0];
        //mapView_ = [GMSMapView mapWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) camera:camera];
        mapView_ = [GMSMapView mapWithFrame:self.viewGoogleMap.bounds camera:camera];
        mapView_.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        mapView_.myLocationEnabled =  YES;
        mapView_.settings.myLocationButton =  NO;
        [mapView_.settings setRotateGestures:NO];
        [mapView_.settings setTiltGestures:NO];
        //    mapView_.settings.zoomGestures=NO;
//        mapView_.settings.scrollGestures=NO;
         mapView_.settings.allowScrollGesturesDuringRotateOrZoom=NO;
        [mapView_ setMinZoom:5 maxZoom:19];
        mapView_.delegate=self;
        [self.viewGoogleMap addSubview:mapView_];
    }
}

- (IBAction)moveToCurrentLocation:(id)sender {
    CLLocationCoordinate2D coordinate = [self getLocation];
    [mapView_ animateToLocation:coordinate];
    [mapView_ animateToZoom:16.0];
}

-(void)getMyLocationIsPressed {
    if ([CLLocationManager locationServicesEnabled])
    {
        CLLocationCoordinate2D coor;
        coor.latitude=[strForCurLatitude doubleValue];
        coor.longitude=[strForCurLongitude doubleValue];
        
        GMSCameraUpdate *updatedCamera = [GMSCameraUpdate setTarget:coor zoom:16.0];
        [mapView_ animateWithCameraUpdate:updatedCamera];
        strForDesLatitude=strForCurLatitude;
        strForDesLongitude=strForCurLongitude;
        [self getAddress];
    }
    else
    {
        UIAlertView* LocationStatus=[[UIAlertView alloc] initWithTitle:@"This app does not have access to Location services" message:@"Please allow Orbit to use location services .Turn it on from settings" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Settings", nil];
        [LocationStatus show];
    }
}

-(void)getAddress
{
    if([APPDELEGATE connected]) {
        NSString *url = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/directions/json?origin=%f,%f&destination=%f,%f&sensor=false",[strForDesLatitude floatValue], [strForDesLongitude floatValue], [strForDesLatitude floatValue], [strForDesLongitude floatValue]];
        
        NSString *str = [NSString stringWithContentsOfURL:[NSURL URLWithString:url] encoding:NSUTF8StringEncoding error:nil];
        if (str) {
            NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: [str dataUsingEncoding:NSUTF8StringEncoding]
                                                                 options: NSJSONReadingMutableContainers
                                                                   error: nil];
            
            NSDictionary *getRoutes = [JSON valueForKey:@"routes"];
            
            NSDictionary *getLegs = [getRoutes valueForKey:@"legs"];
            NSArray *getAddress = [getLegs valueForKey:@"end_address"];
            if (getAddress.count!=0)
            {
                if(![[[getAddress objectAtIndex:0]objectAtIndex:0] isEqual:[NSNull null]]){
                    _currentDestinationSearchTxt.text=[[getAddress objectAtIndex:0]objectAtIndex:0];
                    currentDestinationAddress=[[getAddress objectAtIndex:0]objectAtIndex:0];
                }
            }
        } else{
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
        }

    } else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


- (void) getLocationFromAddressString:(NSString *)addresss
{
    if (!(addresss.length > 3)) {
        _currentDestinationSearchTxt.text = @"";
        [self startRideDestinationChangeWithLat:@"" andLong:@"" andAddress:@""];
        ALog(@"new address = %@", addresss);
    } else {
        double latitude = 0, longitude = 0;
        //    NSString* newAddress = @"Tech Active Solutions (India) Private Limited, Bengaluru, Karnataka, India";
        NSString *esc_addr = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                                                                        NULL,
                                                                                                        (CFStringRef)addresss,
                                                                                                        NULL,
                                                                                                        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                                        kCFStringEncodingUTF8 ));

        NSString *req = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=%@&key=%@", esc_addr, GOOGLE_KEY];
        ALog(@"url = %@", req);
        
        NSURL *URL = [NSURL URLWithString:req];
        NSData *data = [NSData dataWithContentsOfURL:URL];
        if (data) {
            NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: data
                                                                 options: NSJSONReadingMutableContainers
                                                                   error: nil];
            ALog(@"Json result = %@", JSON);
            NSArray *results = [JSON valueForKey:@"results"];
            if ([results count] >0) {
                NSDictionary *address = [results firstObject];
//                _currentDestinationSearchTxt.text=[address valueForKey:@"formatted_address"];
                strForDesLatitude=[NSString stringWithFormat:@"%@",[[[address valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"]];
                strForDesLongitude=[NSString stringWithFormat:@"%@",[[[address valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"]];
                [self getAddressFromLatLongUsingGeocodeForDestinationWithLattitude:strForDesLatitude andLongitude:strForDesLongitude andAddress:addresss];
            } else {
                if ([JSON valueForKey:@"error_message"]){
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[JSON valueForKey:@"error_message"] view:self.view]];
                    [customAlertView show];
                }
            }
        }
        ALog(@"new lattitude = %f, longitude =- %f and address = %@", latitude, longitude, addresss);
    }
    
}

-(void) startRideDestinationChangeWithLat: (NSString*)lattitude andLong: (NSString*)longitude andAddress: (NSString*)address{
    if([APPDELEGATE connected]){
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:address  forKey:PARAM_DESTINATION_ADDRESS];
        if ([lattitude isEqualToString:@""] || [longitude isEqualToString:@""]) {
            [dictParam setValue:@"0"  forKey:PARAM_D_LATITUDE];
            [dictParam setValue:@"0"  forKey:PARAM_D_LONGITUDE];
        }else {
            [dictParam setValue:lattitude  forKey:PARAM_D_LATITUDE];
            [dictParam setValue:longitude  forKey:PARAM_D_LONGITUDE];
        }
        [dictParam setValue:[pref stringForKey:PREF_REQ_ID] forKey:PARAM_REQUEST_ID];
        ALog(@"destination change params are = %@", dictParam);
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_SET_DESTINATION withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                [APPDELEGATE stopLoader:self.view];
                if (error.code == -1005 ) {
                    [self startRideDestinationChangeWithLat:lattitude andLong:longitude andAddress:address];
                    ALog(@"network error so call destiantion change again again");
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
//                [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                [customAlertView show];
                }
            }else if (response){
                [APPDELEGATE stopLoader:self.view];
                ALog(@"destination change response = %@", response);
                if([[response valueForKey:@"success"]boolValue]){
                    markerOwnerDest.map=nil;
                    markerOwnerDest=nil;
                }
            }
        }];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}
-(void)callTypesTwoApiToCheckDestinationServicesWithLattitude: (NSString*)lattitude AndLongitude: (NSString*) longitude onCompletion: (void (^)(NSDictionary *dict)) completed{
    
    if([APPDELEGATE connected]){
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:lattitude forKey:PARAM_USER_LATITUDE];
        [dictParam setValue:longitude forKey:PARAM_USER_LONGITUDE];
        ALog(@"types 2  parameters = %@",dictParam);
        
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
        [afn getDataFromPath:FILE_APPLICATION_TYPES_TWO withParamData:dictParam withBlock:^(id response, NSError *error)
         {
             if (response == Nil){
                 if (error.code == -1005 ) {
                     [APPDELEGATE stopLoader:self.view];
                     [self callTypesTwoApiToCheckDestinationServicesWithLattitude:lattitude AndLongitude:longitude onCompletion:^(NSDictionary* completed) {
                         ALog(@"error so calling again types two api");
                     }];
                 }else {
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPDELEGATE stopLoader:self.view];
                         [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                     });
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                 }
             }else if (response){
                 ALog(@"types two response at line-4419 is %@", response);
                 [APPDELEGATE stopLoader:self.view];
                 completed(response);
             }
         }];
    } else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


-(void)getAddressFromLatLongUsingGeocodeForDestinationWithLattitude: (NSString *)lattitude andLongitude: (NSString*)longitude andAddress: (NSString*)addresss {
    if([APPDELEGATE connected]) {
        NSString *url = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?latlng=%@,%@&sensor=false",lattitude, longitude];
        ALog(@"Geocode addres from latlong = %@", url);
        NSURL *URL = [NSURL URLWithString:url];
        NSData *data = [NSData dataWithContentsOfURL:URL];
        if (data) {
            NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: data
                                                                 options: NSJSONReadingMutableContainers
                                                                   error: nil];
            
            NSArray *results = [JSON valueForKey:@"results"];
            
            if (results.count!=0)
            {
                NSDictionary *address = [results firstObject];
                    if([address valueForKey:@"formatted_address"]) {
//                        _currentDestinationSearchTxt.text=[address valueForKey:@"formatted_address"];
                        strForDesLatitude=[NSString stringWithFormat:@"%@",[[[address valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lat"]];
                        strForDesLongitude=[NSString stringWithFormat:@"%@",[[[address valueForKey:@"geometry"] valueForKey:@"location"] valueForKey:@"lng"]];
                        if (checkForDestinationServiceAvailability) {
                            [self callTypesTwoApiToCheckDestinationServicesWithLattitude:strForDesLatitude AndLongitude:strForDesLongitude onCompletion:^(NSDictionary *dict) {
                                if (![[dict valueForKey:@"status"] boolValue]) {
                                    
                                    strForDesLatitude=@"";
                                    strForDesLongitude=@"";
                                    [self startRideDestinationChangeWithLat:@"" andLong:@"" andAddress:@""];
                                    NSString *msg = [dict valueForKey:@"message"];
                                    [customAlertView setContainerView:[APPDELEGATE createDemoView:msg view:self.view]];
                                    customAlertView.tag=1234;
                                    [customAlertView show];
                                    
                                }else {
                                    [self startRideDestinationChangeWithLat:strForDesLatitude andLong:strForDesLongitude andAddress:currentDestinationAddress];
                                }
                            }];
                        } else {
                            [self startRideDestinationChangeWithLat:strForDesLatitude andLong:strForDesLongitude andAddress:currentDestinationAddress];
                        }
                    } else {
                        _currentDestinationSearchTxt.text=@"Please select proper location";
                    }
            }
        } else {
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
            return ;
        }
    }else{
        [APPDELEGATE stopLoader:self.view];
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if([keyPath isEqualToString:@"myLocation"]) {
        CLLocation *location = [object myLocation];
        //...
        ALog(@"Location, %@,", location);
        
        CLLocationCoordinate2D target =
        CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        strForCurLatitude=[NSString stringWithFormat:@"%f", location.coordinate.latitude];
        strForCurLongitude=[NSString stringWithFormat:@"%f", location.coordinate.longitude];
        [mapView_ animateToLocation:target];
        [mapView_ animateToZoom:16.0];
//        [APPDELEGATE stopLoader:self.view];
    }
}

#pragma mark - currentRide API

-(void)setTimerToCheckDriverStatus
{
    if (timerIsStopped) {
        if (timerForCheckReqStatus) {
            [timerForCheckReqStatus invalidate];
            timerForCheckReqStatus = nil;
        }

    } else {
        if (timerForCheckReqStatus) {
            [timerForCheckReqStatus invalidate];
            timerForCheckReqStatus = nil;
        }
        ALog(@"timer is activated and the time from settings = %f",getRequestCallTime );
        timerForCheckReqStatus = [NSTimer scheduledTimerWithTimeInterval:getRequestCallTime target:self selector:@selector(checkForRequestStatus) userInfo:nil repeats:YES];
        
//         timerForCheckReqStatus = [NSTimer scheduledTimerWithTimeInterval:getRequestCallTime target:self selector:@selector(checkForDummyRequestStatus) userInfo:nil repeats:YES];
    }
}

-(void)checkForRequestStatus
{
    if([APPDELEGATE connected]){
        NSString *strReqId=[pref objectForKey:PREF_REQ_ID];
        NSString *strForUrl=[NSString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@&%@=%@&%@=%@",FILE_GET_REQUEST,PARAM_ID,[pref objectForKey:PREF_USER_ID],PARAM_TOKEN,[pref objectForKey:PREF_USER_TOKEN],PARAM_REQUEST_ID,strReqId,PARAM_LAST_WALKER_ID,strForLatLongID,PARAM_LYMO_DEVICE_ID,[pref objectForKey:PREF_LYMO_DEVICE_ID]];
        ALog(@"request url in myrides current ride = %@", strForUrl);
        // NSString *strForUrl=[NSString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@",FILE_GET_REQUEST,PARAM_ID,@"222",PARAM_TOKEN,@"2y10a5RMW0Z3TuJkScXEh0QdokzroiO4cTW6L9lLYsYV9BFe28DJ6lS",PARAM_REQUEST_ID,strReqId];
        
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
        [afn getDataFromPath:strForUrl withParamData:nil withBlock:^(id response, NSError *error){
            if(isResponse){
                if (response == Nil){
                    
//                    [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                    [customAlertView show];
                }else if (response){
                    if([[response valueForKey:@"success"]boolValue] && [[response valueForKey:@"status"] intValue]) {
                        ALog(@"GET REQ--->%@",response);
                        if([[response valueForKey:@"status"] intValue]!=0){
                            if([[response valueForKey:@"is_completed"] intValue]!=0){
                                isResponse = NO;
                                _backButton.hidden=YES;
                                [timerForCheckReqStatus invalidate];
                                timerForCheckReqStatus = nil;
                                _lymoArrivingLbl.text=@"Trip Ended";
                                _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                                _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                                _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                                _currentCancelAlertBigView.hidden=YES;
                                dispatch_once(&onceToken, ^{
                                    _lymoArrivingLbl.text=@"Trip Ended";
                                    timerIsStopped=YES;
                                    [timerForCheckReqStatus invalidate];
                                    timerForCheckReqStatus = nil;
                                    ALog(@"The trip is ended showing ride complete here---------------********---------");
                                    dictWalker=[response valueForKey:@"walker"];
                                    rideCompleteTripID=[response valueForKey:@"trip_id"];
                                    rideCompleteRequestId = strReqId;
                                    rideCompleteDate=[response valueForKey:@"request_end_date"];
                                    rideCompleteCarCatorgery=[dictWalker valueForKey:@"type_name"];
                                    rideCompleteTime=[response valueForKey:@"request_end_time"];
                                    rideCompletePayment=[response valueForKey:@"payment_type_content"];
                                    rideCompletePrice=[response valueForKey:@"total"];
                                    rideCompleteMessage=[response valueForKey:@"payment_description"];
                                    rideCompleteDriveIcon=[dictWalker valueForKey:@"picture"];
                                    if ([[dictWalker valueForKey:@"sec_car_model"] length] > 1) {
                                        rideCompleteDriverCarCategory=[dictWalker valueForKey:@"sec_car_model"];
                                    }else{
                                        rideCompleteDriverCarCategory=[dictWalker valueForKey:@"car_model"];
                                    }
                                    rideCompleteDriverCarNumber=[dictWalker valueForKey:@"car_number"];
                                    rideCompleteDriverName=_currentStartRideDetailName.text;
                                     [pref setBool:YES forKey:PREF_SETTING_REQUEST_ID_STATUS];  //  presented modally so can be dismissed
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        if (searchController) {
                                            ALog(@"search controller is initialized");
                                            [searchController dismissViewControllerAnimated:NO completion:^{
                                                ALog(@"REMOVED SEARCH VIEW CONTROLLER NOW");
                                            }];
                                        }
                                        [self performSegueWithIdentifier:STRING_SEGUE_RIDE_COMPLETE sender:self];
                                        
                                    });
                                    
                                    return ;
                                    
                                });
                                
                            } else {
                                _currentDestinationSearchTxt.enabled=NO;
                                _currentSearchBar.enabled=NO;
                                
                                //Cancel ride button
                                _currentStartRideDetailCancelView.userInteractionEnabled = YES;
                                _currentStartRideCancelLbl.textColor=[UIColor blackColor];
                                _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_icon"];
                                
                                strForCurLatitude=[response valueForKey:@"latitude"];
                                strForCurLongitude=[response valueForKey:@"longitude"];
                                isLater=[[response valueForKey:@"is_later"] intValue];
                                strForSourceAddress = [response valueForKey:@"source_address"];
                                
                                if(![[response valueForKey:@"latitude"] isEqualToString:@""] && ![[response valueForKey:@"longitude"] isEqualToString:@""]) {
                                    if (markerOwner == nil) {
                                        markerOwner = [[GMSMarker alloc] init];
                                        markerOwner.position = CLLocationCoordinate2DMake([[response valueForKey:@"latitude"] doubleValue], [[response valueForKey:@"longitude"] doubleValue]);
                                        markerOwner.groundAnchor = CGPointMake(0.3, 0.7);
                                        UIImage *markerIcon =  [UIImage imageNamed:@"mapPin"];
                                        //                                    [GMSMarker markerImageWithColor:[UIColor redColor]];
                                        //                                    [UIImage imageNamed:@"mapPin"];
                                        markerIcon = [markerIcon imageWithAlignmentRectInsets:UIEdgeInsetsMake((markerIcon.size.width/2), 0, 0, 0)];
                                        markerOwner.icon = markerIcon;
                                        markerOwner.map = mapView_;
                                    }
                                }
                                strForDestinationAddress = [response valueForKey:@"destination_address"];
                                if((![[response valueForKey:@"dest_latitude"] isEqualToString:@""] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@""]) && (![[response valueForKey:@"dest_latitude"] isEqualToString:@"0"] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@"0"])){
                                    if (markerOwnerDest == nil) {
                                        markerOwnerDest = [[GMSMarker alloc] init];
                                        markerOwnerDest.position = CLLocationCoordinate2DMake([[response valueForKey:@"dest_latitude"] doubleValue], [[response valueForKey:@"dest_longitude"] doubleValue]);
                                        markerOwnerDest.icon = [UIImage imageNamed:@"mapPindest"];
                                        markerOwnerDest.map = mapView_;
                                    }
                                }else {
                                        markerOwnerDest.map = nil;
                                        markerOwnerDest = nil;
                                    
                                    ALog(@"destination is cleared");
                                }
                                
                                
                                
                                //strForSourceAddress = [response valueForKey:@"source_address"];
                                _currentSearchBar.text = [response valueForKey:@"source_address"];
                                //strForDestinationAddress = [response valueForKey:@"destination_address"];
                                _currentDestinationSearchTxt.text = [response valueForKey:@"destination_address"];
                                dictWalker=[response valueForKey:@"walker"];
                                _currentStartRideName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                                _currentStartRideDetailName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                                [_currentStartRideIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                                [_currentStartRideDetailIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                                
                                if ([[dictWalker valueForKey:@"sec_car_model"] length] > 1) {
                                    _currentStartRideDetailCarType.text=[dictWalker objectForKey:@"sec_car_model"];
                                    _currentStartRideCarType.text=[dictWalker objectForKey:@"sec_car_model"];
                                }else{
                                   _currentStartRideDetailCarType.text=[dictWalker objectForKey:@"car_model"];
                                    _currentStartRideCarType.text=[dictWalker objectForKey:@"car_model"];
                                }
                                
                                
                                
                                _currentStartRideCarNumber.text=[dictWalker objectForKey:@"car_number"];
                                _currentStartRideDetailCarNumber.text=[dictWalker objectForKey:@"car_number"];
                                
                                self.currentStartRideRatingView.delegate = self;
                                self.currentStartRideRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                                self.currentStartRideRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                                self.currentStartRideRatingView.contentMode = UIViewContentModeScaleAspectFill;
                                self.currentStartRideRatingView.maxRating = 5;
                                self.currentStartRideRatingView.minRating = 0;
                                self.currentStartRideRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                                self.currentStartRideRatingView.editable = NO;
                                self.currentStartRideRatingView.halfRatings = NO;
                                self.currentStartRideRatingView.floatRatings = YES;
                                _currentStartRideRating.text=[dictWalker objectForKey:@"rating"];
                                
                                self.currentStartRideDetailRatingView.delegate = self;
                                self.currentStartRideDetailRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                                self.currentStartRideDetailRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                                self.currentStartRideDetailRatingView.contentMode = UIViewContentModeScaleAspectFill;
                                self.currentStartRideDetailRatingView.maxRating = 5;
                                self.currentStartRideDetailRatingView.minRating = 0;
                                self.currentStartRideDetailRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                                self.currentStartRideDetailRatingView.editable = NO;
                                self.currentStartRideDetailRatingView.halfRatings = NO;
                                self.currentStartRideDetailRatingView.floatRatings = YES;
                                _currentStartRideDetailRating.text=[dictWalker objectForKey:@"rating"];
                                
                                strForWalkerPhone=[dictWalker objectForKey:@"phone"];
                                
                                //mapView
                                //[mapView_ clear];
                                if ([[response valueForKey:@"is_cancelled"] intValue]!=0) {
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        _currentDriverCallBigView.hidden=YES;
                                        _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                                        _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                                        _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                                        _currentCancelAlertBigView.hidden=YES;
                                        [timerForCheckReqStatus invalidate];
                                        timerForCheckReqStatus = nil;
                                        if (searchController) {
                                            
                                                [searchController dismissViewControllerAnimated:NO completion:^{
                                                    ALog(@"SEARCH PAGE IS CLOSED NOW");
                                                }];
                                        }
                                        if([[response valueForKey:@"payment_mode"] intValue] != 0){
                                            
                                            if([[response valueForKey:@"cancelled_by"] intValue] == 1){
                                                [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_DRIVER view:self.view]];
                                                customAlertView.tag=101;
                                                [customAlertView show];
                                            } else {
                                                [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_IS_CANCELLED_200 view:self.view]];
                                                customAlertView.tag=101;
                                                [customAlertView show];
                                            }
                                            
                                        } else {
                                            if([[response valueForKey:@"is_paid"] intValue] != 0 && [[response valueForKey:@"total_amount"] intValue] != 0){
                                                NSMutableDictionary *cancelDict = [[NSMutableDictionary alloc] init];
                                                [cancelDict setObject:[response valueForKey:@"total"] forKey:@"cancel_amount"];
                                                [cancelDict setObject:[response valueForKey:@"trip_id"]  forKey:@"trip_id"];
                                                [cancelDict setObject:[response valueForKey:@"walker"] forKey:@"walker_data"];
                                                [cancelDict setObject:[response valueForKey:@"request_start_date"] forKey:@"cancellation_date"];
                                                [cancelDict setObject:[response valueForKey:@"request_start_time"] forKey:@"cancellation_time"];
                                                [cancelDict setObject:[response valueForKey:@"payment_type_content"] forKey:@"payment_type"];
                                                [cancelDict setObject:[response valueForKey:@"payment_description"] forKey:@"payment_description"];
                                                [cancelDict setObject:[response  valueForKey:@"payment_mode"] forKey:@"payment_mode"];
                                                [cancelDict setObject:[response valueForKey:@"payment_message"] forKey:@"payment_message"];
                                                if([[response valueForKey:@"cancelled_by"] intValue] == 1){
                                                    [cancelDict setValue:@YES forKey:@"is_driver"];
                                                } else {
                                                    [cancelDict setValue:@YES forKey:@"is_admin"];
                                                }
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    [self showCancelledTripAmountPaidScreenWithresponse:cancelDict AndShowAlert:YES];
                                                });
                                                
                                            }else if ([[response valueForKey:@"total_amount"] intValue] == 0){
                                                if([[response valueForKey:@"cancelled_by"] intValue] == 1){
                                                    [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_DRIVER view:self.view]];
                                                    customAlertView.tag=101;
                                                    [customAlertView show];
                                                } else {
                                                    [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_IS_CANCELLED_200 view:self.view]];
                                                    customAlertView.tag=101;
                                                    [customAlertView show];
                                                }
                                            }
                                            
                                        }
                                    });
                                }else{
                                    if([[response valueForKey:@"is_walker_started"] intValue]!=0){
                                        _lymoArrivingLbl.text=@"Orbit Arriving";
                                    }
                                    
                                    if([[response valueForKey:@"is_walker_arrived"] intValue]!=0){
                                        _lymoArrivingLbl.text=@"Orbit Arrived";
                                    }
                                    
                                    if([[response valueForKey:@"is_walk_started"] intValue]!=0){
                                        _lymoArrivingLbl.text=@"Trip Started";
                                        _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                                        _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                                        _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                                        _currentCancelAlertBigView.hidden=YES;
                                        [arrPath removeAllObjects];
                                        arrPath=[[response valueForKey:@"locationdata"] mutableCopy];
                                        
                                        if ([arrPath count] > 0) {
                                            animationTime=getRequestCallTime/arrPath.count;
                                            [timerForCheckReqStatus invalidate];
                                            timerForCheckReqStatus = nil;
                                            strForLatLongID=[[arrPath lastObject] valueForKey:@"id"];
                                            [self drawPath];
                                            /*************/
                                        } else {
                                            if (timerForCheckReqStatus == nil) {
                                                [self setTimerToCheckDriverStatus];
                                            }
                                        }
                                        
                                        ALog(@"The location data is %@", arrPath);
                                        
                                        // landing page code completed
                                        
                                        
                                    }else{
                                        //mapView
                                        //[mapView_ clear];
                                        CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[dictWalker valueForKey:@"latitude"]doubleValue],[[dictWalker valueForKey:@"longitude"]doubleValue]);                                    double bearing = [[dictWalker valueForKey:@"bearing"]doubleValue];
                                        if (driver_marker == nil) {
                                            driver_marker = [GMSMarker markerWithPosition:coordinates];
                                            driver_marker.icon=driverCarIcon;
                                        }
                                        driver_marker.map = mapView_;
                                        [CATransaction begin];
                                        [CATransaction setAnimationDuration:2.0];
                                        driver_marker.position = coordinates;
                                        driver_marker.rotation = bearing;
                                        [CATransaction commit];
                                    }
                                }
                            }
                        }
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self] ;;
                    }else{
                        ALog(@"ge request response is not success the response =  %@", response);
                        if ([[response valueForKey:@"is_cancelled"] boolValue]) {
                            [timerForCheckReqStatus invalidate];
                            timerForCheckReqStatus = nil;
                            [self currentBackBtn:self];
                        }
                        
                    }
                }
            }else {
                ALog(@" +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ this is not going inside");
            }
        }];
    }
    else
    {
        [timerForCheckReqStatus invalidate];
        timerForCheckReqStatus = nil;
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}




-(void)checkForDummyRequestStatus
{
    if([APPDELEGATE connected]){
//        NSString *strReqId=[pref objectForKey:PREF_REQ_ID];
        NSString *strReqId= @"11933";
        NSString *strForUrl=[NSString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@&%@=%@&%@=%@",@"getdummyrequest",PARAM_ID,[pref objectForKey:PREF_USER_ID],PARAM_TOKEN,[pref objectForKey:PREF_USER_TOKEN],PARAM_REQUEST_ID,strReqId,PARAM_LAST_WALKER_ID,strForLatLongID,PARAM_LYMO_DEVICE_ID,[pref objectForKey:PREF_LYMO_DEVICE_ID]];
        
        // NSString *strForUrl=[NSString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@",FILE_GET_REQUEST,PARAM_ID,@"222",PARAM_TOKEN,@"2y10a5RMW0Z3TuJkScXEh0QdokzroiO4cTW6L9lLYsYV9BFe28DJ6lS",PARAM_REQUEST_ID,strReqId];
        
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
        [afn getDataFromPath:strForUrl withParamData:nil withBlock:^(id response, NSError *error){
            if(isResponse){
                if (response == Nil){
//                    [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
                    //                    [customAlertView show];
                }else if (response){
                    if([[response valueForKey:@"success"]boolValue] && [[response valueForKey:@"status"] intValue]) {
                        ALog(@"GET REQ with lastWalkId = %@ --->%@",strForLatLongID, response);
                        if([[response valueForKey:@"status"] intValue]!=0){
                            if([[response valueForKey:@"is_completed"] intValue]!=0){
                                isResponse = NO;
                                [timerForCheckReqStatus invalidate];
                                timerForCheckReqStatus = nil;
                                _lymoArrivingLbl.text=@"Trip Ended";
                                _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                                _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                                _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                                _currentCancelAlertBigView.hidden=YES;
                                dispatch_once(&onceToken, ^{
                                    _lymoArrivingLbl.text=@"Trip Ended";
                                    timerIsStopped=YES;
                                    [timerForCheckReqStatus invalidate];
                                    timerForCheckReqStatus = nil;
                                    ALog(@"The trip is ended showing ride complete here---------------********---------");
                                    dictWalker=[response valueForKey:@"walker"];
                                    rideCompleteTripID=[response valueForKey:@"trip_id"];
                                    rideCompleteDate=[response valueForKey:@"request_end_date"];
                                    rideCompleteCarCatorgery=[dictWalker valueForKey:@"type_name"];
                                    rideCompleteTime=[response valueForKey:@"request_end_time"];
                                    rideCompletePayment=[response valueForKey:@"payment_type_content"];
                                    rideCompletePrice=[response valueForKey:@"total"];
                                    rideCompleteMessage=[response valueForKey:@"payment_description"];
                                    rideCompleteDriveIcon=[dictWalker valueForKey:@"picture"];
                                    rideCompleteDriverCarCategory=[dictWalker valueForKey:@"car_model"];
                                    rideCompleteDriverCarNumber=[dictWalker valueForKey:@"car_number"];
                                    rideCompleteDriverName=_currentStartRideDetailName.text;
                                    [pref setBool:YES forKey:PREF_SETTING_REQUEST_ID_STATUS];  //  presented modally so can be dismissed
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                    [self performSegueWithIdentifier:STRING_SEGUE_RIDE_COMPLETE sender:self];
                                    });
                                    return ;
                                    
                                });
                                
                            } else {
                                _currentDestinationSearchTxt.enabled=NO;
                                _currentSearchBar.enabled=NO;
                                
                                //Cancel ride button
                                _currentStartRideDetailCancelView.userInteractionEnabled = YES;
                                _currentStartRideCancelLbl.textColor=[UIColor blackColor];
                                _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_icon"];
                                
                                strForCurLatitude=[response valueForKey:@"latitude"];
                                strForCurLongitude=[response valueForKey:@"longitude"];
                                
                                strForSourceAddress = [response valueForKey:@"source_address"];
                                if(![[response valueForKey:@"latitude"] isEqualToString:@""] && ![[response valueForKey:@"longitude"] isEqualToString:@""]){
                                    
                                    UIImage *markerIcon =  [UIImage imageNamed:@"mapPin"];
                                    //                                    [GMSMarker markerImageWithColor:[UIColor redColor]];
                                    //                                    [UIImage imageNamed:@"mapPin"];
                                    markerIcon = [markerIcon imageWithAlignmentRectInsets:UIEdgeInsetsMake((markerIcon.size.width/2), 0, 0, 0)];
                                    if (markerOwner == nil) {
                                        markerOwner = [[GMSMarker alloc] init];
                                        markerOwner.position = CLLocationCoordinate2DMake([[response valueForKey:@"latitude"] doubleValue], [[response valueForKey:@"longitude"] doubleValue]);
                                        markerOwner.groundAnchor = CGPointMake(0.3, 0.7);
                                        markerOwner.icon = markerIcon;
                                        markerOwner.map = mapView_;
                                    }
                                }
                                strForDestinationAddress = [response valueForKey:@"destination_address"];
                                if((![[response valueForKey:@"dest_latitude"] isEqualToString:@""] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@""]) && (![[response valueForKey:@"dest_latitude"] isEqualToString:@"0"] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@"0"])){
                                    if (markerOwnerDest == nil) {
                                        markerOwnerDest = [[GMSMarker alloc] init];
                                        markerOwnerDest.position = CLLocationCoordinate2DMake([[response valueForKey:@"dest_latitude"] doubleValue], [[response valueForKey:@"dest_longitude"] doubleValue]);
                                        markerOwnerDest.icon = [UIImage imageNamed:@"mapPindest"];
                                        markerOwnerDest.map = mapView_;
                                    }
                                }else {
                                    if (markerOwnerDest) {
                                        markerOwnerDest.map = nil;
                                        markerOwnerDest=nil;
                                    }
                                }
                                
                                
                                //strForSourceAddress = [response valueForKey:@"source_address"];
                                _currentSearchBar.text = [response valueForKey:@"source_address"];
                                //strForDestinationAddress = [response valueForKey:@"destination_address"];
                                _currentDestinationSearchTxt.text = [response valueForKey:@"destination_address"];
                                dictWalker=[response valueForKey:@"walker"];
                                _currentStartRideName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                                _currentStartRideDetailName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                                [_currentStartRideIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                                [_currentStartRideDetailIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                                _currentStartRideDetailCarType.text=[dictWalker objectForKey:@"car_model"];
                                _currentStartRideCarType.text=[dictWalker objectForKey:@"car_model"];
                                _currentStartRideCarNumber.text=[dictWalker objectForKey:@"car_number"];
                                _currentStartRideDetailCarNumber.text=[dictWalker objectForKey:@"car_number"];
                                
                                self.currentStartRideRatingView.delegate = self;
                                self.currentStartRideRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                                self.currentStartRideRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                                self.currentStartRideRatingView.contentMode = UIViewContentModeScaleAspectFill;
                                self.currentStartRideRatingView.maxRating = 5;
                                self.currentStartRideRatingView.minRating = 0;
                                self.currentStartRideRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                                self.currentStartRideRatingView.editable = NO;
                                self.currentStartRideRatingView.halfRatings = NO;
                                self.currentStartRideRatingView.floatRatings = YES;
                                _currentStartRideRating.text=[dictWalker objectForKey:@"rating"];
                                
                                self.currentStartRideDetailRatingView.delegate = self;
                                self.currentStartRideDetailRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                                self.currentStartRideDetailRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                                self.currentStartRideDetailRatingView.contentMode = UIViewContentModeScaleAspectFill;
                                self.currentStartRideDetailRatingView.maxRating = 5;
                                self.currentStartRideDetailRatingView.minRating = 0;
                                self.currentStartRideDetailRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                                self.currentStartRideDetailRatingView.editable = NO;
                                self.currentStartRideDetailRatingView.halfRatings = NO;
                                self.currentStartRideDetailRatingView.floatRatings = YES;
                                _currentStartRideDetailRating.text=[dictWalker objectForKey:@"rating"];
                                
                                strForWalkerPhone=[dictWalker objectForKey:@"phone"];
                                
                                //mapView
                                //[mapView_ clear];
                                
                                if([[response valueForKey:@"is_walker_started"] intValue]!=0){
                                    _lymoArrivingLbl.text=@"Orbit Arriving";
                                }
                                
                                if([[response valueForKey:@"is_walker_arrived"] intValue]!=0){
                                    _lymoArrivingLbl.text=@"Orbit Arrived";
                                }
                                
                                if ([strForLatLongID isEqualToString:@"0"]) {
                                    [mapView_ clear];
                                    driver_marker=nil;
                                    markerOwner=nil;
                                    markerOwnerDest=nil;
                                    if(![[response valueForKey:@"latitude"] isEqualToString:@""] && ![[response valueForKey:@"longitude"] isEqualToString:@""]){
                                        
                                        CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[response valueForKey:@"latitude"] doubleValue], [[response valueForKey:@"longitude"] doubleValue]);
                                        
                                        //                                    double bearing = [[dictWalker valueForKey:@"bearing"]doubleValue];
                                        markerOwner = [GMSMarker markerWithPosition:coordinates];
                                        //                                        markerOwner.icon=[GMSMarker markerImageWithColor:[UIColor redColor]]; // commented on 18072016
                                        markerOwner.icon=[UIImage imageNamed:@"mapPin"];
                                        //                                        [UIImage imageNamed:@"mapPin"];
                                        markerOwner.map = mapView_;
                                        markerOwner.position = coordinates;
                                    }
                                    
                                    if((![[response valueForKey:@"dest_latitude"] isEqualToString:@""] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@""]) && (![[response valueForKey:@"dest_latitude"] isEqualToString:@"0"] && ![[response valueForKey:@"dest_longitude"] isEqualToString:@"0"])){
                                        
                                        CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[response valueForKey:@"dest_latitude"] doubleValue], [[response valueForKey:@"dest_longitude"] doubleValue]);
                                        markerOwnerDest = [GMSMarker markerWithPosition:coordinates];
                                        markerOwnerDest.icon=[UIImage imageNamed:@"mapPindest"];
                                        markerOwnerDest.map = mapView_;
                                        markerOwnerDest.position = coordinates;
                                    }
                                }
                                
                                
                                if([[response valueForKey:@"is_walk_started"] intValue]!=0){
                                    _lymoArrivingLbl.text=@"Trip Started";
                                    _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                                    _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                                    _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                                    _currentCancelAlertBigView.hidden=YES;
                                    
                                    [arrPath removeAllObjects];
                                    arrPath=[[response valueForKey:@"locationdata"] mutableCopy];
                                    if ([arrPath count] > 1) {
                                        if (arrPath.count>1) {
                                            animationTime=getRequestCallTime/arrPath.count;
                                        }else{
                                            animationTime=0.2;
                                        }
                                        [timerForCheckReqStatus invalidate];
                                        timerForCheckReqStatus = nil;
                                        strForLatLongID=[[arrPath lastObject] valueForKey:@"id"];
                                        [self drawPath];
                                    } else {
                                        [timerForCheckReqStatus invalidate];
                                        timerForCheckReqStatus = nil;
                                        [self performSelector:@selector(setTimerToCheckDriverStatus) withObject:nil afterDelay:getRequestCallTime];
                                    }
                                    
                                    ALog(@"The location data is %@", arrPath);
                                    
                                    // landing page code completed
                                    
                                    
                                }else{
                                    //mapView
                                    //[mapView_ clear];
                                    CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[dictWalker valueForKey:@"latitude"]doubleValue],[[dictWalker valueForKey:@"longitude"]doubleValue]);                                    double bearing = [[dictWalker valueForKey:@"bearing"]doubleValue];
                                    if (driver_marker == nil) {
                                        driver_marker = [GMSMarker markerWithPosition:coordinates];
                                        driver_marker.icon=driverCarIcon;
                                        
                                    }
                                        driver_marker.map = mapView_;
                                        [CATransaction begin];
                                        [CATransaction setAnimationDuration:2.0];
                                        driver_marker.position = coordinates;
                                        driver_marker.rotation = bearing;
                                        [CATransaction commit];
                                }
                            }
                        }
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self] ;;
                    }
                }
            }
        }];
    }
    else
    {
        [timerForCheckReqStatus invalidate];
        timerForCheckReqStatus = nil;
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Draw Completed Route Methods

-(void)requestPath
{
    NSString *strForUserId=[pref objectForKey:PREF_USER_ID];
    NSString *strForUserToken=[pref objectForKey:PREF_USER_TOKEN];
    NSString *strReqId=[pref objectForKey:PREF_REQ_ID];
    if ([APPDELEGATE connected]) {
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        NSMutableString *pageUrl=[NSMutableString stringWithFormat:@"%@?%@=%@&%@=%@&%@=%@&%@=%@",FILE_REQUEST_PATH,PARAM_ID,strForUserId,PARAM_TOKEN,strForUserToken,PARAM_REQUEST_ID,strReqId,PARAM_LYMO_DEVICE_ID,[pref objectForKey:PREF_LYMO_DEVICE_ID]];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
        [afn getDataFromPath:pageUrl withParamData:nil withBlock:^(id response, NSError *error)
         {
             ALog(@"completed path  Data= %@",response);
             if (response == Nil){
                 
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [APPDELEGATE stopLoader:self.view];
                     [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                 });
                 [self currentBackBtn:self];
             }else if (response)
             {
                 dictWalker=[response valueForKey:@"walker"];
                 [mapView_ clear];
                 driver_marker=nil;
                 markerOwner=nil;
                 markerOwnerDest=nil;
                 if([[response valueForKey:@"is_walker_started"] intValue]!=0){
                     _lymoArrivingLbl.text=@"Orbit Arriving";
                 }
                 
                 if([[response valueForKey:@"is_walker_arrived"] intValue]!=0){
                     _lymoArrivingLbl.text=@"Orbit Arrived";
                 }
                 
                 if([[response valueForKey:@"is_walk_started"] intValue]!=0){
                     _lymoArrivingLbl.text=@"Trip Started";
                     _currentStartRideDetailCancelView.userInteractionEnabled = NO;
                     _currentStartRideCancelLbl.textColor=[UIColor lightGrayColor];
                     _currentStartRideCancelIcon.image=[UIImage imageNamed:@"Cancel_gray"];
                     _currentCancelAlertBigView.hidden=YES;
                 }
                 
                 NSString *idString = [dictWalker valueForKey:@"type"];
                 if ([idString isEqualToString:@"1"] || [idString isEqualToString:@"5"]) {
                     driverCarIcon=[UIImage imageNamed:@"Saloon"];
                 }else if ([idString isEqualToString:@"2"]  || [idString isEqualToString:@"6"]) {
                     driverCarIcon=[UIImage imageNamed:@"Mini"];
                 }else if ([idString isEqualToString:@"3"]) {
                     driverCarIcon=[UIImage imageNamed:@"MiniBus16"];
                 }else if ([idString isEqualToString:@"4"]) {
                     driverCarIcon=[UIImage imageNamed:@"Executive"];
                 }else {
                     driverCarIcon=[UIImage imageNamed: @"Executive"];
                 }
                     driver_marker.icon=driverCarIcon;
                     driver_marker.map = mapView_;
                 strForSourceAddress = [response valueForKey:@"source_address"];
                 isLater=[[response valueForKey:@"is_later"] intValue];
                 strForDestinationAddress = [response valueForKey:@"destination_address"];
                 //strForSourceAddress = [response valueForKey:@"source_address"];
                 _currentSearchBar.text = [response valueForKey:@"source_address"];
                 //strForDestinationAddress = [response valueForKey:@"destination_address"];
                 _currentDestinationSearchTxt.text = [response valueForKey:@"destination_address"];
                 dictWalker=[response valueForKey:@"walker"];
                 _currentStartRideName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                 _currentStartRideDetailName.text=[NSString stringWithFormat:@"%@ %@",[dictWalker objectForKey:@"first_name"],[dictWalker objectForKey:@"last_name"]];
                 [_currentStartRideIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                 [_currentStartRideDetailIcon downloadFromURL:[dictWalker objectForKey:@"picture"] withOutLoader:nil];
                 if ([[dictWalker valueForKey:@"sec_car_model"] length] > 1) {
                     _currentStartRideDetailCarType.text=[dictWalker objectForKey:@"sec_car_model"];
                     _currentStartRideCarType.text=[dictWalker objectForKey:@"sec_car_model"];
                 }else{
                     _currentStartRideDetailCarType.text=[dictWalker objectForKey:@"car_model"];
                     _currentStartRideCarType.text=[dictWalker objectForKey:@"car_model"];
                 }
                 _currentStartRideCarNumber.text=[dictWalker objectForKey:@"car_number"];
                 _currentStartRideDetailCarNumber.text=[dictWalker objectForKey:@"car_number"];
                 
                 self.currentStartRideRatingView.delegate = self;
                 self.currentStartRideRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                 self.currentStartRideRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                 self.currentStartRideRatingView.contentMode = UIViewContentModeScaleAspectFill;
                 self.currentStartRideRatingView.maxRating = 5;
                 self.currentStartRideRatingView.minRating = 0;
                 self.currentStartRideRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                 self.currentStartRideRatingView.editable = NO;
                 self.currentStartRideRatingView.halfRatings = NO;
                 self.currentStartRideRatingView.floatRatings = YES;
                 _currentStartRideRating.text=[dictWalker objectForKey:@"rating"];
                 
                 self.currentStartRideDetailRatingView.delegate = self;
                 self.currentStartRideDetailRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                 self.currentStartRideDetailRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                 self.currentStartRideDetailRatingView.contentMode = UIViewContentModeScaleAspectFill;
                 self.currentStartRideDetailRatingView.maxRating = 5;
                 self.currentStartRideDetailRatingView.minRating = 0;
                 self.currentStartRideDetailRatingView.rating = [[dictWalker objectForKey:@"rating"] floatValue];
                 self.currentStartRideDetailRatingView.editable = NO;
                 self.currentStartRideDetailRatingView.halfRatings = NO;
                 self.currentStartRideDetailRatingView.floatRatings = YES;
                 _currentStartRideDetailRating.text=[dictWalker objectForKey:@"rating"];
                 
                 strForWalkerPhone=[dictWalker objectForKey:@"phone"];
                 
                 if([[response valueForKey:@"success"] intValue]==1)
                 {
                     ALog(@"the completed path is success so drawing completed path");
                     [arrPath removeAllObjects];
                     if ([[[response valueForKey:@"locationdata"] lastObject] valueForKey:@"id"]) {
                         strForLatLongID=[[[response valueForKey:@"locationdata"] lastObject] valueForKey:@"id"];
                     }
                     //                 arrPath=[[response valueForKey:@"locationdata"] mutableCopy];
                     //                 [self drawCompletedPath];
                     [self setTimerToCheckDriverStatus];
                 } else {
                     [self setTimerToCheckDriverStatus];
                 }
             }
             
         }];
    }
}

-(void)drawCompletedPath {
    NSMutableDictionary *dictPath=[[NSMutableDictionary alloc]init];
    NSString *templati,*templongi;
    if ([arrPath count]) {
        if ([[arrPath lastObject] valueForKey:@"id"]) {
            strForLatLongID=[[arrPath lastObject] valueForKey:@"id"];
        }
        
        for (int i=0; i<arrPath.count; i++)
        {
            dictPath=[arrPath objectAtIndex:i];
            templati=[dictPath valueForKey:@"latitude"];
            templongi=[dictPath valueForKey:@"longitude"];
            
            CLLocationCoordinate2D current;
            current.latitude=[templati doubleValue];
            current.longitude=[templongi doubleValue];
            [mapView_ clear];
            [pathpoliline addCoordinate:current];
            
            GMSPolyline *polyLinePath = [GMSPolyline polylineWithPath:pathpoliline];
            polyLinePath.strokeColor = [UIColor colorWithRed:(27.0f/255.0f) green:(151.0f/255.0f) blue:(200.0f/255.0f) alpha:1.0];
            polyLinePath.strokeWidth = 5.f;
            polyLinePath.geodesic = YES;
            polyLinePath.map = mapView_;
            
        }
        
        [self setTimerToCheckDriverStatus];
    } else {
        [self setTimerToCheckDriverStatus];
        return;
    }
    
    [APPDELEGATE stopLoader:self.view];
}

- (UIImage*)saveImageWithUrl: (NSString*) urlString
{
    
    NSCharacterSet *notAllowedChars = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"] invertedSet];
    
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
    UIImage * image = [UIImage imageWithData:data];
    
    //    [self image:image scaledToSize:CGSizeMake(18.0, 38.0)];
    if (image != nil)
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                             NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString* path = [documentsDirectory stringByAppendingPathComponent:
                          [NSString stringWithString: [[urlString componentsSeparatedByCharactersInSet:notAllowedChars] componentsJoinedByString:@""]]];
        ALog(@"file path for saving = %@", path);
        NSData* data =UIImagePNGRepresentation(image);
        ALog(@"-----the size of image while saving  = %@", NSStringFromCGSize([UIImage imageWithData:data].size));
        ALog(@"saving image at path %@", path);
        [data writeToFile:path atomically:YES];
    }
    
    if (image.size.width/3.0 > 18.0 || image.size.height/3.0 > 38.0) {
        image = [UIImage image:image scaledToNewSize:CGSizeMake(image.size.width / 3.0, image.size.height/3.0)];
    } else {
        image = [UIImage image:image scaledToNewSize:CGSizeMake(18.0, 38.0)];
    }
    return image;
}


- (UIImage*)loadImageWithURL : (NSString *)urlString
{
    ALog(@"start loading image named %@", urlString);
    NSCharacterSet *notAllowedChars = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"] invertedSet];
    UIImage* image = nil;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString* path = [documentsDirectory stringByAppendingPathComponent:
                      [NSString stringWithString: [[urlString componentsSeparatedByCharactersInSet:notAllowedChars] componentsJoinedByString:@""]]];
    ALog(@"file path for checking = %@", path);
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:path];
    if (fileExists) {
        ALog(@"image is present at file path %@", path);
        UIImage *actualImage = [UIImage imageWithContentsOfFile:path];
        if (actualImage.size.width/3.0 > 18.0 || actualImage.size.height/3.0 > 38.0 ) {
            image = [UIImage image:actualImage scaledToNewSize:CGSizeMake(actualImage.size.width / 3.0, actualImage.size.height/3.0)];
        } else {
            image = [UIImage image:actualImage scaledToNewSize:CGSizeMake(18.0, 38.0)];
        }
        ALog(@"the size ofsaved image = %@",NSStringFromCGSize(image.size));
    }else {
        ALog(@"ohhhhhhh image is not saved so save now at path %@", path);
        image = [self saveImageWithUrl:urlString];
    }
    
    return image;
}



#pragma mark - Move car and Draw Ongoing Route Methods


-(void)drawPath
{
    ALog(@"total number of coordinates are %lu", (unsigned long)arrPath.count);
    if ([arrPath count]) {
        [self moveCarWithAnimationToTheCoordinateWithBearing:[arrPath firstObject]];
    } else {
        if (timerIsStopped) {
            if (timerForCheckReqStatus) {
                [timerForCheckReqStatus invalidate];
                timerForCheckReqStatus = nil;
            }
            
        }else {
            [self checkForRequestStatus];
//            [self checkForDummyRequestStatus];
        }
    }
}


//-(void)moveCarWithAnimationToTheCoordinateWithBearing: (NSDictionary*) newCoordinate {
//    CLLocation *loc = [[CLLocation alloc] initWithLatitude:[[newCoordinate valueForKey:@"latitude"]doubleValue] longitude:[[newCoordinate valueForKey:@"longitude"]doubleValue]];
//    CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[newCoordinate valueForKey:@"latitude"]doubleValue],[[newCoordinate valueForKey:@"longitude"]doubleValue]);
//    double bearing = [[newCoordinate valueForKey:@"bearing"]doubleValue];
//    //    bearing = [self getHeadingForDirectionFromCoordinate:fromLatLongForBearing toCoordinate:ToLatLongForBearing];
//    NSString *templati,*templongi;
//    templati=[newCoordinate valueForKey:@"latitude"];
//    templongi=[newCoordinate valueForKey:@"longitude"];
//    CLLocationCoordinate2D current;
//    current.latitude=[templati doubleValue];
//    current.longitude=[templongi doubleValue];
//    [pathpoliline addCoordinate:current];
//    GMSPolyline *polyLinePath = [GMSPolyline polylineWithPath:pathpoliline];
//    polyLinePath.strokeColor = [UIColor orbitYellowColor];
//    polyLinePath.strokeWidth = 5.f;
//    polyLinePath.geodesic = YES;
//    
//    if (driver_marker == nil) {
//        driver_marker = [GMSMarker markerWithPosition:coordinates];
//        driver_marker.icon=[UIImage imageNamed:@"pin_driver"];
//        driver_marker.map = mapView_;
//    } else {
//        [CATransaction begin];
//        [CATransaction setValue:[NSNumber numberWithFloat: animationTime] forKey:kCATransactionAnimationDuration];
//        [CATransaction setCompletionBlock:^{
//            [self RemoveFirstObjectCallDrawPathAgain:newCoordinate];
//        }];
//        driver_marker.position = coordinates;
//        driver_marker.rotation = bearing;
//        if (round(bearing) != 0) {
//            driver_marker.rotation = bearing;
//        }
//        [self focusOnCoordinate:coordinates];
//        [CATransaction commit];
//    }
//}



-(void)moveCarWithAnimationToTheCoordinateWithBearing: (NSDictionary*) newCoordinate {
    
    CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake([[newCoordinate valueForKey:@"latitude"]doubleValue],[[newCoordinate valueForKey:@"longitude"]doubleValue]);
    
    [pathpoliline addCoordinate:coordinates];
//    GMSPolyline *polyLinePath = [GMSPolyline polylineWithPath:pathpoliline];
//    polyLinePath.strokeColor = [UIColor orbitYellowColor];
//    polyLinePath.strokeWidth = 5.f;
//    polyLinePath.geodesic = YES;
    
    if (driver_marker == nil) {
        ALog(@"---------------->>>>>>The drivermarker is nil so creating new driver in location %f, %f", coordinates.latitude, coordinates.longitude);
        driver_marker = [GMSMarker markerWithPosition:coordinates];
        driver_marker.icon=driverCarIcon;
    }
    //        ALog(@"---------------->>>>>>The drivermarker is already created in location %f, %f", coordinates.latitude, coordinates.longitude);
    driver_marker.map = mapView_;
    [CATransaction begin];
    if (!animationTime) {
        animationTime=0.2f;
    }
    [CATransaction setValue:[NSNumber numberWithFloat: animationTime] forKey:kCATransactionAnimationDuration];
    [CATransaction setCompletionBlock:^{
//        polyLinePath.map=mapView_;
        [self RemoveFirstObjectCallDrawPathAgain:newCoordinate];
    }];
    driver_marker.position = coordinates;
    double bearing = [[newCoordinate valueForKey:@"bearing"]doubleValue];
    ALog(@"Bearing is = %f, coordinates = %f, %f", bearing, coordinates.latitude, coordinates.longitude);
    if (round(bearing) != 0) {
        driver_marker.rotation = bearing;
    }
    [self focusOnCoordinate:coordinates];
    ALog(@"the current location %f, %f and bearinf = %f", coordinates.latitude, coordinates.longitude,[[newCoordinate valueForKey:@"bearing"]doubleValue]);
    [CATransaction commit];
}




-(void)RemoveFirstObjectCallDrawPathAgain: (NSDictionary*) newCoordinate  {
    if ([arrPath count]) {
        [arrPath removeObjectAtIndex:0];
        //            [arrPath removeObjectsInRange:NSMakeRange(0, MIN(5, arrPath.count))];
    }
    [self drawPath];
}

- (void)focusOnCoordinate:(CLLocationCoordinate2D) coordinate {
    [mapView_ animateToLocation:coordinate];
    //    [mapView_ animateToBearing:0];
    [mapView_ animateToViewingAngle:0];
//    [mapView_ animateToZoom:zoom];
    [mapView_ animateToZoom:16.0];
}

#pragma mark - Rating delegate

- (void)floatRatingView:(TPFloatRatingView *)ratingView ratingDidChange:(CGFloat)rating
{
    ALog(@"%f",rating);
}

#pragma mark - Ride complete  Delegate

-(void) rideCompleteRatingIsGiven:(UIViewController *)sender{
     [self currentBackBtn:self];
}


-(void) cancellationPaymentIsDone:(UIViewController *)sender{
    [self currentBackBtn:self];
}

-(void)showCancelledTripAmountPaidScreenWithresponse : (NSDictionary*) response AndShowAlert: (BOOL)show{
    // the cancelled amount is paid (amount deducted from card automatically or other means) so show ride cancelled screen
    ALog(@"Showing cancel payment screen because ride is cancelled and amount paid from cancelled ride =  %@ .", [response valueForKey:@"cancel_amount"]);
    
    RideCancelledPaymentViewController *rideCancelledVC = [[RideCancelledPaymentViewController alloc] initWithNibName:@"RideCancelledPaymentViewController" bundle:nil];
    rideCancelledVC.rideCancelledDelegate=self;
    
    rideCancelledVC.strRideCompletePrice=[response valueForKey:@"cancel_amount"];
    rideCancelledVC.strRideCompleteTripID=[response valueForKey:@"trip_id"];
    
    rideCancelledVC.strRideCompleteDate=[response valueForKey:@"cancellation_date"];
    rideCancelledVC.strRideCompleteTime=[response valueForKey:@"cancellation_time"];
    rideCancelledVC.strRideCompletePayment=[response valueForKey:@"payment_type"];
    rideCancelledVC.strRideCompleteMessage=[response valueForKey:@"payment_description"];
    if ([response valueForKey:@"walker_data"]) {
        rideCancelledVC.isWalkerDetailsAvailable=YES;
        NSMutableDictionary *currentDictWalker=[response valueForKey:@"walker_data"];
        rideCancelledVC.strRideCompleteCarCatorgery=[currentDictWalker valueForKey:@"car_model"];
        rideCancelledVC.strRideCompleteDriveIcon=[currentDictWalker valueForKey:@"picture"];
        if ([[currentDictWalker valueForKey:@"sec_car_model"] length] > 1) {
            rideCancelledVC.strRideCompleteDriverCarCategory=[currentDictWalker valueForKey:@"sec_car_model"];
        }else {
            rideCancelledVC.strRideCompleteDriverCarCategory=[currentDictWalker valueForKey:@"car_model"];
        }
        
        rideCancelledVC.strRideCompleteDriverCarNumber=[currentDictWalker valueForKey:@"car_number"];
        rideCancelledVC.strRideCompleteDriverName=[NSString stringWithFormat:@"%@ %@",[currentDictWalker objectForKey:@"first_name"],[currentDictWalker objectForKey:@"last_name"]];
    }else {
        ALog(@"walker is not available = %@",[response valueForKey:@"walker_data"]);
        rideCancelledVC.isWalkerDetailsAvailable=NO;
    }
    [self presentViewController:rideCancelledVC animated:YES completion:^{
        [self sendCancelledRequestAmountPaidEmailWithId:[pref objectForKey:PREF_REQ_ID]];
        if (show) {
            if ([response valueForKey:@"is_customer"]) {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_CUSTOMER view:self.view]];
            }else if(([response valueForKey:@"is_driver"])){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_CANCELLED_BY_DRIVER view:self.view]];
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:RIDE_IS_CANCELLED_200 view:self.view]];
            }
            
            customAlertView.tag=101;
            [customAlertView show];
        }
        if (![[response valueForKey:@"payment_mode"] intValue]) {
            [APPDELEGATE showAlertOnTopMostControllerWithText:[response valueForKey:@"payment_message"]];
        }
    }];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
//    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    if (alertView.tag == 1234) {
         _currentDestinationSearchTxt.text = @"";
        customAlertView.tag=1;
    }if (alertView.tag == 101) {
        [self currentBackBtn:self];
    }
    [alertView close];
}


@end
