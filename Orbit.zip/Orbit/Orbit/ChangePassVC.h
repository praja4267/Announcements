//
//  ChangePassVC.h
//  
//
//  Created by Active Mac06 on 17/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface ChangePassVC : UIViewController<CustomIOSAlertViewDelegate,UITextFieldDelegate>
{
    CustomIOSAlertView *customAlertView;
}

// Button
@property (strong, nonatomic) IBOutlet UIButton *BackBtn;
@property (strong, nonatomic) IBOutlet UIButton *DoneBtn;
// Action
- (IBAction)BackBtn:(id)sender;
- (IBAction)Done:(id)sender;
// TextView
@property (strong, nonatomic) IBOutlet UITextField *OldPass_txt;
@property (strong, nonatomic) IBOutlet UITextField *NewPassTxt;
@property (strong, nonatomic) IBOutlet UITextField *RepeatPassTxt;


@end
