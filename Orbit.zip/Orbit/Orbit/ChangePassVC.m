//
//  ChangePassVC.m
//  
//
//  Created by Active Mac06 on 17/12/15.
//
//

#import "ChangePassVC.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"

@interface ChangePassVC ()


@end

@implementation ChangePassVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //Alert view
    
    _OldPass_txt.delegate=self;
    _NewPassTxt.delegate=self;
    _RepeatPassTxt.delegate=self;
    
    [_DoneBtn setExclusiveTouch:YES];
    
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}
-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)Done:(id)sender {
    [self.view endEditing:YES];
    if([APPDELEGATE connected]){
        if(_OldPass_txt.text.length<1 || _NewPassTxt.text.length<1 || _RepeatPassTxt.text.length<1 ){
            if(_OldPass_txt.text.length==0){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_OLD_PASSWORD view:self.view]];
                [customAlertView show];
            }
            else if(_NewPassTxt.text.length==0){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_NEW_PASSWORD view:self.view]];
                [customAlertView show];
            }
            else if(_RepeatPassTxt.text.length==0){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_REPEAT_NEW_PASSWORD view:self.view]];  // @"Please enter all password fileds"
                [customAlertView show];
            }
        }else if([_NewPassTxt.text isEqualToString:_OldPass_txt.text] || [_RepeatPassTxt.text isEqualToString:_OldPass_txt.text]){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_NEW_PASSWORD_NOT_OLD view:self.view]];
            [customAlertView show];  //@"Please enter new password"
        }else{
            if([_NewPassTxt.text isEqualToString:_RepeatPassTxt.text]){
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:_OldPass_txt.text forKey:PARAM_OLD_PASSWORD];
            [dictParam setValue:_NewPassTxt.text forKey:PARAM_NEW_PASSWORD];
            [dictParam setValue:PARAM_PASSWORD forKey:PARAM_TYPE];
                ALog(@"change password params = %@", dictParam);
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_UPDATE withParamData:dictParam withBlock:^(id response, NSError *error)
             {
                 if (response == Nil){
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self Done:sender];
                         
                     }else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                     }
                 }else if (response){
                     ALog(@"Change Password Response ---> %@",response);
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
                         [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                         [pref synchronize];
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                         customAlertView.tag = 123;
                         [customAlertView show];
                     }
                     else{
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                         [customAlertView show];
                     }
                      [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                 }
                 [APPDELEGATE stopLoader:self.view];
             }];
        }else{
            [customAlertView setContainerView:[APPDELEGATE createDemoView:RETYPE_PASSWORD_MISMATCH view:self.view]];  //@"Retype password mismatch"
            [customAlertView show];
        }
        }
    }
    else
    {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)BackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSInteger nextTag = textField.tag + 1;
    //  Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        //   Found next Responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        //  Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return YES;
}
#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
//    [self resetAllTextFields];
    if ([alertView tag] == 123) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    [alertView close];
}

-(void) resetAllTextFields {
    _NewPassTxt.text=@"";
    _RepeatPassTxt.text=@"";
    _OldPass_txt.text=@"";
}
@end
