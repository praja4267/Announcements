//
//  FAQViewController.m
//  
//
//  Created by Active Mac06 on 10/12/15.
//
//

#import "FAQViewController.h"
#import "FAQTableViewCell.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"

@interface FAQViewController ()<UITextViewDelegate>
{
    NSString *faqcount;
    NSIndexPath *selectedIndexPath;
}
@property (strong, nonatomic) IBOutlet UITableView *FAQtableview;
@property (strong, nonatomic) NSMutableArray *SelectedIndexesarr;
@property (strong, nonatomic) NSMutableDictionary *faqData;
@property (strong, nonatomic) NSMutableArray *faqquestid;

@end

@implementation FAQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _faqData=[[NSMutableDictionary alloc]init];
    _faqquestid=[[NSMutableArray alloc]init];
    _SelectedIndexesarr=[[NSMutableArray alloc]init];
    _FAQtableview.tableFooterView = [UIView new];
    _FAQtableview.estimatedRowHeight = 61.0 ;
    _FAQtableview.rowHeight = UITableViewAutomaticDimension;
    [self getFAQdata];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_FAQtableview reloadData];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [faqcount intValue];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

        return [[[_faqData valueForKey:[_faqquestid objectAtIndex:section]] objectAtIndex:1] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FAQTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
        if (cell == nil) {
        cell=[[FAQTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    [self configureCell:cell atIndexPath:indexPath];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    static FAQTableViewCell *cell = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cell = (FAQTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
    });
    [self configureCell:cell atIndexPath:indexPath];
    CGFloat height = 55.0f;
    if ([_SelectedIndexesarr containsObject:indexPath])
    {
        CGFloat height = ceilf([cell.txt_details sizeThatFits:cell.txt_details.frame.size].height);
        if (height>55) {
            [self performSelector:@selector(goToBottom) withObject:nil afterDelay:0.02];
           if (IS_OS_8_OR_LATER) {
                  return UITableViewAutomaticDimension;
            }else{
               return height;
            }
        }else{
            return height+55;
        }
    }
    else
    {
        return height;
    }
}
-(void)goToBottom
{
    [_FAQtableview scrollToRowAtIndexPath:selectedIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}

-(void)configureCell:(FAQTableViewCell*)cell atIndexPath:(NSIndexPath*)indexPath {
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if ([_SelectedIndexesarr containsObject:indexPath]) {
        [cell.Mark setImage:[UIImage imageNamed:@"Mark_Up"]];
    }else{
        [cell.Mark setImage:[UIImage imageNamed:@"Mark_Down"]];
    }
    
    cell.textLabel.textColor = [UIColor orbitBlackColorhex7];
    
    for(int i=0;i<_faqquestid.count;i++){
        NSMutableArray *data=[[_faqData valueForKey:[_faqquestid objectAtIndex:i]] objectAtIndex:1];
        if(indexPath.section==i){
            //            ALog(@"---------%@",data[indexPath.row]);
            NSMutableDictionary *list = data[indexPath.row];
            cell.lbl_points.text=[list valueForKey:@"title"];
            cell.txt_details.text=[list valueForKey:@"description"];
        }
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndexPath=indexPath;
    if(_SelectedIndexesarr.count>0){
        [self tableView:tableView didDeselectRowAtIndexPath:[_SelectedIndexesarr lastObject]];
    }
    [_FAQtableview beginUpdates];
    
    if ([_SelectedIndexesarr containsObject:indexPath])
    {
        [_SelectedIndexesarr removeObject:indexPath];
        [_FAQtableview reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    else
    {
        [_SelectedIndexesarr removeAllObjects];
        [_SelectedIndexesarr addObject:indexPath];
        
    }
    
    [_FAQtableview reloadRowsAtIndexPaths:_SelectedIndexesarr withRowAnimation:UITableViewRowAnimationFade];
    [_FAQtableview endUpdates];
    //[tableView reloadData];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FAQTableViewCell *cell = (FAQTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    [cell.Mark setImage:[UIImage imageNamed:@"Mark_Down"]];
    

}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    // Background color
    view.backgroundColor = [UIColor colorWithRed:0.976 green:0.976 blue:0.976 alpha:1];
    
    // Text Color
    UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
    [header.textLabel setTextColor:[UIColor blackColor]];
    
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if(_faqquestid.count==0){
        return @"";
    }
    return [[_faqData valueForKey:[_faqquestid objectAtIndex:section]] objectAtIndex:0];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 61.0;
}

#pragma mark - FAQ API

- (void)getFAQdata{
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_FAQ withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getFAQdata];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
//                [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                [customAlertView show];
                }
            }else if (response){
                if([[response valueForKey:@"status"]boolValue]){
                    ALog(@"pick up......%@",response);
                    faqcount=[NSString stringWithFormat:@"%@",[response valueForKey:@"count"]];
                        ALog(@"FAQ Count......%@",faqcount);
                        NSMutableArray *faqquestions=[response valueForKey:@"questions"];
                        if(faqquestions.count>0){
                            for(NSMutableDictionary *quest in faqquestions){
                                
                                [_faqquestid addObject:[quest valueForKey:@"id"]];
                                [_faqData setObject:@[[quest valueForKey:@"name"],[quest valueForKey:@"faq"]] forKey:[quest valueForKey:@"id"]];
                        }
                    }
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
            }
            [_FAQtableview reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}

#pragma mark- Button Actions

- (IBAction)faqBackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}
@end
