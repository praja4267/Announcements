//
//  FavouriteUpdatesVC.h
//  
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"
#import "Reachability.h"

@interface FavouriteUpdatesVC : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}


@property (nonatomic,strong) NSString *toDisplay;
@property (nonatomic,strong) NSString *favTag;
@property (nonatomic,strong) NSString *favAddress;
@property (nonatomic,strong) NSString *favLat;
@property (nonatomic,strong) NSString *favLong;
@property (nonatomic,strong) NSString *favID;
@property (strong, nonatomic)  Reachability* reach;

@property (strong, nonatomic) IBOutlet UITextField *favTitleTxt;
//@property (weak, nonatomic) IBOutlet UITextField *favTitleTxt;
@property (weak, nonatomic) IBOutlet UIView *favTitleView;
@property (weak, nonatomic) IBOutlet UILabel *favPlaceLbl;
@property (weak, nonatomic) IBOutlet UIButton *favSaveBtn;
- (IBAction)favSaveBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *favUpdateBtn;
- (IBAction)favUpdateBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *favViewForMap;
- (IBAction)favSaveBackBtn:(id)sender;
- (IBAction)FavUpdateLocationBtn:(id)sender;

@end
