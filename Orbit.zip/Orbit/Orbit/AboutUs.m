//
//  AboutUs.m
//  
//
//  Created by Active Mac06 on 16/12/15.
//
//

#import "AboutUs.h"
#import "AboutusViewCell.h"
#import "PrivacyVC.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "REFrostedViewController.h"

@interface AboutUs ()
{
    
    NSMutableArray *title;
    NSMutableArray *content;
    NSString *toAboutTitle,*toAboutContent;
}

// Button
@property (strong, nonatomic) IBOutlet UIButton *MenuBtn;
@property (strong, nonatomic) IBOutlet UILabel *aboutUsTitle;

// Action
- (IBAction)Menu:(id)sender;

@property (strong, nonatomic) IBOutlet UIWebView *AboutusWebVW;

@property (strong, nonatomic) IBOutlet UITableView *AboutTblVW;

@property (strong, nonatomic) IBOutlet UILabel *VersionLbl;

@end

@implementation AboutUs

- (void)viewDidLoad {
    [super viewDidLoad];
     // Do any additional setup after loading the view.
    _AboutTblVW.tableFooterView = [UIView new];
    _aboutUsTitle.text=@"";
    title=[[NSMutableArray alloc]init];
    content=[[NSMutableArray alloc]init];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    ALog(@"Version.. %@",version);
//    _VersionLbl.text=[NSString stringWithFormat:@"Version %@",version];
    #if USE_TEST_URL
    _VersionLbl.text=@"V_00.66";
    #else
    _VersionLbl.text=@"V_00.06";
//     _VersionLbl.text=[NSString stringWithFormat:@"Version %@",version];
    #endif
   
      [self getAboutusData];
    _VersionLbl.textColor=[UIColor blackColor];
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
}


-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}


-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return title.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // Configure the cell...
    AboutusViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Aboutcell" forIndexPath:indexPath];
    
    if (cell == nil) {
        cell=[[AboutusViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Aboutcell"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if(title.count > 0){
        cell.accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Mark_blue"]];
        cell.CellLbl.text=[title objectAtIndex:indexPath.row];
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
    CGRect fareFrame = _AboutTblVW.frame;
    UIView *Line = [[UIView alloc] initWithFrame:CGRectMake(0, 1, fareFrame.size.width, 0.75f)];
    [Line setBackgroundColor:[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1]];
    [_AboutTblVW addSubview:Line];
}

# pragma -mark TAbleViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    if ([APPDELEGATE connected]) {
        toAboutTitle=[title objectAtIndex:indexPath.row];
        toAboutContent=[content objectAtIndex:indexPath.row];
        [self performSegueWithIdentifier:STRING_SEGUE_ABOUT_TO_PRIVACY sender:self];
//    }else {
//        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
//        [customAlertView show];
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - AboutUs API

- (void)getAboutusData {
    if([APPDELEGATE connected]){
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_PAGES withParamData:Nil withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getAboutusData];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response) {
                ALog(@"about us response = %@", response);
                if([[response valueForKey:@"success"]boolValue]){
                    NSMutableDictionary *Aboutus=[response valueForKey:@"about_us"];
                    _aboutUsTitle.text=[Aboutus valueForKey:@"title"];
                    NSString *web=[Aboutus valueForKey:@"content"];
                    [_AboutusWebVW loadHTMLString:[NSString stringWithFormat:@"<html><body style=\"font-size: 16; font-family: Dinpro; color: #999999\">%@</body></html>",web] baseURL:nil];
                    NSMutableArray *Information=[response valueForKey:@"informations"];
                    [title removeAllObjects];
                    [content removeAllObjects];
                    ALog(@"about us count = %lu", (unsigned long)Information.count);
                    if(Information.count>0){
                        for(NSMutableDictionary *info in Information){
                            [title addObject:[info valueForKey:@"title"]];
                            [content addObject:[info valueForKey:@"content"]];
                        }
                    }
                } else {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
//                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES];;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [_AboutTblVW reloadData];
                [APPDELEGATE stopLoader:self.view];
            });

        }];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_ABOUT_TO_PRIVACY]) {
        PrivacyVC *Privacyactivity = (PrivacyVC *)segue.destinationViewController;
        Privacyactivity.toTitle= toAboutTitle;
        Privacyactivity.toContent= toAboutContent;
    }
}

- (IBAction)Menu:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
