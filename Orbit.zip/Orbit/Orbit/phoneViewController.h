//
//  phoneViewController.h
//  
//
//  Created by ActiveMac03 on 26/11/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface phoneViewController : UIViewController<UITextFieldDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView, *alreadyRegisteredAlert;
}


@property (weak, nonatomic) IBOutlet UITextField *phoneTxt;
@property (weak, nonatomic) IBOutlet UIButton *phoneVerifyBtn;
- (IBAction)phoneVerifyBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *countryCodeBtn;
- (IBAction)countryCode:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *backButton;

@end
