//
//  LoginRegisterViewController.h
//  
//
//  Created by ActiveMac03 on 14/11/15.
//
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "CustomIOSAlertView.h"

@interface LoginRegisterViewController : UIViewController<UITextFieldDelegate,CustomIOSAlertViewDelegate>

@property (weak, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *loginScrollView;
@property (weak, nonatomic) IBOutlet UIView *homeView;
@property (weak, nonatomic) IBOutlet UIView *signupView;
@property (weak, nonatomic) IBOutlet UIView *loginView;
@property (weak, nonatomic) IBOutlet UIView *forgetPasswordView;
@property (weak, nonatomic) IBOutlet UIView *socialMailView;

#pragma mark -Home View
@property (weak, nonatomic) IBOutlet UIButton *homeFBBtn;
@property (weak, nonatomic) IBOutlet UIButton *homeGoogleBtn;
@property (weak, nonatomic) IBOutlet UIButton *homeLoginBtn;
@property (weak, nonatomic) IBOutlet UIButton *homeSignupBtn;

#pragma mark -Home button Actions
-(IBAction)onClickLoginBtn:(id)sender;
-(IBAction)onClickSignupBtn:(id)sender;
-(IBAction)onClickFBBtn:(id)sender;
-(IBAction)onClickGoogleBtn:(id)sender;

#pragma mark -signup view
@property (weak, nonatomic) IBOutlet UIView *signupSubView;
@property (weak, nonatomic) IBOutlet UITextField *signupNameTxt;
@property (weak, nonatomic) IBOutlet UITextField *signupEmailTxt;
@property (weak, nonatomic) IBOutlet UITextField *signupPasswordTxt;
@property (weak, nonatomic) IBOutlet UIButton *signupBtn;

#pragma mark -Signup button Actions
- (IBAction)signupBtn:(id)sender;

#pragma mark -Login View
@property (weak, nonatomic) IBOutlet UIView *loginSubView;
@property (weak, nonatomic) IBOutlet UITextField *loginEmailTxt;
@property (weak, nonatomic) IBOutlet UITextField *loginPasswordTxt;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

#pragma mark -login button actions
- (IBAction)loginBtn:(id)sender;
- (IBAction)loginToForgetPassBtn:(id)sender;

#pragma mark -Forget password view
@property (weak, nonatomic) IBOutlet UIView *forgetPasswordSubView;
@property (weak, nonatomic) IBOutlet UITextField *forgetPasswordEmailTxt;
@property (weak, nonatomic) IBOutlet UIButton *forgetPasswordBtn;


#pragma mark -forget password button actions
- (IBAction)forgetPasswordBtn:(id)sender;

#pragma mark -Social Mail View
@property (weak, nonatomic) IBOutlet UIView *socialMailSubView;
@property (weak, nonatomic) IBOutlet UITextField *socialMailNameTxt;
@property (weak, nonatomic) IBOutlet UITextField *socialMailEmailTxt;
@property (weak, nonatomic) IBOutlet UIButton *socialMailConfirmBtn;

#pragma mark -Social Mail View button Actions
- (IBAction)socialMailConfirmBtn:(id)sender;



@end
