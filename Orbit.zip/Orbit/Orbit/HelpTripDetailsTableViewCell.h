//
//  HelpTripDetailsTableViewCell.h
//  
//
//  Created by Active Mac06 on 23/12/15.
//
//

#import <UIKit/UIKit.h>

@interface HelpTripDetailsTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *IssuesLbl;

@end
