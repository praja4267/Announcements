//
//  PrivacyVC.m
//  
//
//  Created by Active Mac06 on 18/12/15.
//
//

#import "PrivacyVC.h"
#import "Constants.h"
#import "AppDelegate.h"

@interface PrivacyVC ()

@property (strong, nonatomic) IBOutlet UIButton *BackBtn;
@property (strong, nonatomic) IBOutlet UILabel *TitleLbl;
@property (strong, nonatomic) IBOutlet UIWebView *webVW;
- (IBAction)BackBtn:(id)sender;


@end

@implementation PrivacyVC


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _TitleLbl.text=_toTitle;
    
    NSString *web=_toContent;
    [_webVW loadHTMLString:[NSString stringWithFormat:@"<html><body style=\"font-size: 16; font-family: Dinpro; color: #999999\">%@</body></html>",web] baseURL:nil];
    
}

// Status Bar Color Change
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)BackBtn:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
}
@end
