//
//  CardListViewController.h
//  
//
//  Created by ActiveMac03 on 08/01/16.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@protocol CardListViewControllerDelegate <NSObject>
@optional
-(void)selectedCardDetailsDictionaryis : (NSDictionary*)cardDetailsDict;
@end

@interface CardListViewController : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}
@property (weak, nonatomic) IBOutlet UITableView *cardListTableView;
- (IBAction)cardListBackBtn:(id)sender;
- (IBAction)cardListAddBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *addCardButton;

@property (strong, nonatomic) IBOutlet UIView *noCardsView;
@property (nonatomic, weak) id <CardListViewControllerDelegate> cardListDelegate;
@property BOOL shouldShowCash, isPresented, isFromOutstanding, isfromBookingPage;
@end
