//
//  CardListViewController.m
//
//
//  Created by ActiveMac03 on 08/01/16.
//
//

#import "CardListViewController.h"
#import "cardListTableViewCell.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "UIImageView+Download.h"
#import "addCardViewController.h"

@interface CardListViewController ()<AddCardViewControllerDelegate>{
    NSMutableArray *arrCardName,*arrCardNumber,*arrCardID,*arrCardIcon, *cardDetails, *arrCardDefault, *arrExpiryDate;
     UIRefreshControl *refreshControl;
}
@end

@implementation CardListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _noCardsView.hidden=YES;
    arrCardIcon=[[NSMutableArray alloc]init];
    arrCardName=[[NSMutableArray alloc]init];
    arrCardNumber=[[NSMutableArray alloc]init];
    arrCardID=[[NSMutableArray alloc]init];
    cardDetails = [[NSMutableArray alloc] init];
    arrCardDefault=[[NSMutableArray alloc] init];
    arrExpiryDate=[[NSMutableArray alloc] init];
    _cardListTableView.tableFooterView = [UIView new];
    
   // [self getCardListData];
    
   
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
    if ([[[NSUserDefaults standardUserDefaults] valueForKey:PREF_SETTING_CARD_PAYMENT] boolValue]) {
        _addCardButton.hidden=NO;
    }else {
        _addCardButton.hidden=YES;
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
     [self getCardListData];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

//-(void)viewDidAppear:(BOOL)animated{
//    [super viewDidAppear:animated];
//    [self getCardListData];
//
//}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_shouldShowCash) {
        if ([arrCardNumber count]==0) {
            return 1;
        }
        return arrCardNumber.count+1;
    } else {
        return arrCardNumber.count;
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
    cardListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cardListCell" forIndexPath:indexPath];
    
    if (cell == nil) {
        cell=[[cardListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cardListCell"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (_shouldShowCash) {
        if(indexPath.row==0){
            cell.cardListName.text=@"Cash";
            cell.cardListNumber.text=@"Cash Payment";
            cell.cardListDefaultSelectedImgView.hidden=YES;
            //  [cell.cardListIcon downloadFromURL:@"Cash_Money" withPlaceholder:nil];
            
            cell.cardListIcon.image=[UIImage imageNamed:@"Cash_Money"];
        }else{
            if ([arrCardNumber count]>0) {
                cell.cardListNumber.text=[NSString stringWithFormat:@"**** %@",arrCardNumber[(indexPath.row)-1]];
                cell.cardListName.text=arrCardName[(indexPath.row)-1];
                [cell.cardListIcon downloadFromURL:arrCardIcon[(indexPath.row)-1] withOutLoader:nil];
                if ([[arrCardDefault objectAtIndex:indexPath.row - 1] intValue]) {
                    cell.cardListDefaultSelectedImgView.hidden=NO;
                }else {
                    cell.cardListDefaultSelectedImgView.hidden=YES;
                }
            }
        }

    } else {
        if ([arrCardNumber count]>0) {
            cell.cardListNumber.text=[NSString stringWithFormat:@"**** %@",arrCardNumber[(indexPath.row)]];
            cell.cardListName.text=arrCardName[(indexPath.row)];
            [cell.cardListIcon downloadFromURL:arrCardIcon[(indexPath.row)] withOutLoader:nil];
            if ([[arrCardDefault objectAtIndex:indexPath.row] intValue]) {
                cell.cardListDefaultSelectedImgView.hidden=NO;
            }else {
                cell.cardListDefaultSelectedImgView.hidden=YES;
            }
        }
    }
        return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 105;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}

# pragma -mark TableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    ALog(@"Option....%@",[pref valueForKey:PREF_PAYMENT_OPT]);
    
    if (_shouldShowCash) {
        if(indexPath.row==0){   // selected cash
            if ([[pref valueForKey:PREF_PAYMENT_OPT]  isEqual: @"1"]) {     //  before this also cash was selected again selected cash
                ALog(@"Both are Same 1");
                [pref setValue:@"" forKey:@"Paymentselected"];
                [pref setValue:@"1" forKey:PREF_PAYMENT_OPT];
                [pref setValue:@"Cash" forKey:PREF_PAYMENT_CARD_NAME];
                [pref setValue:@"Cash_Money" forKey:PREF_PAYMENT_CARD_ICON];
                [pref setValue:@"" forKey:PREF_PAYMENT_ID];
                [pref removeObjectForKey:PREF_LAST_FOUR];
                ALog(@"Cash Promo....%@",[pref valueForKey:PREF_PAYMENT_OPT]);
            }else {                                                              //  before this card was selected now selected cash
                [pref setValue:@"isPromoChange" forKey:@"Paymentselected"];
                [pref setValue:@"1" forKey:PREF_PAYMENT_OPT];
                [pref setValue:@"Cash" forKey:PREF_PAYMENT_CARD_NAME];
                [pref setValue:@"Cash_Money" forKey:PREF_PAYMENT_CARD_ICON];
                [pref setValue:@"" forKey:PREF_PAYMENT_ID];
                [pref removeObjectForKey:PREF_LAST_FOUR];
                ALog(@"Cash Promo....%@",[pref valueForKey:PREF_PAYMENT_OPT]);
            }
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
            [dict setValue:@"1" forKey:@"isCashSelected"];
            if ([self.cardListDelegate conformsToProtocol:@protocol(CardListViewControllerDelegate)]) {
                
                if ([self.cardListDelegate respondsToSelector:@selector(selectedCardDetailsDictionaryis:)]) {
                    ALog(@"selected a card %@", dict);
                    [self.cardListDelegate selectedCardDetailsDictionaryis:dict];
                }
            }
            
        } else {    // selected a card
            if ([[pref valueForKey:PREF_PAYMENT_OPT]  isEqual: @"0"]) {            // before this also same card was selected
                ALog(@"Both are Same 0");
                [pref setValue:@"" forKey:@"Paymentselected"];
                [pref setValue:@"0" forKey:PREF_PAYMENT_OPT];
                [pref setValue:arrCardName[(indexPath.row)-1] forKey:PREF_PAYMENT_CARD_NAME];
                [pref setValue:arrCardIcon[(indexPath.row)-1] forKey:PREF_PAYMENT_CARD_ICON];
                [pref setValue:arrCardIcon[(indexPath.row)-1] forKey:PREF_CARD_URL];
                [pref setValue:arrCardID[(indexPath.row)-1] forKey:PREF_PAYMENT_ID];
                [pref setValue:arrCardNumber[(indexPath.row)-1] forKey:PREF_LAST_FOUR];
                ALog(@"last four of selected card  = %@", [pref valueForKey:PREF_LAST_FOUR]);
                ALog(@"Card Promo....%@",[pref valueForKey:PREF_PAYMENT_OPT]);
            } else { // before this cash was selected
                [pref setValue:@"isPromoChange" forKey:@"Paymentselected"];
                [pref setValue:@"0" forKey:PREF_PAYMENT_OPT];
                [pref setValue:arrCardName[(indexPath.row)-1] forKey:PREF_PAYMENT_CARD_NAME];
                [pref setValue:arrCardIcon[(indexPath.row)-1] forKey:PREF_PAYMENT_CARD_ICON];
                [pref setValue:arrCardIcon[(indexPath.row)-1] forKey:PREF_CARD_URL];
                [pref setValue:arrCardID[(indexPath.row)-1] forKey:PREF_PAYMENT_ID];
                [pref setValue:arrCardNumber[(indexPath.row)-1] forKey:PREF_LAST_FOUR];
                 ALog(@"last four of selected card  = %@", [pref valueForKey:PREF_LAST_FOUR]);
                ALog(@"Card Promo....%@",[pref valueForKey:PREF_PAYMENT_OPT]);
            }
            [self reverseGivenString:arrCardName[(indexPath.row)-1]];
            
            if ([self.cardListDelegate conformsToProtocol:@protocol(CardListViewControllerDelegate)]) {
                
                if ([self.cardListDelegate respondsToSelector:@selector(selectedCardDetailsDictionaryis:)]) {
                    ALog(@"selected a card %@", [cardDetails objectAtIndex:indexPath.row - 1]);
                    [self.cardListDelegate selectedCardDetailsDictionaryis:[cardDetails objectAtIndex:indexPath.row - 1]];
                }
            }
        }
        [pref synchronize];
        [APPDELEGATE stopLoader:self.view];
        
        [self.navigationController popViewControllerAnimated:YES];
        
    } else {
        if ([self.cardListDelegate conformsToProtocol:@protocol(CardListViewControllerDelegate)]) {
            
            if ([self.cardListDelegate respondsToSelector:@selector(selectedCardDetailsDictionaryis:)]) {
                ALog(@"selected a card %@", [cardDetails objectAtIndex:indexPath.row]);
                [self.cardListDelegate selectedCardDetailsDictionaryis:[cardDetails objectAtIndex:indexPath.row]];
            }
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - card list API

- (void)getCardListData {
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_CARD withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response){
                ALog(@"saved cards response in cardlist view controller = %@", response);
                if([[response valueForKey:@"success"]boolValue]){
                    [arrCardIcon removeAllObjects];
                    [arrCardNumber removeAllObjects];
                    [arrCardName removeAllObjects];
                    [arrCardDefault removeAllObjects];
                    [arrExpiryDate removeAllObjects];
                    cardDetails =[response valueForKey:@"payments"];
                    if (!_shouldShowCash) {
                        if (cardDetails.count == 0) {
                             _noCardsView.hidden=NO;
                        }else{
                            _noCardsView.hidden=YES;
                        }
                    }else{
                        _noCardsView.hidden=YES;
                    }
                    
                    for(NSMutableDictionary *paymentTags in cardDetails){
                        [arrCardIcon addObject:[paymentTags valueForKey:@"image"]];
                        [arrCardNumber addObject:[paymentTags valueForKey:@"last_four"]];
                        [arrCardName addObject:[paymentTags valueForKey:@"card_type"]];
                        [arrCardID addObject:[paymentTags valueForKey:@"id"]];
                        
                        [arrCardDefault addObject:[paymentTags valueForKey:@"is_default"]];
                        [arrExpiryDate addObject:[NSString stringWithFormat:@"%@/%@", [paymentTags valueForKey:@"expiry_month"], [paymentTags valueForKey:@"expiry_year"]]];
                        
                    }
                    
                }else {
                    if (_shouldShowCash) {
                        _noCardsView.hidden=YES;
                    }else{
                        _noCardsView.hidden=NO;
                    }
                    
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:NO FromViewController:self];;
            }
            [_cardListTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Button Actions

- (IBAction)cardListBackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
     NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    if ([[pref valueForKey:PREF_PAYMENT_OPT]  isEqual: @"1"]||[[pref valueForKey:PREF_PAYMENT_OPT]  isEqual: @"0"]) {
        ALog(@"Both are Same 1 or 0");
        [pref setValue:@"isPromoNotChange" forKey:@"Paymentselected"];
    }else{
        [pref setValue:@"isPromoChange" forKey:@"Paymentselected"];
         ALog(@"Toggled");
    }
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)cardListAddBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    if ([APPDELEGATE connected]) {
        [self performSegueWithIdentifier:STRING_SEGUE_CARD_LIST_TO_ADD_CARD sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }

    
}

-(void) reverseGivenString :(NSString *)string{
    NSMutableString *reversedString = [NSMutableString string];
    int index = [string length] - 1;
    while (index >= 0) {
        NSString *temp = [string substringWithRange:NSMakeRange(index, 1)];
        [reversedString appendString:temp];
        index--;
    }
    NSLog(@"reversed string = %@", reversedString);
    
}

-(BOOL) isPalendromeString :(NSString*)string{
    for (int i = 0; i < string.length/2; i++) {
        if ([string characterAtIndex:i] != [string characterAtIndex:string.length-1-i]) {
            return NO;
        }
    }
    return YES;
}

-(BOOL) isPrimeNumber :(NSUInteger)number{
    
    return YES;
}

#pragma mark - Add card viewcontroller delegate

-(void)cardAddedFromWebViewWithMessage:(NSString *)message {
    
    [customAlertView setContainerView:[APPDELEGATE createDemoView:message view:self.view]];
    [customAlertView show];
    //    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:message message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    //    [alert show];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:STRING_SEGUE_CARD_LIST_TO_ADD_CARD]) {
        addCardViewController *Addcardcntl= (addCardViewController *)segue.destinationViewController;
        if (_isFromOutstanding || _isfromBookingPage) {
            Addcardcntl.isFromOutStanding=YES;
            Addcardcntl.addcardDelegate=self;
        }
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
