//
//  OutStandingPaymentsViewController.h
//  Orbit
//
//  Created by Active Mac05 on 05/07/16.
//  Copyright © 2016 techActive. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CardListViewController.h"
#import "CustomIOSAlertView.h"




@interface OutStandingPaymentsViewController : UIViewController <CardListViewControllerDelegate, CustomIOSAlertViewDelegate> {
     CustomIOSAlertView *customAlertView;
}

@property (strong, nonatomic) IBOutlet UIButton *backButton;
@property (strong, nonatomic) IBOutlet UILabel *balanceAmountLabel;
@property (strong, nonatomic) IBOutlet UILabel *messageLabel;
@property (strong, nonatomic) IBOutlet UIImageView *cardImageView;
@property (strong, nonatomic) IBOutlet UILabel *cardNumberLabel;
@property (strong, nonatomic) IBOutlet UIButton *payNowButton;
@property (strong, nonatomic) IBOutlet UIView *cardDetailsHolderView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imageViewWidthConstraint;
@property (strong, nonatomic) IBOutlet UIImageView *cardDetailsBGImageView;
@property (strong, nonatomic) IBOutlet UIButton *addCardButton;
@property (nonatomic, strong) NSString *outStandingAmount, *request_id, *cancel_payment_id, *cardImageUrl, *cardLastFourString;
@property BOOL isPushed, isPresentedFromBookingPage, isPresentedFromSettings, isPresentedFromCurrentRide;
@end
