//
//  OTPViewController.h
//  
//
//  Created by ActiveMac03 on 07/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface OTPViewController : UIViewController<UITextFieldDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}
@property (weak, nonatomic) IBOutlet UITextField *otpTxt;
@property (weak, nonatomic) IBOutlet UILabel *otpPhoneLbl;
@property (weak, nonatomic) IBOutlet UIButton *otpResendBtn;
@property (weak, nonatomic) IBOutlet UILabel *otpResendLbl;
@property (strong, nonatomic) IBOutlet UIButton *otpConfirmBtn;
@property (strong, nonatomic) IBOutlet UIButton *backButton;

- (IBAction)BackBtn:(id)sender;
- (IBAction)otpResendBtn:(id)sender;
- (IBAction)otpConfirmBtn:(id)sender;

@property NSString *screenStatus;

@end
