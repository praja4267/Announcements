//
//  MenuListTableViewCell.h
//  Orbit
//
//  Created by Active Mac05 on 16/06/16.
//  Copyright © 2016 techActive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuListTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *backGroundImage;
@property (strong, nonatomic) IBOutlet UIImageView *sideImage;
@property (strong, nonatomic) IBOutlet UILabel *label;

@end
