//
//  FAQViewController.h
//  
//
//  Created by Active Mac06 on 10/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface FAQViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

- (IBAction)faqBackBtn:(id)sender;

@end
