//
//  OnBoardSliderVC.m
//  
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import "OnBoardSliderVC.h"

@interface OnBoardSliderVC ()

@property (strong, nonatomic) IBOutlet UIImageView *Animate_img;
@property (strong, nonatomic) IBOutlet UILabel *PayByCash_lbl;
@property (strong, nonatomic) IBOutlet UILabel *Desc_lbl;

@end

@implementation OnBoardSliderVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.PayByCash_lbl.text = self.titleText;
    self.Desc_lbl.text = self.descText;
    self.Animate_img.image= [UIImage imageNamed:self.Imagegif];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
