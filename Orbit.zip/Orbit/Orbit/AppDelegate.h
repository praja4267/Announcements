//
//  AppDelegate.h
//  lymo
//
//  Created by Active Mac06 on 02/11/15.
//  Copyright © 2015 techActive. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Reachability.h"
#import <GoogleSignIn/GoogleSignIn.h>
#import "UIColor+CustomColor.h"
#import "CustomIOSAlertView.h"

typedef void(^myCompletion)(BOOL);

#define ALog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
//#define ALog(fmt, ...)
@interface AppDelegate : UIResponder <UIApplicationDelegate,GIDSignInDelegate,UIAlertViewDelegate, CustomIOSAlertViewDelegate>

@property (strong, nonatomic) UIWindow *window;

//@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
//@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
//@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
//
//- (void)saveContext;
//- (NSURL *)applicationDocumentsDirectory;

- (NSString *)applicationCacheDirectoryString;
- (BOOL)connected;
-(void)showToastMessage:(NSString *)message;
- (UIView *)createDemoView:(NSString*)message view:(UIView*)view;
- (UIView *)createDemoViewWithAttributedString:(NSMutableAttributedString*)message view:(UIView*)view;
-(NSMutableDictionary *)deviceInfo;

//-(void)customerSetting:(NSMutableDictionary*)setting ShowRideComplete : (BOOL)status;
-(void)customerSetting:(NSMutableDictionary *)setting ShowRideComplete:(BOOL)rideComplete ShowCancelPayment : (BOOL)paymentStatus FromViewController:(UIViewController*) currentViewController;
//-(void)customerSetting:(NSMutableDictionary*)setting onCompletion:(myCompletion) compblock;

-(BOOL)settingsStatus :(NSMutableDictionary* )setting;
-(void)logout: (myCompletion)completionBlock;

@property (nonatomic, strong) UIActivityIndicatorView *activityIndicatorView;
@property (strong, nonatomic) UIView *overlayView;
@property (strong, nonatomic) UIView *innerOverlayView;

- (void)startLoader:(UIView*)view giveSpaceFornavigationBar:(BOOL)navigationBar;
- (void)stopLoader:(UIView*)view;
-(void)changeLoaderBackgroundColorwithAlpha:(UIColor*)color;
+ (UIViewController*) topMostController;
-(void)showAlertOnTopMostControllerWithText:(NSString*)message;
-(void)checkForUpdate;
-(NSString*)getTheErrorMessageFromError : (NSError*)error;
@end

