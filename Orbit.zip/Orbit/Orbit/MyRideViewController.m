//
//  MyRideViewController.m
//
//
//  Created by ActiveMac03 on 10/12/15.
//
//

#import "MyRideViewController.h"
#import "SPSlideTabView.h"
#import "myRideTableViewCell.h"
#import "NoRidesTableViewCell.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "RideDetailsViewController.h"
#import "REFrostedViewController.h"
#import "currentRideViewController.h"


@interface MyRideViewController ()<SPSlideTabViewDelegate>{
    BOOL isFirstLoading;
    UITableView *myRideTableView;
    NSMutableArray *myRideDateArray,*myRideStatusArray,*myRideStatusIDArray,*myRideOriginArray,*myRideDestinationArray,*myRideTitleArray,*myRideTitleIDArray,*myRideTableViewArray,*myRideTypeID,*myRideAmount, *paidcurrency;
    NSString *rideRequestID,*strForPageIndex, *currentRideTitle;
    NSInteger previousIndex ;
    NSUserDefaults *pref;
    
}
@property (weak, nonatomic) IBOutlet SPSlideTabView *slideTabView;

@end

@implementation MyRideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    pref=[NSUserDefaults standardUserDefaults];
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    //[APPDELEGATE stopLoader:self.view];
    isFirstLoading = YES;
    myRideTitleArray=[[NSMutableArray alloc]init];
    myRideTitleIDArray=[[NSMutableArray alloc]init];
    myRideDateArray=[[NSMutableArray alloc]init];
    myRideStatusArray=[[NSMutableArray alloc]init];
    myRideStatusIDArray=[[NSMutableArray alloc]init];
    myRideOriginArray=[[NSMutableArray alloc]init];
    myRideDestinationArray=[[NSMutableArray alloc]init];
    myRideTableViewArray=[[NSMutableArray alloc]init];
    myRideTypeID=[[NSMutableArray alloc]init];
    myRideAmount=[[NSMutableArray alloc]init];
    paidcurrency=[[NSMutableArray alloc] init];
    
    previousIndex = 0;
    
    [self getMyRideTitle];
    
    _slideTabView.hidden=YES;
    _myRideEmptyCarIcon.hidden=YES;
    _myRideEmptyLabel.hidden=YES;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(myFunction) name:@"getMyRideTitleIdentifier" object:nil];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    //[APPDELEGATE stopLoader:self.view];
    
    if (isFirstLoading) {
        [self.slideTabView setSelectedPageIndex:0];
        [self.slideTabView setNeedsRender];
    }else {
        [self.slideTabView setSelectedPageIndex:previousIndex];
        [self.slideTabView setNeedsRender];
        [myRideTableView reloadData];
    }
    isFirstLoading = NO;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"myRideScroll" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(myRideScrollNotification:) name:@"myRideScroll" object:nil];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"getMyRideTitleIdentifier" object:nil];
    myRideTitleArray= nil;
    myRideTitleIDArray=nil;
    myRideDateArray=nil;
    myRideStatusArray=nil;
    myRideStatusIDArray=nil;
    myRideOriginArray=nil;
    myRideDestinationArray=nil;
    myRideTableViewArray=nil;
    myRideTypeID=nil;
    myRideAmount=nil;
    paidcurrency=nil;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //[APPDELEGATE stopLoader:self.view];
    [myRideTableView reloadData];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"myRideScroll" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [customAlertView close];
}


-(void)setView:(UIView*)view
{
    [super setView:view];
    if(view == nil)
    {
        ALog(@"++++++++++++++++++++++++++++set view is called in myride view controller because of memory warning  so clearing all date ++++++++++++++++++++++++++");
        myRideTitleArray= nil;
        myRideTitleIDArray=nil;
        myRideDateArray=nil;
        myRideStatusArray=nil;
        myRideStatusIDArray=nil;
        myRideOriginArray=nil;
        myRideDestinationArray=nil;
        myRideTableViewArray=nil;
        myRideTypeID=nil;
        myRideAmount=nil;
        paidcurrency=nil;
        myRideTableView=nil;
        _myRidesEmptyView=nil;
        _myRideEmptyCarIcon = nil;
        _myRideEmptyLabel = nil;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    ALog(@"The memory error is in AllRides page");
    // Dispose of any resources that can be recreated.
}

- (void)getMyRideTitle {
    if([APPDELEGATE connected]){
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:@"0" forKey:PARAM_TYPE];
      // [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        
        ALog(@"device request is %@", dictParam);
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_HISTORY withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005 ) {
                    [self getMyRideTitle];
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response){
                if([[response valueForKey:@"success"]boolValue]){
                    ALog(@"pick up......get myride title 1 %@",response);
                    if([[response valueForKey:@"success"]boolValue]){
                        NSMutableArray *statusDetails=[response valueForKey:@"request_status"];
                        if(statusDetails.count>0){
                            for(NSMutableDictionary *places in statusDetails){
                                [myRideTitleIDArray addObject:[places objectForKey:@"id"]];
                                [myRideTitleArray addObject:[places objectForKey:@"name"]];
                            }
                        }
                        statusDetails=nil;
                        NSMutableArray *requestDetails=[response valueForKey:@"requests"];
                        if(requestDetails.count>0){
                            for(NSMutableDictionary *places in requestDetails){
                                [myRideStatusIDArray addObject:[places objectForKey:@"id"]];
                                [myRideTypeID addObject:[places objectForKey:@"type_id"]];
                                [myRideStatusArray addObject:[places objectForKey:@"status"]];
                                [myRideOriginArray addObject:[places objectForKey:@"source_address"]];
                                [myRideDestinationArray addObject:[places objectForKey:@"destination_address"]];
                                [myRideDateArray addObject:[places objectForKey:@"date"]];
                                [myRideAmount addObject:[places objectForKey:@"total"]];
                                [paidcurrency addObject:[places objectForKey:@"paid_currency"]];
                            }
                        }
                        requestDetails=nil;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [myRideTableView reloadData];
                        });
                    }
                }
                else {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];
            }
            [self customSlideTabView];
            [self addPages];
            //[myRideTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [APPDELEGATE stopLoader:self.view];
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (void)customSlideTabView {
    
    _slideTabView.hidden=NO;
    
    [self.slideTabView setBackgroundColor:[UIColor clearColor]];
    
    [self.slideTabView setTabBarHeight:50];
    [self.slideTabView setTabBarBackgroundColor:[UIColor whiteColor]];
    
    [self.slideTabView setSelectedViewColor:[UIColor blackColor]];
    
    /**
     * custom the selectedView's width
     * (fit to the text of the selected button or equals to the width of the selected button)
     */
    
    [self.slideTabView setSelectedViewSizeToFit:NO];
    
    [self.slideTabView setSeparatorStyle:SPSlideTabBarSeparatorStyleSingleLine];
    [self.slideTabView setSeparatorLineInsetTop:8];
    [self.slideTabView setSeparatorColor:[UIColor whiteColor]];
    
    [self.slideTabView setBarButtonMinWidth:self.view.frame.size.width / 3];
    [self.slideTabView setBarButtonTitleColor:[UIColor orbitBlackColorhex7]];
    [self.slideTabView setSelectedBarButtonTitleColor:[UIColor blackColor]];
    [self.slideTabView setBarButtonTitleFont:[UIFont fontWithName:@"Dinpro-Bold" size:15.0]];
    [self.slideTabView setDelegate:self];
    
    UIView *lineView = [[UIView alloc] initWithFrame: CGRectMake(0,50, self.view.frame.size.width,1)];
    lineView.backgroundColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1];
    [self.slideTabView addSubview:lineView];
}


- (void)addPages {
    for(int i=0;i<myRideTitleArray.count;i++){
        [self.slideTabView addPageView:[self createTableView:i] ForTitle:myRideTitleArray[i]];
    }
    //    [self.slideTabView addPageView:[self createTableView] ForTitle:@"All Ride"];
    //    [self.slideTabView addPageView:[self createTableView] ForTitle:@"Current"];
    //    [self.slideTabView addPageView:[self createTableView] ForTitle:@"Completed"];
    //    [self.slideTabView addPageView:[self createTableView] ForTitle:@"Upcomming"];
    //    [self.slideTabView addPageView:[self createTableView] ForTitle:@"Cancelled"];
}

-(UITableView*)createTableView:(int)tag{
    
    myRideTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 117, self.slideTabView.frame.size.width, self.slideTabView.frame.size.height)];
    myRideTableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    myRideTableView.delegate=self;
    myRideTableView.dataSource=self;
    myRideTableView.tag=tag;
    myRideTableView.tableFooterView = [UIView new];
    [myRideTableViewArray addObject:myRideTableView];
//    [self.slideTabView bringSubviewToFront:myRideTableView];
    return myRideTableView;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (myRideStatusIDArray.count==0) {
        return 1;
    }
    return myRideStatusIDArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if(myRideStatusIDArray.count>0){
        static NSString *CellIdentifier = @"myRideTableViewCell";
        
        myRideTableViewCell *cell = (myRideTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil){
            [tableView registerNib:[UINib nibWithNibName:@"myRideTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
            cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        }
//        [cell.contentView setBackgroundColor:[UIColor redColor]];
//        [cell setBackgroundColor:[UIColor redColor]];

        
        cell.hidden=NO;
        _pageIndex = 0;
        _myRidesEmptyView.hidden=YES;
        _myRideEmptyCarIcon.hidden=YES;
        _myRideEmptyLabel.hidden=YES;
        myRideTableView.hidden=NO;
        cell.myRideDestinationLbl.hidden=NO;
        cell.myRideOriginLbl.hidden=NO;
        cell.myRideDateLbl.hidden=NO;
        cell.myRideStatusLbl.hidden=NO;
        cell.myRideOriginIcon.hidden=NO;
        cell.myRideDestinationIcon.hidden=NO;
        cell.myRideAmountLbl.hidden=NO;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.row < myRideDateArray.count) {
            cell.myRideDateLbl.text=[NSString stringWithFormat:@"%@  -",myRideDateArray[indexPath.row]];
            cell.myRideStatusLbl.text=myRideStatusArray[indexPath.row];
            if(![myRideOriginArray[indexPath.row] isEqualToString:@""]){
                cell.myRideOriginLbl.text=myRideOriginArray[indexPath.row];
            }else{
                cell.myRideOriginLbl.text = @"- -";
            }
            if(![myRideDestinationArray[indexPath.row] isEqualToString:@""]){
                cell.myRideDestinationLbl.text=myRideDestinationArray[indexPath.row];
            }else{
                cell.myRideDestinationLbl.text = @"- -";
            }
            cell.myRideAmountLbl.text=[NSString stringWithFormat:@"%@ %@",paidcurrency[indexPath.row],myRideAmount[indexPath.row]];
            if([myRideTypeID[indexPath.row]isEqualToString:@"2"]){
                cell.myRideAmountLbl.hidden=YES;
                cell.myRideStatusLbl.textColor= [UIColor colorWithRed:1 green:0.749 blue:0 alpha:1];
            }else if ([myRideTypeID[indexPath.row]isEqualToString:@"4"]){
                cell.myRideStatusLbl.textColor= [UIColor colorWithRed:1 green:0.02 blue:0.02 alpha:1];
            }else if ([myRideTypeID[indexPath.row]isEqualToString:@"5"]){
                cell.myRideAmountLbl.hidden=YES;
                cell.myRideStatusLbl.textColor= [UIColor colorWithRed:0 green:0.071 blue:1 alpha:1];
            }else{
                cell.myRideStatusLbl.textColor= [UIColor blackColor];
            }
        }
         return cell;
    }else{
        _myRidesEmptyView.hidden=YES;
        static NSString *EmptyCellIdentifier = @"NoRidesTableViewCell";
        
        NoRidesTableViewCell *cell1 = (NoRidesTableViewCell *)[tableView dequeueReusableCellWithIdentifier:EmptyCellIdentifier];
        if (cell1 == nil) {
            [tableView registerNib:[UINib nibWithNibName:@"NoRidesTableViewCell" bundle:nil] forCellReuseIdentifier:EmptyCellIdentifier];
            cell1=[tableView dequeueReusableCellWithIdentifier:EmptyCellIdentifier];
        }
        return cell1;
    }
   
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (myRideStatusIDArray.count==0) {
        return self.view.frame.size.height;
    }
    return 143;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([APPDELEGATE connected]){
        if([myRideTypeID[indexPath.row]isEqualToString:@"2"]){
            rideRequestID=myRideStatusIDArray[indexPath.row];
            [self performSegueWithIdentifier:STRING_SEGUE_CURRENT_RIDE sender:self];
        }else{
            rideRequestID=myRideStatusIDArray[indexPath.row];
            [self performSegueWithIdentifier:STRING_SEGUE_RIDE_DETAILS sender:self];
        }
    } else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


#pragma mark - SPSlideTabViewDelegate
- (void)slideTabView:(SPSlideTabView *)slideTabView didScrollToPageIndex:(NSInteger)pageIndex {
    ALog(@"slideTabView:(SPSlideTabView *)slideTabView didScrollToPageIndex:(NSInteger)pageIndex %ld", (long)pageIndex);
    
    _myRideEmptyCarIcon.hidden=YES;
    _myRideEmptyLabel.hidden=YES;
    _pageIndex = pageIndex;
    previousIndex = pageIndex;
    switch (pageIndex) {
        case 1:
            
        default:
             [APPDELEGATE stopLoader:self.view];
            strForPageIndex = [NSString stringWithFormat:@"%ld",(long)pageIndex];
            [self getMyRideContent:myRideTitleIDArray[pageIndex] tag:pageIndex];
            break;
    }
}

- (void)getMyRideContent:(NSString*)type tag:(NSInteger)tag {
    if([APPDELEGATE connected]){
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:type forKey:PARAM_TYPE];
        ALog(@"the device request individual = %@", dictParam);
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        [APPDELEGATE changeLoaderBackgroundColorwithAlpha:[UIColor colorWithRed:1 green:1 blue:1 alpha:1]];
//        [APPDELEGATE changeLoaderBackgroundColorwithAlpha:[UIColor clearColor]];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_HISTORY withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getMyRideContent:type tag:tag];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response){
                if([[response valueForKey:@"success"]boolValue]){
                    ALog(@"pick up...... in ride view controller get my ride content 1  %@",response);
                    NSMutableArray *requestDetails=[response valueForKey:@"requests"];
                    [myRideStatusIDArray removeAllObjects];
                    [myRideStatusArray removeAllObjects];
                    [myRideOriginArray removeAllObjects];
                    [myRideDestinationArray removeAllObjects];
                    [myRideDateArray removeAllObjects];
                    [myRideTypeID removeAllObjects];
                    [myRideAmount removeAllObjects];
                    [paidcurrency removeAllObjects];
                    if(requestDetails.count>0){
                        for(NSMutableDictionary *places in requestDetails){
                            [myRideTypeID addObject:[places objectForKey:@"type_id"]];
                            [myRideStatusIDArray addObject:[places objectForKey:@"id"]];
                            [myRideStatusArray addObject:[places objectForKey:@"status"]];
                            [myRideOriginArray addObject:[places objectForKey:@"source_address"]];
                            [myRideDestinationArray addObject:[places objectForKey:@"destination_address"]];
                            [myRideDateArray addObject:[places objectForKey:@"date"]];
                            [myRideAmount addObject:[places objectForKey:@"total"]];
                            [paidcurrency addObject:[places objectForKey:@"paid_currency"]];
                        }
                    }
                    requestDetails=nil;
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                
                [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                for(UITableView *table in myRideTableViewArray)
                {
                    if(table.tag==tag){
                        
                        [table reloadData];
                    }
                }
                [APPDELEGATE stopLoader:self.view];
            });
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Segue Action

//In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_RIDE_DETAILS]) {
        RideDetailsViewController *rideDetailsactivity = (RideDetailsViewController *)segue.destinationViewController;
        rideDetailsactivity.requestID=rideRequestID;
    } else if([segue.identifier isEqualToString:STRING_SEGUE_CURRENT_RIDE]) {
        currentRideViewController *currentActivity = (currentRideViewController *)segue.destinationViewController;
        currentActivity.requestID=rideRequestID;
        
    }
}

#pragma mark - Button actions

- (IBAction)myRideMenu:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}

- (void)reloadtheridedetailsafterthisoperation:(void (^)(void))block {
    
}

-(void)myFunction {
    [APPDELEGATE stopLoader:self.view];
    NSString *inStr = [NSString stringWithFormat: @"%ld", (long)previousIndex];
    dispatch_queue_t getDataQueue = dispatch_queue_create("getDataQueue", nil);
    dispatch_async(getDataQueue, ^{
        [self getMyRideContent:inStr tag:_pageIndex];
        dispatch_async(dispatch_get_main_queue(), ^{
            [myRideTableView reloadData];
        });
    });
}

#pragma mark search page Delegate methods

- (void) myRideScrollNotification:(NSNotification *)notification {
    _myRideEmptyCarIcon.hidden=YES;
    _myRideEmptyLabel.hidden=YES;
}


#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}
@end
