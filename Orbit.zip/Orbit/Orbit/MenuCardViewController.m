//
//  MenuCardViewController.m
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import "MenuCardViewController.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"
#import "MenuPaymentCardTableViewCell.h"
#import "UIImageView+Download.h"
#import "CardDeleteViewController.h"

@interface MenuCardViewController (){
    NSMutableArray *arrCardType,*arrCardNumber,*arrCardIcon,*arrCardID,*arrCardDefault,*arrExpiryDate;
    
    NSMutableDictionary *CardContent;
    BOOL isCardEmpty;
}

@end

@implementation MenuCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrCardIcon=[[NSMutableArray alloc]init];
    arrCardNumber=[[NSMutableArray alloc]init];
    arrCardType=[[NSMutableArray alloc]init];
    arrCardID=[[NSMutableArray alloc]init];
    arrCardDefault=[[NSMutableArray alloc]init];
    arrExpiryDate= [[NSMutableArray alloc]init];
    CardContent=[[NSMutableDictionary alloc]init];
     _menuCardTableView.tableFooterView = [UIView new];
   
   // [self getCardDetails];
    _menuCardTableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0);
    
    _menuCardEmptyView.hidden=YES;
    _menuCardTableView.hidden=YES;
    isCardEmpty=NO;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [APPDELEGATE stopLoader:self.view];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardDetails" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCardDetails) name:@"CardDetails" object:nil];
    [self getCardDetails];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"AddedCard"]) {
//        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"AddedCard"];
//
//    }
}
- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardDetails" object:nil];
    [customAlertView close];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardDetails" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([arrCardNumber count]==0) {
        return 1;
    }
    return arrCardNumber.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
    MenuPaymentCardTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"menuCardListCell" forIndexPath:indexPath];
    
    if (cell == nil) {
        cell=[[MenuPaymentCardTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"menuCardListCell"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if ([arrCardNumber count]>0) {
        _menuCardEmptyView.hidden=YES;
        _menuCardTableView.hidden=NO;
        cell.selectedImageWidthConstraint.constant=15;
        cell.cardNumberLbl.text=[NSString stringWithFormat:@"**** %@",arrCardNumber[indexPath.row]];
        cell.cardTitleLbl.text=arrCardType[indexPath.row];
//        cell.selectedLabel.font=[UIFont fontWithName:@"Dinpro" size:12];
        [cell.cardLogoImg downloadFromURL:arrCardIcon[indexPath.row] withPlaceholder:nil];
        if ([[arrCardDefault objectAtIndex:indexPath.row] intValue]) {
            cell.selectedCardImageView.hidden=NO;
        }else {
            cell.selectedCardImageView.hidden=YES;
        }
        
        
    }else{
        if (isCardEmpty) {
        _menuCardEmptyView.hidden=NO;
        }
        _menuCardTableView.hidden=YES;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([APPDELEGATE connected]){
        [CardContent setValue:[arrCardType objectAtIndex:indexPath.row] forKey:@"Name"];
        [CardContent setValue:[NSString stringWithFormat:@"****%@",arrCardNumber[indexPath.row]] forKey:@"Number"];
        [CardContent setValue:[arrCardIcon objectAtIndex:indexPath.row] forKey:@"Icon"];
        [CardContent setValue:[arrCardID objectAtIndex:indexPath.row] forKey:@"ID"];
        [CardContent setValue:[arrCardDefault objectAtIndex:indexPath.row] forKey:@"Default"];
        [CardContent setValue:[arrExpiryDate objectAtIndex:indexPath.row] forKey:@"expiry_date"];
        [[NSNotificationCenter defaultCenter] postNotificationName: @"PaymentMenuVC" object:Nil userInfo:CardContent];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 105;
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}

#pragma mark - Card list API

- (void)getCardDetails{
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_CARD withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getCardDetails];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response){
                isCardEmpty=YES;
                ALog(@"Menu Card Details Response..%@",response);
                if([[response valueForKey:@"success"]boolValue]){
                    [arrCardIcon removeAllObjects];
                    [arrCardNumber removeAllObjects];
                    [arrCardType removeAllObjects];
                    NSMutableArray *payment=[response valueForKey:@"payments"];
                    for(NSMutableDictionary *paymentTags in payment){
                        [arrCardIcon addObject:[paymentTags valueForKey:@"image"]];
                        [arrCardNumber addObject:[paymentTags valueForKey:@"last_four"]];
                        [arrCardType addObject:[paymentTags valueForKey:@"card_type"]];
                        [arrCardID addObject:[paymentTags valueForKey:@"id"]];
                        [arrCardDefault addObject:[paymentTags valueForKey:@"is_default"]];
                        [arrExpiryDate addObject:[NSString stringWithFormat:@"%@/%@", [paymentTags valueForKey:@"expiry_month"], [paymentTags valueForKey:@"expiry_year"]]];
                    }
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
            }
            [_menuCardTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}


@end


//   a22!@#$s8523key!a22bytes8523key!
