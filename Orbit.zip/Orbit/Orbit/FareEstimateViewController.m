//
//  FareEstimateViewController.m
//
//
//  Created by ActiveMac03 on 25/12/15.
//
//

#import "FareEstimateViewController.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "SearchViewController.h"
//#import <GoogleMapsM4B/GoogleMaps.h>
#import <GoogleMaps/GoogleMaps.h>
#import "FavouriteListVC.h"

@interface FareEstimateViewController ()<UITextFieldDelegate, FavouriteListVCDelegate>{
    CLLocationManager *locationManager;
    NSString *strForLatitude,*strForLongitude,*strForFromText,*strForDestinationLatitude,*strForDestinationLongitude;
    BOOL isFav, bookingShouldRest, showNocarsAvailableView, fareEstimateSearchingTextField;
    NSUserDefaults *pref;
}
@end

@implementation FareEstimateViewController

- (void)viewDidLoad {
    _fareRateCardBtn.hidden=YES;
    [super viewDidLoad];
    pref=[NSUserDefaults standardUserDefaults];
    [_fareCalculateBtn setExclusiveTouch:YES];
    bookingShouldRest=YES;
    _fareOriginTxt.delegate=self;
    _fareDestinationTxt.delegate=self;
    [_fareOriginFavBtn setImage:_favButtonOriginImage forState:UIControlStateNormal];
    [_fareDestinationFavBtn setImage:_favButtonDestinationImage forState:UIControlStateNormal];
    _fareEstimateLbl.text = [NSString stringWithFormat:@"Fare Estimate (%@)", [pref valueForKey:PREF_SETTING_CURRENCY_TEXT]];
    strForDestinationLatitude=@"";
    strForDestinationLongitude=@"";
    if ([_screenStatus isEqualToString:@"booking"]) {
        [self showCalculateBtn];
        _fareOriginTxt.text=_OriginText;
        strForLatitude=_OriginLatitude;
        strForLongitude=_OriginLongitude;
    }else if ([_screenStatus isEqualToString:@"ridenow"] || [_screenStatus isEqualToString:@"ridelater"]) {
        [self showCalculateBtn];
        _fareOriginTxt.text=_OriginText;
        strForLatitude=_OriginLatitude;
        strForLongitude=_OriginLongitude;
        
        _fareDestinationTxt.text=_DestinationText;
        strForDestinationLatitude=_DestinationLatitude;
        strForDestinationLongitude=_DestinationLongitude;
    }else{
        
    }
    
    UITapGestureRecognizer *orginGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openSearchOriginBarController:)];
    _fareOriginSearchBarVW.tag=1;
    [_fareOriginSearchBarVW addGestureRecognizer: orginGesture];
    _fareOriginSearchBarVW.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *destinationGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openSearchDestinationBarController:)];
    _fareDestinationSearchBarVW.tag=2;
    [_fareDestinationSearchBarVW addGestureRecognizer: destinationGesture];
    _fareDestinationSearchBarVW.userInteractionEnabled = YES;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    [[NSUserDefaults standardUserDefaults] setValue:_fareDestinationTxt.text forKey:PREF_FARE_DESTINATIONTEXT];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fareEstimate:) name:@"fareEstimatePage" object:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([_fareOriginTxt.text isEqual: @""]) {
        [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    }else if ([_fareDestinationTxt.text isEqual:@""]){
        [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    }
}
-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    bookingShouldRest=YES;
    ALog(@"The OriginLatitude = %@, *OriginLongitude = %@, *OriginText = %@, *DestinationLatitude = %@, *DestinationLongitude = %@, *DestinationText = %@, *screenStatus  = %@, ",_OriginLatitude,_OriginLongitude,_OriginText,_DestinationLatitude,_DestinationLongitude,_DestinationText,_screenStatus);
    if ([_fareOriginTxt.text isEqual: @""]) {
        [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    }else if ([_fareDestinationTxt.text isEqual:@""]){
        [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    }

}
-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) showCalculateBtn{
    _fareCalculateBtn.hidden=NO;
    // _fareRateCardBtn.hidden=YES;
    _fareTimeCostLbl.hidden=YES;
    _fareTimeLbl.hidden=YES;
    _farePriceLbl.hidden=YES;
    _fareEstimateLbl.hidden=YES;
}

-(void) hideCalculateBtn{
    _fareCalculateBtn.hidden=YES;
    // _fareRateCardBtn.hidden=YES;
    _fareTimeCostLbl.hidden=NO;
    _fareTimeLbl.hidden=NO;
    _farePriceLbl.hidden=NO;
    _fareEstimateLbl.hidden=NO;
}

#pragma mark - TextView Delegate
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    if ([APPDELEGATE connected]) {
        [pref setObject:textField.text forKey:PREF_SEARCH_EDIT_ADDRESS];
        if(textField==_fareOriginTxt){
            strForFromText=@"origin";
            [self performSegueWithIdentifier:STRING_SEGUE_SEARCH_PAGE sender:self];
        }else{
            strForFromText=@"destination";
            [self performSegueWithIdentifier:STRING_SEGUE_SEARCH_PAGE sender:self];
        }
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Button Actions

- (IBAction)fareOriginFavBtn:(id)sender {
    
    if ([APPDELEGATE connected]) {
        strForFromText=@"origin";
        [pref setObject:_fareOriginTxt.text forKey:PREF_ADD_FAV_TEXT];
        [pref setObject:strForLatitude forKey:PREF_ADD_FAV_LAT];
        [pref setObject:strForLongitude forKey:PREF_ADD_FAV_LONG];
        [pref setObject:@"yes" forKey:PREF_ADD_FAV_VIEW];
        [pref synchronize];
        [self performSegueWithIdentifier:STRING_SEGUE_TO_FAVORITES sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)fareDestinationFavBtn:(id)sender {
    
    if ([APPDELEGATE connected]) {
        strForFromText=@"destination";
        [pref setObject:_fareDestinationTxt.text forKey:PREF_ADD_FAV_TEXT];
        [pref setObject:strForDestinationLatitude forKey:PREF_ADD_FAV_LAT];
        [pref setObject:strForDestinationLongitude forKey:PREF_ADD_FAV_LONG];
        if(_fareDestinationTxt.text.length<1){
            [pref setObject:@"no" forKey:PREF_ADD_FAV_VIEW];
        }else{
            [pref setObject:@"yes" forKey:PREF_ADD_FAV_VIEW];
        }
        [pref synchronize];
        [self performSegueWithIdentifier:STRING_SEGUE_TO_FAVORITES sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)fareCalculateBtn:(id)sender {
    if([APPDELEGATE connected])  {
        ALog(@"\n calculate  OriginLatitude = %@, *OriginLongitude = %@, *OriginText = %@, *DestinationLatitude = %@, *DestinationLongitude = %@, *DestinationText = %@, *screenStatus  = %@,strfor lattitude =  %@, strfor longitude = %@, strForDestinationLatitude =%@, strForDestinationLongitude = %@",_OriginLatitude,_OriginLongitude,_OriginText,_DestinationLatitude,_DestinationLongitude,_DestinationText,_screenStatus, strForLatitude, strForLongitude, strForDestinationLatitude, strForDestinationLongitude);

        if(_fareOriginTxt.text.length<1 || _fareDestinationTxt.text.length<1){
            if(_fareOriginTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_SOURCE view:self.view]];
                [customAlertView show];
            }
            else if(_fareDestinationTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_DESTINATION view:self.view]];
                [customAlertView show];
            }
        }
        else if (strForLatitude.length<1 || strForLongitude.length<1){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_SOURCE view:self.view]];
            [customAlertView show];
        }else if (strForDestinationLatitude.length<1 || strForDestinationLongitude.length<1){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_DESTINATION view:self.view]];
            [customAlertView show];
        }
        else {
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:strForLatitude forKey:PARAM_LATITUDE];
            [dictParam setValue:strForLongitude forKey:PARAM_LONGITUDE];
            [dictParam setValue:strForDestinationLatitude forKey:PARAM_D_LATITUDE];
            [dictParam setValue:strForDestinationLongitude forKey:PARAM_D_LONGITUDE];
            [dictParam setValue:[pref objectForKey:PREF_CATEGORY_TYPE_ID] forKey:PARAM_TYPE];
             ALog(@"Fare Calculate Sending Data ---> %@",dictParam);
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_FARE withParamData:dictParam withBlock:^(id response, NSError *error)
             {
                 ALog(@"Fare Calculate Response ---> %@",response);
                 if (response == Nil){
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self fareCalculateBtn:sender];
                         
                     }else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                     }
                 } else if (response)
                 {
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         [self hideCalculateBtn];
                         
                         [pref setValue:_fareDestinationTxt.text forKey:PREF_FARE_DESTINATIONTEXT];
                         
                         _fareTimeLbl.text=[response valueForKey:@"time"];
                         _farePriceLbl.text=[response valueForKey:@"estimated_fare"];
                         bookingShouldRest=NO;
                     }
                     else{
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                         [customAlertView show];
                     }
                      [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                 }
                 [APPDELEGATE stopLoader:self.view];
             }];
        }
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)fareRateCardBtn:(id)sender {
    
}

- (IBAction)fareBackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [pref setValue:@"" forKey:@"Paymentselected"];
    [self.navigationController popViewControllerAnimated:YES];
     [[NSNotificationCenter defaultCenter] postNotificationName:@"fare" object:nil];
    if (bookingShouldRest) {
        if ([self.fareEstDelegate conformsToProtocol:@protocol(FareEstimateViewControllerDelegate)]) {
            [self.fareEstDelegate resetTheBookingScreen];
        }
    }
}


-(void)openBookingScreen{
    if ([APPDELEGATE connected]) {
        [APPDELEGATE.window setRootViewController:nil];
        [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"DEMORootViewController"]];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)fareDoneBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)openSearchOriginBarController:(UITapGestureRecognizer*)sender{
    [self.view endEditing:YES];
    
    if ([APPDELEGATE connected]) {
        strForFromText=@"origin";
        [pref setObject:@"origin" forKey:PREF_FROM_DESTINATION];
        [pref setObject:_fareOriginTxt.text forKey:PREF_SEARCH_EDIT_ADDRESS];
        [self performSegueWithIdentifier:STRING_SEGUE_SEARCH_PAGE sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}

-(void)openSearchDestinationBarController:(UITapGestureRecognizer*)sender{
    [self.view endEditing:YES];
    
    if ([APPDELEGATE connected]) {
        strForFromText=@"destination";
        [pref setObject:@"destination" forKey:PREF_FROM_DESTINATION];
        [pref setObject:_fareDestinationTxt.text forKey:PREF_SEARCH_EDIT_ADDRESS];
        [self performSegueWithIdentifier:STRING_SEGUE_SEARCH_PAGE sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Segue Actions
-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_SEARCH_PAGE]){
        SearchViewController *searchController = (SearchViewController *)segue.destinationViewController;
        searchController.strForCurrentPage=@"fareEstimate";
        searchController.originOrDestination=strForFromText;
        searchController.latLongString = _currentLatLongString;
        if ([strForFromText isEqualToString:@"origin"]) {
            [pref setObject:@"origin" forKey:PREF_FROM_DESTINATION];
        } else {
           [pref setObject:@"destination" forKey:PREF_FROM_DESTINATION];
        }
    }else if([segue.identifier isEqualToString:STRING_SEGUE_TO_FAVORITES]){
        FavouriteListVC *favController = (FavouriteListVC *)segue.destinationViewController;
        favController.favouritesDelegate=self;
        favController.strForCurrentPage=@"fareEstimate";
        favController.addFavLat=strForLatitude;
        favController.addFavLong=strForLongitude;
        
        if([strForFromText isEqualToString:@"origin"]){
            favController.searchingTextField=@"estimate_origin";
            favController.addFavText=_fareOriginTxt.text;
            favController.addFavLat=_OriginLatitude;
            favController.addFavLong=_OriginLongitude;
        }else if([strForFromText isEqualToString:@"destination"]){
            favController.searchingTextField=@"estimate_dest";
            favController.addFavText=_fareDestinationTxt.text;
            favController.addFavLat=_DestinationLatitude;
            favController.addFavLong=_DestinationLongitude;
        }
        if (sender == _fareOriginFavBtn) {
            favController.searchingTextField=@"estimate_origin";
            favController.addFavText=_fareOriginTxt.text;
        } else if (sender == _fareDestinationFavBtn) {
            favController.searchingTextField=@"estimate_dest";
             favController.addFavText=_fareDestinationTxt.text;
        }
    }
}

- (void) fareEstimate:(NSNotification *)notification{
    if([_screenStatus isEqualToString:@"booking"]){
        [self showCalculateBtn];
        NSDictionary *fareInfo = notification.userInfo;
        if([fareInfo[@"text"] isEqualToString:@"currentLocation"]){
            if([strForFromText isEqualToString:@"origin"]){
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }else if ([strForFromText isEqualToString:@"destination"]){
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }
            [self getMyLocationIsPressed];
        }else{
            if([strForFromText isEqualToString:@"origin"]){
                _fareOriginTxt.text=fareInfo[@"text"];
                
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [self getLocationFromAddressString:_fareOriginTxt.text];
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }else if ([strForFromText isEqualToString:@"destination"]){
                _fareDestinationTxt.text=fareInfo[@"text"];
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                    if ([fareInfo[@"text"] isEqualToString:@""]) {
                        _fareDestinationTxt.text=@"";
                        _DestinationLatitude=@"";
                        _DestinationLongitude=@"";
                    }else{
                      [self getLocationFromAddressString:_fareDestinationTxt.text];
                    }
                    
                }
            }
        }
    }else if([_screenStatus isEqualToString:@"ridenow"] || [_screenStatus isEqualToString:@"ridelater"]){
        [self showCalculateBtn];
        NSDictionary *fareInfo = notification.userInfo;
        if([fareInfo[@"text"] isEqualToString:@"currentLocation"]){
            if([strForFromText isEqualToString:@"origin"]){
                if([fareInfo[@"isFav"] boolValue] && [pref objectForKey:PREF_FAREEST_ORIG_ADDRESS_ID]){
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }else if ([strForFromText isEqualToString:@"destination"]){
                if([fareInfo[@"isFav"] boolValue] && [pref objectForKey:PREF_FAREEST_DEST_ADDRESS_ID]){
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }
            [self getMyLocationIsPressed];
        } else{
            if([strForFromText isEqualToString:@"origin"]){
                _fareOriginTxt.text=fareInfo[@"text"];
                [self getLocationFromAddressString:_fareOriginTxt.text];
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }else if ([strForFromText isEqualToString:@"destination"]){
                _fareDestinationTxt.text=fareInfo[@"text"];
                [self getLocationFromAddressString:_fareDestinationTxt.text];
                if([fareInfo[@"isFav"] boolValue]){
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
                }else{
                    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
                }
            }
        }
    }
}

#pragma mark - Location Delegate

-(void)getMyLocationIsPressed{
    if ([CLLocationManager locationServicesEnabled])
    {
        if([strForFromText isEqualToString:@"origin"]){
            strForLatitude=_strForCurrentLatitude;
            strForLongitude=_strForCurrentLongitude;
        }else if ([strForFromText isEqualToString:@"destination"]){
            strForDestinationLatitude = _strForCurrentLatitude;
            strForDestinationLongitude = _strForCurrentLongitude;
        }
        [self getAddressFromLatLongUsingGeocodeAndChangeAddress:YES];
    }
    else
    {
    }
}

-(void)getLocationFromString:(NSString *)str
{
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc] init];
    [dictParam setObject:str forKey:PARAM_ADDRESS];
        [dictParam setObject:GOOGLE_KEY forKey:PARAM_KEY];
//    [dictParam setObject:GOOGLE_KEY_NEW forKey:PARAM_KEY];
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
    [afn getAddressFromGooglewithParamData:dictParam withBlock:^(id response, NSError *error)
     {
         ALog(@"the response address details = %@", response);
         if(response)
         {
             NSArray *arrAddress=[response valueForKey:@"results"];
             if ([arrAddress count] > 0)
             {
                 if([strForFromText isEqualToString:@"origin"]){
                     ALog(@"origin latlon data = %@", [arrAddress objectAtIndex:0]);
                     _fareOriginTxt.text=[[arrAddress objectAtIndex:0] valueForKey:@"formatted_address"];
                     NSDictionary *dictLocation=[[[arrAddress objectAtIndex:0] valueForKey:@"geometry"] valueForKey:@"location"];
                     strForLatitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lat"]];
                     strForLongitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lng"]];
                 }else if ([strForFromText isEqualToString:@"destination"]){
                     ALog(@"origin latlong data = %@", [arrAddress objectAtIndex:0]);
                     _fareDestinationTxt.text=[[arrAddress objectAtIndex:0] valueForKey:@"formatted_address"];
                     NSDictionary *dictLocation=[[[arrAddress objectAtIndex:0] valueForKey:@"geometry"] valueForKey:@"location"];
                     strForDestinationLatitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lat"]];
                     strForDestinationLongitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lng"]];
                 }
             }
         }
         [APPDELEGATE stopLoader:self.view];
     }];
}


- (void) getLocationFromAddressString:(NSString *)address
{
    double latitude = 0, longitude = 0;
    NSString *esc_addr = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(
                                                                                               NULL,
                                                                                               (CFStringRef)address,
                                                                                               NULL,
                                                                                               (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                                               kCFStringEncodingUTF8 ));
    //    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *req = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/place/textsearch/json?query=%@&key=%@", esc_addr, GOOGLE_KEY];
    ALog(@"url = %@", req);
    
    NSURL *URL = [NSURL URLWithString:req];
    NSData *data = [NSData dataWithContentsOfURL:URL];
    if (data) {
        NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: data
                                                             options: NSJSONReadingMutableContainers
                                                               error: nil];
        ALog(@"Json result = %@", JSON);
        NSArray *results = [JSON valueForKey:@"results"];
        if ([results count] >0) {
            NSDictionary *address = [results firstObject];
            NSDictionary *dictLocation=[[address valueForKey:@"geometry"] valueForKey:@"location"];
            latitude=[[dictLocation objectForKey:@"lat"] doubleValue];
            longitude=[[dictLocation objectForKey:@"lng"] doubleValue];

                if([strForFromText isEqualToString:@"origin"]){
                    ALog(@"origin latlon data = %@", address);
//                    _fareOriginTxt.text=[address valueForKey:@"formatted_address"];
                    strForLatitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lat"]];
                    strForLongitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lng"]];
                    _OriginLatitude = strForLatitude;
                    _OriginLongitude = strForLongitude;
                }else if ([strForFromText isEqualToString:@"destination"]){
                    ALog(@"origin latlong data = %@", address);
//                    _fareDestinationTxt.text=[address valueForKey:@"formatted_address"];
                    strForDestinationLatitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lat"]];
                    strForDestinationLongitude=[NSString stringWithFormat:@"%@",[dictLocation objectForKey:@"lng"]];
                    _DestinationLatitude=strForDestinationLatitude;
                    _DestinationLongitude=strForDestinationLongitude;
                }
            [self getAddressFromLatLongUsingGeocodeAndChangeAddress:NO];
        } else {
            if ([JSON valueForKey:@"error_message"]){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[JSON valueForKey:@"error_message"] view:self.view]];
                [customAlertView show];
            }
        }
    }
    
    ALog(@"new lattitude = %f, longitude =- %f and address = %@", latitude, longitude, address);
}

-(void)getAddressFromLatLongUsingGeocodeAndChangeAddress: (BOOL)change
{
    if([APPDELEGATE connected]) {
        NSString *url=@"";
        if([strForFromText isEqualToString:@"origin"]){
            url = [NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?latlng=%@,%@&sensor=false&key=%@",strForLatitude, strForLongitude, GOOGLE_KEY];
        }else if ([strForFromText isEqualToString:@"destination"]){
            url = [NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?latlng=%@,%@&sensor=false&key=%@",strForDestinationLatitude, strForDestinationLongitude, GOOGLE_KEY];
        }
        ALog(@"Geocode addres from latlong = %@", url);
        NSURL *URL = [NSURL URLWithString:url];
        NSData *data = [NSData dataWithContentsOfURL:URL];
        if (data) {
            NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: data
                                                                 options: NSJSONReadingMutableContainers
                                                                   error: nil];
            
            NSArray *results = [JSON valueForKey:@"results"];
            
            if (results.count!=0)
            {
                NSDictionary *address = [results firstObject];
                if (change) {
                    if([strForFromText isEqualToString:@"origin"]){
                        _fareOriginTxt.text=[address valueForKey:@"formatted_address"];
                    }else if([strForFromText isEqualToString:@"destination"]){
                        _fareDestinationTxt.text = [address valueForKey:@"formatted_address"];
                    }
                }
            }
        } else {
            [APPDELEGATE stopLoader:self.view];
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
            return ;
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


#pragma mark - Favourites list vc  Delegate method
-(void)selectedAddressDictionary:(NSDictionary *)addressDict sender:(id)sender{
    [self showCalculateBtn];
    ALog(@"***************** protocols and delegaets is working address data = %@ *******************", addressDict);
    if ([[addressDict valueForKey:@"searchingField"] isEqualToString:@"estimate_origin"]){
        _fareOriginTxt.text=[addressDict valueForKey:@"selectedAddress"];
        _OriginText=[addressDict valueForKey:@"selectedAddress"];
        [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
        _OriginLatitude=[addressDict valueForKey:@"selectedLat"];
        _OriginLongitude=[addressDict valueForKey:@"selectedLong"];
        strForLatitude=_OriginLatitude;
        strForLongitude=_OriginLongitude;
//        if ([self.fareEstDelegate conformsToProtocol:@protocol(FareEstimateViewControllerDelegate)]) {
//            [self.fareEstDelegate fareEstmateFavouriteselectedAddressDetails:addressDict sender:self];
//        }

    } else if ([[addressDict valueForKey:@"searchingField"] isEqualToString:@"estimate_dest"]) {
        _fareDestinationTxt.text=[addressDict valueForKey:@"selectedAddress"];
        _DestinationText=[addressDict valueForKey:@"selectedAddress"];
        [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_fill"] forState:UIControlStateNormal];
        _DestinationLatitude=[addressDict valueForKey:@"selectedLat"];
        _DestinationLongitude=[addressDict valueForKey:@"selectedLong"];
        strForDestinationLatitude=_DestinationLatitude;
        strForDestinationLongitude=_DestinationLongitude;
//        if ([self.fareEstDelegate conformsToProtocol:@protocol(FareEstimateViewControllerDelegate)]) {
//            [self.fareEstDelegate fareEstmateFavouriteselectedAddressDetails:addressDict sender:self];
//        }
    }
}


-(void)deselectOriginButton {
    [_fareOriginFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    if ([self.fareEstDelegate conformsToProtocol:@protocol(FareEstimateViewControllerDelegate)]) {
        [self.fareEstDelegate deselectOriginFromFareEstimate];
    }
}

-(void)deselectDestinationButton {
    [_fareDestinationFavBtn setImage:[UIImage imageNamed:@"Fav_btn"] forState:UIControlStateNormal];
    if ([self.fareEstDelegate conformsToProtocol:@protocol(FareEstimateViewControllerDelegate)]) {
        [self.fareEstDelegate deselectDestimationFromFareEstimate];
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
