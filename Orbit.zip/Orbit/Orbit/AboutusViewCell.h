//
//  AboutusViewCell.h
//  
//
//  Created by Active Mac06 on 17/12/15.
//
//

#import <UIKit/UIKit.h>

@interface AboutusViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *CellLbl;

@end
