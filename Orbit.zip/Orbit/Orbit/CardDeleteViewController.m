//
//  CardDeleteViewController.m
//  
//
//  Created by Active Mac06 on 14/01/16.
//
//

#import "CardDeleteViewController.h"
#import "UIImageView+Download.h"
#import "REFrostedViewController.h"
#import "MenuCardViewController.h"
#import "AppDelegate.h"
#import "Constants.h"
#import "AFNHelper.h"
@interface CardDeleteViewController ()
{
}

@end

@implementation CardDeleteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _deleteCardNameLbl.text=_toDeleteCardName;
    _deletCardNumberLbl.text=_toDeleteCardNumber;
    _expiryDateLabel.text=_toDeleteCardExpiryDate;
    [_deleteCardIconImg downloadFromURL:_toDeleteCardIcon withPlaceholder:nil];
    
    if([_toDeleteCardDefault isEqualToString:@"1"]){
        
        _deleteCardDefaultBtn.hidden=YES;
    }
    else{
        _deleteCardDefaultBtn.hidden=NO;
    }
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
//    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)deleteCardDeleteBtn:(id)sender {
    [self.view endEditing:YES];

    if([APPDELEGATE connected])  {
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:_toDeleteCardID forKey:PARAM_PAYMENT_ID];
        
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_DELETE_CARD withParamData:dictParam withBlock:^(id response, NSError *error)
             {
                 ALog(@"Delete Card Response ---> %@",response);
                 if (response == Nil){
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self deleteCardDeleteBtn:sender];
                     } else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                     }
                 }else if (response)
                 {
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         NSString *strLog=[NSString stringWithFormat:@"%@",[response valueForKey:@"message"]];
//                         [APPDELEGATE showToastMessage:strLog];
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:strLog view:self.view]];
                         customAlertView.tag=123;
                         _expiryDateLabel.text=@"";
                         _deletCardNumberLbl.text=@"";
                         _deleteCardIconImg.image=nil;
                         _deleteCardNameLbl.text=@"";
                         _expiryStaticLabel.hidden=YES;
                         _line1.hidden=YES;
                         _line2.hidden=YES;
                         _line3.hidden=YES;
                         [_deleteCardDefaultBtn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
                         _deleteCardDefaultBtn.hidden=YES;
                        [customAlertView show];
//                         [self.navigationController popViewControllerAnimated:YES];
                     }
                     else{
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                         [customAlertView show];
                     }
                      [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                 }
                 [APPDELEGATE stopLoader:self.view];
             }];
        
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
 
}

- (IBAction)deleteCardBackBtn:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)deleteCardDefaultBtn:(id)sender {
    [self.view endEditing:YES];
    
    if([APPDELEGATE connected])  {
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:_toDeleteCardID forKey:PARAM_CARD_ID];
        [dictParam setValue:@"0" forKey:PARAM_PAYMENT_MODE];

        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_SELECTED_CARD withParamData:dictParam withBlock:^(id response, NSError *error)
         {
             ALog(@"Default Card Response ---> %@",response);
             if (response == Nil){
                 if (error.code == -1005) {
                     [APPDELEGATE stopLoader:self.view];
                     [self deleteCardDeleteBtn:sender];
                     
                 }else {
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPDELEGATE stopLoader:self.view];
                         [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                     });
//                 [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                 [customAlertView show];
                 }
             }else if (response)
             {
                 if([[response valueForKey:@"success"]boolValue])
                 {
                     
            //        _toDeleteCardName=[pref objectForKey:PREF_PAYMENT_CARD_NAME];
            //      _deleteCardIconImg = [pref objectForKey:PREF_PAYMENT_CARD_ICON];
                     
                     NSString *strLog=[NSString stringWithFormat:@"%@",[response valueForKey:@"message"]];
                     //                         [APPDELEGATE showToastMessage:strLog];
                     [customAlertView setContainerView:[APPDELEGATE createDemoView:strLog view:self.view]];
                     customAlertView.tag =123;
                     [customAlertView show];
                     
                     _deleteCardDefaultBtn.hidden=YES;
                 }
                 else{
                     [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                     [customAlertView show];
                 }
                  [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
             }
             [APPDELEGATE stopLoader:self.view];
         }];
        
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }

    
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    if (customAlertView.tag == 123) {
        [self.navigationController popViewControllerAnimated:NO];
    }
    [alertView close];
}

@end
