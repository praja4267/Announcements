//
//  OnBoardSliderVC.h
//  
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import <UIKit/UIKit.h>


@interface OnBoardSliderVC : UIViewController
{
    
}
@property NSUInteger pageIndex;
@property NSString *titleText;
@property NSString *descText;
@property NSString *Imagegif;



@end
