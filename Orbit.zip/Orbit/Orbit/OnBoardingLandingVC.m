//
//  OnBoardingLandingVC.m
//  
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import "OnBoardingLandingVC.h"
#import "OnBoardSliderVC.h"
#import "Constants.h"
#import "AppDelegate.h"

@interface OnBoardingLandingVC () <UIPageViewControllerDataSource,UIPageViewControllerDelegate>
{
     UIPageControl *currentPageControl;
     NSString *alignView;
    IBOutlet UIButton *Getstarted;
}
@property (strong, nonatomic) IBOutlet UIPageControl *OnBoard_pagecontroller;
@property (strong, nonatomic) UIPageViewController *pageViewController;
@property (strong, nonatomic) NSArray *pageTitles;
@property (strong, nonatomic) NSArray *Pagedescription;
@property (strong, nonatomic) NSArray *PageImage;


@end

@implementation OnBoardingLandingVC



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.autoresizesSubviews = NO;
    
    _pageTitles = @[@"Pay By Cash", @"Safe Rides", @"Schedule a Ride"];
    
    _Pagedescription=@[@"When you arrive at your destination,\n just hop out, and make a hassle free \npayment with cash. There’s no \nneed to tip.", @"Our drivers are fully licensed, \ninsured and professionally \ntrained. Only those with the top \nskills become our partners", @"With Ride Later, you can book a \npickup for a future trip so you \ncan be at peace that a taxi will \nbe there when you want it."];
    
    _PageImage=@[@"Onboarding_Cash",@"Onboarding_Card",@"Onboarding_Online"];
    
    // Create page view controller
    self.pageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PageViewController"];
    self.pageViewController.dataSource = self;
    
    OnBoardingLandingVC *startingViewController = [self viewControllerAtIndex:0];
    NSArray *viewControllers = @[startingViewController];
    [self.pageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];

    // Change the size of page view controller
    self.pageViewController.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height+37);
    
    [self addChildViewController:_pageViewController];
    [self.view addSubview:_pageViewController.view];
    [self.pageViewController didMoveToParentViewController:self];
    [self.view bringSubviewToFront:self.OnBoard_pagecontroller];
    [self.view bringSubviewToFront:Getstarted];
    
    UIScrollView* pageView = nil;
    UIPageControl* pageControl = nil;
    
    UIView* selfView = self.pageViewController.view;
    NSArray* subviews = selfView.subviews;
    for( NSInteger i = 0 ; i < subviews.count && ( pageView == nil || pageControl == nil ) ; i++ )
    {
        UIView* t = subviews[i];
        if( [t isKindOfClass:[UIScrollView class]] )
        {
            pageView = (UIScrollView*)t;
        }
        else if( [t isKindOfClass:[UIPageControl class]] )
        {
            currentPageControl = (UIPageControl*)t;
        }
    }
    if( pageView != nil && currentPageControl != nil ){
        [pageView setClipsToBounds:NO];
    }
    [self.OnBoard_pagecontroller setNumberOfPages:[self.pageTitles count]];
    [Getstarted addTarget:self action:@selector(openBookingScreen) forControlEvents:UIControlEventTouchUpInside];
    
    //custom alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"AddedCard"]) {
//        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"AddedCard"];
//                [customAlertView setContainerView:[APPDELEGATE createDemoView:[[NSUserDefaults standardUserDefaults] valueForKey:@"AddcardMessage"] view:self.view]];
//                [customAlertView show];
//        
//    }
}

-(void)openBookingScreen{
    if ([APPDELEGATE connected]) {
        Getstarted.userInteractionEnabled=NO;
        [APPDELEGATE.window setRootViewController:nil];
        [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"DEMORootViewController"]];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}

- (OnBoardSliderVC *)viewControllerAtIndex:(NSUInteger)index
{
    if (([self.pageTitles count] == 0) || (index >= [self.pageTitles count])) {
        [self.OnBoard_pagecontroller setCurrentPage:[currentPageControl currentPage]];
        return nil;
    }
//    if (SCREEN_HEIGHT==480) // iphone 4
//    {
        OnBoardSliderVC *pageContentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"OnBoardSliderVC"];
        pageContentViewController.Imagegif = self.PageImage[index];
        pageContentViewController.titleText = self.pageTitles[index];
        pageContentViewController.descText = self.Pagedescription[index];
        pageContentViewController.pageIndex = index;
        [self.OnBoard_pagecontroller setCurrentPage:[currentPageControl currentPage]];
        return pageContentViewController;

//   }
//      else // iphone 5, 6 and 6+
//        {
//            OnBoardSliderVC *pageContentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"OnBoardSlider5"];
//            pageContentViewController.Imagegif = self.PageImage[index];
//            pageContentViewController.titleText = self.pageTitles[index];
//            pageContentViewController.descText = self.Pagedescription[index];
//            pageContentViewController.pageIndex = index;
//            [self.OnBoard_pagecontroller setCurrentPage:[currentPageControl currentPage]];
//            return pageContentViewController;
//        }
}

#pragma mark - Page View Controller Data Source

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSUInteger index = ((OnBoardSliderVC *) viewController).pageIndex;
    
    if ((index == 0) || (index == NSNotFound)) {
        [self.OnBoard_pagecontroller setCurrentPage:[currentPageControl currentPage]];
        return [self viewControllerAtIndex:[self.pageTitles count]-1];
    }
    index--;
    return [self viewControllerAtIndex:index];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSUInteger index = ((OnBoardSliderVC*) viewController).pageIndex;
    
    if (index == NSNotFound) {
        return nil;
    }
    
    index++;
    if (index == [self.pageTitles count]) {
        [self.OnBoard_pagecontroller setCurrentPage:[currentPageControl currentPage]];
        return [self viewControllerAtIndex:0];
    }
        return [self viewControllerAtIndex:index];
}

- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController
{
    return [self.pageTitles count];
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController
{
    return 0;
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews
{
    
    if(SCREEN_HEIGHT==480)// iPhone 4
    {
        float X_Co = (self.view.frame.size.width - Getstarted.frame.size.width)/2;
        float Y_Co = (self.view.frame.size.height - Getstarted.frame.size.height)-10;
        
        [Getstarted setFrame:CGRectMake(X_Co, Y_Co, Getstarted.frame.size.width, Getstarted.frame.size.height)];
        
        float XCo = (self.view.frame.size.width - _OnBoard_pagecontroller.frame.size.width)/2;
        float YCo = (self.view.frame.size.height - _OnBoard_pagecontroller.frame.size.height)-40;
        
         [_OnBoard_pagecontroller setFrame:CGRectMake(XCo, YCo, _OnBoard_pagecontroller.frame.size.width, _OnBoard_pagecontroller.frame.size.height)];

        
    }
    else if(SCREEN_HEIGHT==568) // iPhone 5
    {
        float X_Co = (self.view.frame.size.width - Getstarted.frame.size.width)/2;
        float Y_Co = (self.view.frame.size.height - Getstarted.frame.size.height)-25;
        
        [Getstarted setFrame:CGRectMake(X_Co, Y_Co, Getstarted.frame.size.width, Getstarted.frame.size.height)];
        
        float XCo = (self.view.frame.size.width - _OnBoard_pagecontroller.frame.size.width)/2;
        float YCo = (self.view.frame.size.height - _OnBoard_pagecontroller.frame.size.height)-60;
        
        [_OnBoard_pagecontroller setFrame:CGRectMake(XCo, YCo, _OnBoard_pagecontroller.frame.size.width, _OnBoard_pagecontroller.frame.size.height)];


    }
    else if (SCREEN_HEIGHT==667) // iPhone 6
    {
        float X_Co = (self.view.frame.size.width - Getstarted.frame.size.width)/2;
        float Y_Co = (self.view.frame.size.height - Getstarted.frame.size.height)-105;
        
        [Getstarted setFrame:CGRectMake(X_Co, Y_Co, Getstarted.frame.size.width, Getstarted.frame.size.height)];
        
        float XCo = (self.view.frame.size.width - _OnBoard_pagecontroller.frame.size.width)/2;
        float YCo = (self.view.frame.size.height - _OnBoard_pagecontroller.frame.size.height)-148;
        
        [_OnBoard_pagecontroller setFrame:CGRectMake(XCo, YCo, _OnBoard_pagecontroller.frame.size.width, _OnBoard_pagecontroller.frame.size.height)];


        
    }
    else //  iPhone 6+
    {
        
        float X_Co = (self.view.frame.size.width - Getstarted.frame.size.width)/2;
        float Y_Co = (self.view.frame.size.height - Getstarted.frame.size.height)-140;
        
        [Getstarted setFrame:CGRectMake(X_Co, Y_Co, Getstarted.frame.size.width, Getstarted.frame.size.height)];
        
        float XCo = (self.view.frame.size.width - _OnBoard_pagecontroller.frame.size.width)/2;
        float YCo = (self.view.frame.size.height - _OnBoard_pagecontroller.frame.size.height)-200;
        
        [_OnBoard_pagecontroller setFrame:CGRectMake(XCo, YCo, _OnBoard_pagecontroller.frame.size.width, _OnBoard_pagecontroller.frame.size.height)];


    }

}


- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
