//
//  MenuPaymentCardTableViewCell.h
//  
//
//  Created by ActiveMac03 on 05/01/16.
//
//

#import <UIKit/UIKit.h>

@interface MenuPaymentCardTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *cardTitleLbl;
@property (strong, nonatomic) IBOutlet UIImageView *cardLogoImg;
@property (strong, nonatomic) IBOutlet UILabel *cardNumberLbl;
@property (strong, nonatomic) IBOutlet UIImageView *selectedCardImageView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *selectedImageWidthConstraint;
@end
