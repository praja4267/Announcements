//
//  HelpTripDetailVC.m
//
//
//  Created by Active Mac06 on 22/12/15.
//
//

#import "HelpTripDetailVC.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "UIImageView+Download.h"
#import "HelpTripDetailsTableViewCell.h"
#import "ChatDetailsTableViewCell.h"
#import "UtilityClass.h"

@interface HelpTripDetailVC ()<UITextFieldDelegate>
{
    NSMutableArray *issuesID;
    NSMutableArray *issuesQuestions;
    NSMutableArray *chatArray;
    NSString *questID;
    NSMutableArray *chat_sentByArray;
    NSMutableArray *createdDateArray;
    Boolean isSubmitted;
}

@end

@implementation HelpTripDetailVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    questID = @"0";
    _invoiceEmailTextField.delegate=self;
    _invoiceEmailTextField.keyboardType=UIKeyboardTypeEmailAddress;
    if ([[NSUserDefaults standardUserDefaults] valueForKey:PREF_USER_EMAIL]) {
        _invoiceEmailTextField.text=[[NSUserDefaults standardUserDefaults] valueForKey:PREF_USER_EMAIL];
    }
    
    [self getHelpDetailsData];
    _inVoiceBigView.hidden=YES;
    issuesID=[[NSMutableArray alloc]init];
    issuesQuestions=[[NSMutableArray alloc]init];
    chatArray = [[NSMutableArray alloc] init];
    chat_sentByArray = [[NSMutableArray alloc] init];
    createdDateArray = [[NSMutableArray alloc] init];
    _HelpDropDownContentView.hidden=YES;
    [self disableScrollsToTopPropertyOnAllSubviewsOf:self.view];
    isSubmitted = false;
    
    _DriverPic.clipsToBounds = YES;
    _DropDownHelp.layer.cornerRadius=2;
    _DropDownHelp.clipsToBounds=YES;
    _DropDownHelp.layer.borderWidth=0.4;
    _DropDownHelp.layer.borderColor=[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    
    _TextVW_View.layer.cornerRadius=2;
    _TextVW_View.clipsToBounds=YES;
    _TextVW_View.layer.borderWidth=0.4;
    _TextVW_View.layer.borderColor=[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    
    _HelpTableVW.layer.cornerRadius=2;
    _HelpTableVW.clipsToBounds=YES;
    _HelpTableVW.layer.borderWidth=0.4;
    _HelpTableVW.layer.borderColor=[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    
    _HelpTableVW.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    
    _inVoiceInnerContainerView.layer.borderColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    _inVoiceInnerContainerView.layer.borderWidth = 0.5f;
    _inVoiceInnerContainerView.layer.cornerRadius = 2;
    _inVoiceInnerContainerView.clipsToBounds=YES;
    
    _invoiceEmailTextField.layer.borderColor = [UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
    _invoiceEmailTextField.layer.borderWidth = 0.5f;
    _invoiceEmailTextField.layer.cornerRadius = 2;
    _invoiceEmailTextField.clipsToBounds=YES;
    
    
    UITapGestureRecognizer *QuestiontapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(QuestionViewGesture:)];
    _DropDownHelp.userInteractionEnabled = YES;
    [_DropDownHelp addGestureRecognizer:QuestiontapRecognizer];
    
    
    UITapGestureRecognizer *invoiceMovingGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideInvoiceKeyboard:)];
    _inVoiceInnerContainerView.userInteractionEnabled = YES;
    [_inVoiceInnerContainerView setExclusiveTouch:YES];
    [_inVoiceInnerContainerView addGestureRecognizer:invoiceMovingGesture];
    
    [_invoiceSendButton addTarget:self action:@selector(invoiceSendBtnPressed) forControlEvents:UIControlEventTouchUpInside];
    [_invoiceCancelButton addTarget:self action:@selector(invoiceCancelBtnPressed) forControlEvents:UIControlEventTouchUpInside];
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    self.view.backgroundColor = [UIColor whiteColor];
    // pull to refresh for scrollview https://github.com/samvermette/SVPullToRefresh
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    // [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    
    [UIView transitionWithView:_HelpDropDownContentView
                      duration:0.4
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:NULL];
    
    _HelpDropDownContentView.hidden=YES;
    [self ScrollToTheLastView];
    [_CommentTxtView resignFirstResponder];
    
}

- (void) disableScrollsToTopPropertyOnAllSubviewsOf:(UIView *)view {
    for (UIView *subview in view.subviews) {
        if ([subview isKindOfClass:[UIScrollView class]]) {
            ((UIScrollView *)subview).scrollsToTop = NO;
        }
        [self disableScrollsToTopPropertyOnAllSubviewsOf:subview];
    }
}
-(BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView{
    if (scrollView == _HelpTripScrlVW) {
        return NO;
    }else {
        return YES;
    }
}
-(void)getHelpDetailsData{
    [self.view endEditing:YES];
    if (isSubmitted) {
        //     [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
    }
    if([APPDELEGATE connected])  {
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:_request_id forKey:PARAM_REQUEST_ID];
        [dictParam setValue:@"1" forKey:PARAM_HELP];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_REQUEST_DETAIL withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getHelpDetailsData];
                    
                }else {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[APPDELEGATE getTheErrorMessageFromError:error] view:self.view]];
                customAlertView.tag = 123;
                [customAlertView show];
                _Submit.userInteractionEnabled=YES;
                }
                
            }else if (response){
                ALog(@"Help Trip Response ---> %@",response);
                if([[response valueForKey:@"success"]boolValue])
                {
                    NSMutableArray *responseChatContent=[response valueForKey:@"chat_content"];
                    if (responseChatContent.count){
                        _dropDownImageView.hidden = YES;
                        [chatArray removeAllObjects];
                        [createdDateArray removeAllObjects];
                        [chat_sentByArray removeAllObjects];
                        [issuesID removeAllObjects];
                        [issuesQuestions removeAllObjects];
                        for (NSDictionary *object  in responseChatContent) {
                            [chatArray addObject:[object valueForKey:@"content"]];
                            [chat_sentByArray addObject:[object valueForKey:@"type"]];
                            [createdDateArray addObject:[object valueForKey:@"created"]];
                        }
                        [_ChatTableView reloadData];
                        [_ChatTableView setNeedsLayout];
                        [_ChatTableView layoutIfNeeded];
                        [_ChatTableView setNeedsUpdateConstraints];
                        [self.HelpTripScrlVW setNeedsUpdateConstraints];
                        [_ChatTableView reloadData];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self ScrollToTheLastView];
                            
                            [UIView animateWithDuration:0.0 animations:^{
                                [self ScrollToTheLastView];
                                
                            } completion:^(BOOL finished) {
                                if (isSubmitted) {
                                    dispatch_after(0.5, dispatch_get_main_queue(), ^{
                                        [APPDELEGATE stopLoader:self.view];
                                    });
                                }
                            }];
                        });
                    }
                    NSMutableDictionary *HelpdetailsReq=[response valueForKey:@"request"];
                    NSMutableDictionary *HelpdetailsWalker=[HelpdetailsReq valueForKey:@"walker"];
                    
                    ALog(@"Help Request....%@",HelpdetailsReq);
                    ALog(@"Help Walker....%@",HelpdetailsWalker);
                    
                    _classLbl.text=[HelpdetailsWalker valueForKey:@"car_model"];
                    _IDLbl.text=[HelpdetailsReq valueForKey:@"trip_id"];
                    _DateLbl.text=[HelpdetailsReq valueForKey:@"request_date"];
                    _TimeLbl.text=[HelpdetailsReq valueForKey:@"request_time"];
                    
                    [self.DriverPic downloadFromURL:[HelpdetailsWalker valueForKey:@"picture"] withPlaceholder:nil];
                    
                    _DriverNameLbl.text=[NSString stringWithFormat:@"%@ %@",[HelpdetailsWalker valueForKey:@"first_name"],[HelpdetailsWalker valueForKey:@"last_name"]];
                    if ([[HelpdetailsWalker valueForKey:@"sec_car_model"] isEqualToString:@""]) {
                       _CarNameLbl.text=[HelpdetailsWalker valueForKey:@"car_model"];
                    }else {
                        _CarNameLbl.text=[HelpdetailsWalker valueForKey:@"sec_car_model"];
                    }
                    
                    _CarNoLbl.text= [NSString stringWithFormat:@"%@",[HelpdetailsWalker valueForKey:@"car_number"]];
                    
                    self.StarRatingView.delegate = self;
                    self.StarRatingView.emptySelectedImage = [UIImage imageNamed:@"StarEmpty"];
                    self.StarRatingView.fullSelectedImage = [UIImage imageNamed:@"StarFull"];
                    self.StarRatingView.contentMode = UIViewContentModeScaleAspectFill;
                    self.StarRatingView.maxRating = 5;
                    self.StarRatingView.minRating = 0;
                    self.StarRatingView.rating = [[HelpdetailsWalker valueForKey:@"rating"] floatValue];
                    self.StarRatingView.editable = NO;
                    self.StarRatingView.halfRatings = NO;
                    self.StarRatingView.floatRatings = YES;
                    
                    _TotalLbl.text=[HelpdetailsReq valueForKey:@"grand_total"];
                    [self.mapImageView downloadFromURL:[HelpdetailsReq valueForKey:@"map_url"] withPlaceholder:nil];
                    
                    _OriginLbl.text=[HelpdetailsReq valueForKey:@"source_address"];
                    _OriginDateTimeLbl.text=[NSString stringWithFormat:@"%@   %@",[HelpdetailsReq valueForKey:@"walk_start_date"],[HelpdetailsReq valueForKey:@"walk_start_time"]];
                    
                    _DestinationLbl.text=[HelpdetailsReq valueForKey:@"destination_address"];
                    _destDateTimeLbl.text=[NSString stringWithFormat:@"%@   %@",[HelpdetailsReq valueForKey:@"walk_end_date"],[HelpdetailsReq valueForKey:@"walk_end_time"]];
                    
                    NSMutableDictionary *dictIssues=[response valueForKey:@"issue_title"];
                    ALog(@"Dictionary Ttile...%@",dictIssues);
                    
                    questID = [response valueForKey:@"issue_id"];
                    
                    if ( [questID  isEqual: @"0"]) {
                        _DropDownHelp.userInteractionEnabled = YES;
                        ALog(@"QuestId is issue id in get help details data is Zero ---------->>>>>>>>>>>>>>= %@",questID);
                    }else {
                        _DropDownHelp.userInteractionEnabled = NO;
                        _SelectIssueLbl.text = [response valueForKey:@"issue_selected"];
                        ALog(@"QuestId is issue id in get help details data is  non Zero ---------->>>>>>>>>>>>>>= %@",questID);
                    }
                    NSMutableArray *arrIssueQuestion=[dictIssues valueForKey:@"issue_question"];
                    if(arrIssueQuestion.count>0){
                        for(NSMutableDictionary *issues in arrIssueQuestion){
                            [issuesID addObject:[issues valueForKey:@"id"]];
                            [issuesQuestions addObject:[issues valueForKey:@"issue"]];
                        }
                    }
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                    [self ScrollToTheLastView];
                    [_CommentTxtView resignFirstResponder];
                    _Submit.userInteractionEnabled=YES;
                }
                //  [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES];;
            }
            [_HelpTableVW reloadData];
            [APPDELEGATE stopLoader:self.view];
            _Submit.userInteractionEnabled=YES;
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
        _Submit.userInteractionEnabled=YES;
    }
}
- (void)QuestionViewGesture:(UITapGestureRecognizer*)sender{
    [self.view endEditing:YES];
    
    [UIView transitionWithView:_HelpDropDownContentView
                      duration:0.4
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:NULL];
    _HelpDropDownContentView.hidden=NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Rating delegate

- (void)floatRatingView:(TPFloatRatingView *)ratingView ratingDidChange:(CGFloat)rating
{
    ALog(@"%f",rating);
}
#pragma mark - Issue Tableview DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == _HelpTableVW) {
        return 1;
    } else {
        return chatArray.count;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == _HelpTableVW) {
        return issuesID.count;
    } else {
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    // Configure the cell...
    if (tableView == _HelpTableVW) {
        
        HelpTripDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Helptripcell" forIndexPath:indexPath];
        
        if (cell == nil) {
            cell=[[HelpTripDetailsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Helptripcell"];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.textColor = [UIColor blackColor];
        
        if(issuesQuestions.count > 0){
            cell.IssuesLbl.text=[issuesQuestions objectAtIndex:indexPath.row];
        }
        return cell;
    } else {
        static NSString *CellIdentifier = @"ChatDetailsTableViewCell";
        
        ChatDetailsTableViewCell *cell = (ChatDetailsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            [tableView registerNib:[UINib nibWithNibName:@"ChatDetailsTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
            cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        }
        cell.chatDataLabel.text = [chatArray objectAtIndex:indexPath.section];
        cell.chatDataLabel.font = [UIFont fontWithName:@"Dinpro" size:13.0];
        cell.timeLabel.text = [createdDateArray objectAtIndex:indexPath.section];
        cell.timeLabel.font = [UIFont fontWithName:@"Dinpro" size:10.0];
        cell.timeLabel.textColor = [UIColor colorWithRed:0.4 green:0.4 blue:0.4 alpha:1];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell layoutIfNeeded];
        [cell setNeedsLayout];
        [self.ChatTableView setNeedsUpdateConstraints];
        cell.layer.cornerRadius=5;
        cell.clipsToBounds=YES;
        cell.layer.borderWidth=0.4;
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.layer.borderColor=[UIColor colorWithRed:0.831 green:0.831 blue:0.831 alpha:1].CGColor;
        if([(NSString *)[chat_sentByArray objectAtIndex:indexPath.section] isEqualToString:@"user"]) {
            cell.contentView.backgroundColor = [UIColor colorWithRed:0.964 green:0.964 blue:0.964 alpha:1];
        } else {
            //hexa  : fff7c2
            cell.contentView.backgroundColor = [UIColor colorWithRed:1.0 green:0.9686 blue:0.760 alpha:1];
        }
        return cell;
    }
    
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _HelpTableVW) {
        cell.separatorInset = UIEdgeInsetsZero;
        if(IS_OS_8_OR_LATER>8.0){
            cell.preservesSuperviewLayoutMargins = false;
        }
        
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
            [cell setSeparatorInset:UIEdgeInsetsZero];
        }
        
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:UIEdgeInsetsZero];
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _HelpTableVW) {
        _SelectIssueLbl.text=[issuesQuestions objectAtIndex:indexPath.row];
        questID=[issuesID objectAtIndex:indexPath.row];
        ALog(@"QuestId is issue id in didSelect row at indexpath ---------->>>>>>>>>>>>>>= %@",questID);
        
        [UIView transitionWithView:_HelpDropDownContentView
                          duration:0.4
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:NULL
                        completion:NULL];
        
        _HelpDropDownContentView.hidden=YES;
    }else{
        return;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (tableView == _HelpTableVW) {
        return 0.0;
    }else {
        return 10.0; // you can have your own choice, of course
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView == _HelpTableVW) {
        UIView *headerView1 = [[UIView alloc] init];
        headerView1.frame = CGRectZero;
        return headerView1;
    } else {
        UIView *headerView = [[UIView alloc] init];
        headerView.backgroundColor = [UIColor whiteColor];
        return headerView;
    }
}

# pragma mark - Submit

- (IBAction)Submit:(id)sender {
    
    if ( [questID  isEqual: @"0"]) {
        [_CommentTxtView resignFirstResponder];
        _DropDownHelp.userInteractionEnabled = YES;
        ALog(@"QuestId Zero in submit buttton function ---------->>>>>>>>>>>>>>= %@",questID);
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_SELECT_AN_ISSUE view:self.view]];
        [customAlertView show];
        return;
    }else {
        
        if ([_CommentTxtView.text  isEqual: @""]) {
            [sender setUserInteractionEnabled:NO];
            [_CommentTxtView resignFirstResponder];
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_ISSUE_DESCRIPTION view:self.view]];
            [customAlertView show];
            [sender setUserInteractionEnabled:YES];
            return;
        }
        
        if ([_CommentTxtView.text  isEqual: @""]) {
            [_CommentTxtView resignFirstResponder];
            [self sendChatDataToServer];
        }else {
            _DropDownHelp.userInteractionEnabled = NO;
            _Submit.userInteractionEnabled=NO;
            _dropDownImageView.hidden = YES;
            [_CommentTxtView resignFirstResponder];
            [self sendChatDataToServer];
            isSubmitted = true;
        }
    }
}

-(void)viewWillLayoutSubviews{
    
    CGFloat height = self.ChatTableView.contentSize.height;
    ALog(@"chat tableview frame = %@, content height = %f", NSStringFromCGRect(_ChatTableView.frame), height);
    _ChatTableViewHeightConstraint.constant = height;
    CGRect frame = _ChatTableView.frame;
    frame.size.height = [_ChatTableView sizeThatFits:CGSizeMake(frame.size.width, HUGE_VALF)].height;
    _ChatTableView.frame = frame;
    [_HelpTripScrlVW setContentSize:CGSizeMake(self.view.frame.size.width, CGRectGetMaxY(_LastView.frame))];
    [super viewWillLayoutSubviews];
}


-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    
    if (_HelpTableVW.contentSize.height <= 270) {
        _HelpTableVWHeightConstraint.constant = _HelpTableVW.contentSize.height;
    }else {
        _HelpTableVWHeightConstraint.constant = 270;
    }
    ALog(@"scrollViewSize = %@, tableviewsize = %@, textviewsize = %@, and buttonframe = %@, totalViewsize = %@",NSStringFromCGRect(_HelpTripScrlVW.frame),NSStringFromCGRect(_ChatTableView.frame) , NSStringFromCGRect(_CommentTxtView.frame), NSStringFromCGRect(_Submit.frame), NSStringFromCGRect(self.view.frame));
}

-(void)ScrollToTheLastView{
    if (isSubmitted) {
        CGPoint bottomOffset = CGPointMake(0, self.HelpTripScrlVW.contentSize.height - self.HelpTripScrlVW.bounds.size.height);
        [self.HelpTripScrlVW setContentOffset:bottomOffset animated:YES];
        
    }
}
- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    _CommentTxtView.delegate=self;
    
    UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
    [keyboardDoneButtonView sizeToFit];
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                   style:UIBarButtonItemStylePlain target:self
                                                                  action:@selector(doneClicked:)];
    [doneButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];
    [keyboardDoneButtonView setItems:[NSArray arrayWithObjects:flexibleSpaceLeft,doneButton, nil]];
    _CommentTxtView.inputAccessoryView = keyboardDoneButtonView;
    
    
}
- (IBAction)doneClicked:(id)sender
{
    [_CommentTxtView resignFirstResponder];
    isSubmitted = NO;
    
}

-(void)sendChatDataToServer{
    if([APPDELEGATE connected])  {
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        
        //developer.lymo.ae/user/help_detail?token=2y10e2zjnI1cNgqMB4897tmlUO5AnaAfreDNXojI2LAfFiiRKQJz2NWO&id=35&request_id=109
        
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:_request_id forKey:PARAM_REQUEST_ID];
        [dictParam setValue:questID forKey:PARAM_ISSUE_ID];
        ALog(@"QuestId is issue id in send chat data to server -------->>>>>>>>>>>>>>= %@",questID);
        [dictParam setValue:_CommentTxtView.text forKey:PARAM_ISSUE];
        [dictParam setValue:_SelectIssueLbl.text forKey:PARAM_ISSUE_TITLE];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_REQUEST_HELP withParamData:dictParam withBlock:^(id response, NSError *error)
         {
             if (response == Nil){
                 if (error.code == -1005) {
                     [APPDELEGATE stopLoader:self.view];
                     [self sendChatDataToServer];
                     
                 }else {
//                     [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                     [customAlertView show];
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPDELEGATE stopLoader:self.view];
                         [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                     });
                 _Submit.userInteractionEnabled=YES;
                 isSubmitted = NO;
                 }
             }else if (response)
             {
                 [_CommentTxtView setText:@""];
                 ALog(@"Help Request Submit Response ---> %@",response);
                 if([[response valueForKey:@"success"]boolValue]){
                     [_CommentTxtView setText:@""];
                     _PlaceholderLbl.hidden = NO;
                     //                     dispatch_async(dispatch_get_main_queue(), ^{
                     //                         [APPDELEGATE showToastMessage:[response valueForKey:@"message"]];
                     //                     });
                     [self getHelpDetailsData];
                 }
                 else{
                     [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                     [customAlertView show];
                     
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [self ScrollToTheLastView];
                         [_CommentTxtView resignFirstResponder];
                         _Submit.userInteractionEnabled=YES;
                     });
                 }
                 // [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES];;
             }
             [_HelpTableVW reloadData];
         }];
        
    }else{
        _Submit.userInteractionEnabled=YES;
        [self ScrollToTheLastView];
        [_CommentTxtView resignFirstResponder];
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


#pragma mark - Textview Placeholder

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if (range.location == 0 && [text isEqualToString:@" "]) {
        return NO;
    }
    return YES;
}


- (void)textViewDidEndEditing:(UITextView *)textView
{
    if ([textView hasText]) {
        _PlaceholderLbl.hidden = YES;
        
    } else {
        _PlaceholderLbl.hidden = NO;
    }
    [_ChatTableView reloadData ];
    [self ScrollToTheLastView];
    isSubmitted = NO;
}

- (void) textViewDidChange:(UITextView *)textView
{
    if(![textView hasText]) {
        _PlaceholderLbl.hidden = NO;
    }
    else{
        _PlaceholderLbl.hidden = YES;
        
    }
}

- (BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    if(![textView hasText]) {
        _PlaceholderLbl.hidden = NO;
    }
    else{
        _PlaceholderLbl.hidden = YES;
    }
    return  YES;
}

- (IBAction)Back:(id)sender {
    if([_strForCurrentPage isEqualToString:@"helpList"]){
        [self.navigationController popViewControllerAnimated:NO];
    }else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark - Textfield delegate


-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    _inVoiceKBAvoidingScrollView.scrollEnabled=NO;
    //[_promoCodeTxt resignFirstResponder];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    // Not found, so remove keyboard.
    [textField resignFirstResponder];
    _inVoiceKBAvoidingScrollView.scrollEnabled=YES;
    return YES;
}

-(void)hideInvoiceKeyboard:(UITapGestureRecognizer* )sender {
    ALog(@"Innner view is called so hide keyboard");
    [_invoiceEmailTextField resignFirstResponder];
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if ([string isEqualToString:@" "]) {
        return NO;
    }
    return YES;
}
#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    
    if ([alertView tag] == 123) {
        [self.view endEditing:YES];
        [self.navigationController popViewControllerAnimated:NO];
    }
    [alertView close];
}


#pragma mark - Receipt button action

-(void)Receipt:(id)sender{
    if([APPDELEGATE connected]){
        _inVoiceBigView.hidden=NO;
        [_invoiceEmailTextField becomeFirstResponder];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
    
    //    [self createCustomAlertViewToAcceptTheEmailFromUser];
}

- (void)invoiceCancelBtnPressed{
    [self.view endEditing:YES];
    //    _invoiceEmailTextField.text=[[NSUserDefaults standardUserDefaults] valueForKey:PREF_USER_EMAIL];
    _inVoiceBigView.hidden=YES;
}

- (void)invoiceSendBtnPressed{
    [_invoiceEmailTextField resignFirstResponder];
    
    if([APPDELEGATE connected]){
        if(_invoiceEmailTextField.text.length<1){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_EMAIL view:self.view]];
            [customAlertView show];
        }else{
            if([[UtilityClass sharedObject]validateEmail:_invoiceEmailTextField.text]){
                NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                NSUserDefaults* pref = [NSUserDefaults standardUserDefaults];
                [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
                [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
                [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
                [dictParam setValue:_request_id forKey:PARAM_REQUEST_ID];
                [dictParam setValue:_invoiceEmailTextField.text forKey:PARAM_EMAIL];
                ALog(@"receipt send mail button  dictionary = %@", dictParam);
                
                [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
                AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                [afn getDataFromPath:FILE_RECEIPT withParamData:dictParam withBlock:^(id response, NSError *error)
                 {
                     if (response == Nil){
                         if (error.code == -1005) {
                             [APPDELEGATE stopLoader:self.view];
                             [self invoiceSendBtnPressed];
                             
                         }else {
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [APPDELEGATE stopLoader:self.view];
                                 [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                             });
//                             [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                             [customAlertView show];
                         }
                     }else if (response)
                     {
                         if([[response valueForKey:@"success"]boolValue])
                         {
                             ALog(@"receipt send mail button Response ---> %@",response);
                             _invoiceEmailTextField.text=@"";
                             _inVoiceBigView.hidden=YES;
                             [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                             [customAlertView show];
                         }
                         else{
                             [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                             [customAlertView show];
                         }
                     }
                     [APPDELEGATE stopLoader:self.view];
                 }];
                
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_EMAIL view:self.view]];
                [customAlertView show];
            }
        }
    }
    else
    {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}

-(void)createCustomAlertViewToAcceptTheEmailFromUser{
    CustomIOSAlertView *alertView = [[CustomIOSAlertView alloc] init];
    UITextField *emailTextField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width - 60, 50)];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:PREF_USER_EMAIL]) {
        emailTextField.text=[[NSUserDefaults standardUserDefaults] valueForKey:PREF_USER_EMAIL];
    }
    emailTextField.backgroundColor=[UIColor whiteColor];
    emailTextField.borderStyle=UITextBorderStyleRoundedRect;
    emailTextField.delegate=self;
    emailTextField.textAlignment=NSTextAlignmentCenter;
    [emailTextField becomeFirstResponder];
    emailTextField.placeholder=@"Enter your email here";
    UIView *holderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, emailTextField.frame.size.width, emailTextField.frame.size.height)];
    [holderView setBackgroundColor: [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4f]];
    emailTextField.center=holderView.center;
    [holderView addSubview:emailTextField];
    
    [alertView setContainerView:holderView];
    [alertView setButtonTitles:[NSMutableArray arrayWithObjects:@"Cancel", @"Send", nil]];
    alertView.tag=101;
    alertView.delegate=self;
    [alertView show];
}

//-(void)myAddFunctionFirstParam: (int)param1 SecondParam: (int)param2 completion: ^(int result);

@end

