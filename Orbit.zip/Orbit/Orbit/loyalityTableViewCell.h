//
//  loyalityTableViewCell.h
//  
//
//  Created by ActiveMac03 on 24/12/15.
//
//

#import <UIKit/UIKit.h>

@interface loyalityTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *tag1;
@property (weak, nonatomic) IBOutlet UILabel *tag2;
@property (weak, nonatomic) IBOutlet UILabel *tag3;
@property (weak, nonatomic) IBOutlet UILabel *tag4;
@property (weak, nonatomic) IBOutlet UILabel *tag5;
@property (weak, nonatomic) IBOutlet UILabel *tag6;

@end
