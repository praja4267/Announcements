//
//  PaymentMenuViewController.m
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import "PaymentMenuViewController.h"
#import "REFrostedViewController.h"
#import "Constants.h"
#import "MenuCardViewController.h"
#import "AppDelegate.h"
#import "CardDeleteViewController.h"


@interface PaymentMenuViewController ()<CAPSPageMenuDelegate>{
    
    NSString *toCardName,*toCardIcon,*toCardNumber,*toCardID,*toCardDefault, *toCardExpiryDate;
}

@property (nonatomic) CAPSPageMenu *pageMenu;

@end

@implementation PaymentMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   [_PaymentAddBtn setExclusiveTouch:YES];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
   if ([[[NSUserDefaults standardUserDefaults] valueForKey:PREF_SETTING_CARD_PAYMENT] boolValue]) {
       _PaymentAddBtn.hidden=NO;
    }else {
       _PaymentAddBtn.hidden=YES;
    }
    
    //Set the webviews delegate to this
    
    

}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardPayment" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PaymentMenuVC" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [APPDELEGATE stopLoader:self.view];
    //  Notification
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardPayment" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(CardPay:) name:@"CardPayment" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PaymentMenuVC" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(MenuCard:) name:@"PaymentMenuVC" object:nil];
    [self getPaymentpage];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"CardPayment" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PaymentMenuVC" object:nil];
}

-(void)getPaymentpage {
    _pageMenu.delegate=self;
    MenuCardViewController *controller1 = [self.storyboard instantiateViewControllerWithIdentifier:@"MenuCardViewController"];
    controller1.title = @"My Saved Cards";
//    MenuWalletViewController *controller2 = [self.storyboard instantiateViewControllerWithIdentifier:@"MenuWalletViewController"];
//    controller2.title = @"Wallet";
    
    NSArray *controllerArray = @[controller1];//@[controller1, controller2];
    
    NSDictionary *parameters = @{
                                 CAPSPageMenuOptionScrollMenuBackgroundColor: [UIColor whiteColor],
                                 CAPSPageMenuOptionViewBackgroundColor: [UIColor whiteColor],
                                 CAPSPageMenuOptionSelectionIndicatorColor: [UIColor colorWithRed:224.0/255.0 green:224.0/255.0 blue:224.0/255.0 alpha:1.0],
                                 CAPSPageMenuOptionBottomMenuHairlineColor: [UIColor colorWithRed:224.0/255.0 green:224.0/255.0 blue:224.0/255.0 alpha:1.0],
                                 CAPSPageMenuOptionMenuItemFont: [UIFont fontWithName:@"Dinpro-Bold" size:14.0],
                                 CAPSPageMenuOptionMenuHeight: @(53.0),
                                 CAPSPageMenuOptionMenuItemWidth: @(130.0),
                                 CAPSPageMenuOptionCenterMenuItems: @(NO),
                                 CAPSPageMenuOptionSelectionIndicatorHeight:@(0.0),
                                 CAPSPageMenuOptionSelectedMenuItemLabelColor:[UIColor blackColor],
                                 CAPSPageMenuOptionUnselectedMenuItemLabelColor:[UIColor orbitBlackColorhex7],
                                 CAPSPageMenuOptionScrollMenuBackgroundColor:[UIColor colorWithRed:224.0/255.0 green:224.0/255.0 blue:224.0/255.0 alpha:1.0],
                                 CAPSPageMenuOptionMenuItemSeparatorPercentageHeight:@(1.0)
//                                 CAPSPageMenuOptionUseMenuLikeSegmentedControl:@(YES) // uncomment This line for center alignment
                                 };
    
    _pageMenu = [[CAPSPageMenu alloc] initWithViewControllers:controllerArray frame:CGRectMake(0.0, 67, self.view.frame.size.width, self.view.frame.size.height) options:parameters];
    [self.view addSubview:_pageMenu.view];
}

- (IBAction)menuBtn:(id)sender {
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}

- (IBAction)paymentAddNewBtn:(id)sender {
    if ([APPDELEGATE connected]) {
         [self performSegueWithIdentifier:STRING_SEGUE_PAYMENT_ADD_NEW_CARD sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
   
}

- (void) CardPay:(NSNotification *)notification{
    NSString *codeInfo = notification.object;
    ALog(@"Add.... %@",codeInfo);
    if ([codeInfo isEqualToString:@"1"]) {
        _PaymentAddBtn.hidden=NO;
    }
    else if([codeInfo isEqualToString:@"0"]){
        _PaymentAddBtn.hidden=YES;
    }
}

- (void) MenuCard:(NSNotification *)notification{
     NSDictionary *PaymentCode = notification.userInfo;
    
    toCardName=[PaymentCode valueForKey:@"Name"];
    toCardNumber=[PaymentCode valueForKey:@"Number"];
    toCardIcon=[PaymentCode valueForKey:@"Icon"];
    toCardID=[PaymentCode valueForKey:@"ID"];
    toCardDefault=[PaymentCode valueForKey:@"Default"];
    toCardExpiryDate=[PaymentCode valueForKey:@"expiry_date"];
    [self performSegueWithIdentifier:@"paymentToDeletecardSegue" sender:self];
}


-(void)cardAddedFromWebViewWithMessage:(NSString *)message{
    
    [customAlertView setContainerView:[APPDELEGATE createDemoView:message view:self.view]];
    [customAlertView show];
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:message message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//    [alert show];
}


#pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:@"paymentToDeletecardSegue"]) {
        CardDeleteViewController *CardDeleteactivity = (CardDeleteViewController *)segue.destinationViewController;
        
        CardDeleteactivity.toDeleteCardName= toCardName;
        CardDeleteactivity.toDeleteCardNumber= toCardNumber;
        CardDeleteactivity.toDeleteCardIcon= toCardIcon;
        CardDeleteactivity.toDeleteCardID= toCardID;
        CardDeleteactivity.toDeleteCardDefault= toCardDefault;
        CardDeleteactivity.toDeleteCardExpiryDate=toCardExpiryDate;
    }else if ([segue.identifier isEqualToString:STRING_SEGUE_PAYMENT_ADD_NEW_CARD]){
        addCardViewController *Addcardcntl= (addCardViewController *)segue.destinationViewController;
        Addcardcntl.addcardDelegate=self;
    }
}




#pragma mark - Custom Popup Delegate
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
