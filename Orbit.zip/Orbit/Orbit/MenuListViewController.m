//
//  MenuListViewController.m
//
//
//  Created by Active Mac06 on 04/12/15.
//
//

#import "MenuListViewController.h"
#import "MyRideViewController.h"
#import "MenuNavigationViewController.h"
#import "LandingPageViewController.h"
#import "REFrostedViewController.h"
#import "HelpViewController.h"
#import "PaymentMenuViewController.h"
#import "referEarnViewController.h"
#import "notificationViewController.h"
#import "Constants.h"
#import "UIImageView+Download.h"
#import "loyalityViewController.h"
#import "AppDelegate.h"
#import "MenuListTableViewCell.h"

@interface MenuListViewController () {
    NSMutableArray *menuList;
    NSMutableArray *menuListIcon;
//    NSMutableArray *menuListIconSelected;
    NSIndexPath *selectedIndexPath;
    BOOL isProfile;
}

@property (strong, nonatomic) IBOutlet UITableView *MenuTableView;

@end

@implementation MenuListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    menuList=[[NSMutableArray alloc]init];
    menuListIcon=[[NSMutableArray alloc]init];
//    menuListIconSelected=[[NSMutableArray alloc]init];
    
    _MenuTableView.tableFooterView = [UIView new];
    _MenuTableView.delegate=self;
    
    //Enable Gesture action for NavBackButton
    UITapGestureRecognizer *menuProfileViewtapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(menuProfileViewGesture:)];
    _menuProfileView.userInteractionEnabled = YES;
    [_menuProfileView addGestureRecognizer:menuProfileViewtapRecognizer];
    _menuProfileIcon.layer.cornerRadius=33;
    _menuProfileIcon.clipsToBounds = YES;
    isProfile=NO;
    [_MenuTableView registerNib:[UINib nibWithNibName:@"MenuListTableViewCell" bundle:nil] forCellReuseIdentifier:@"MenuListCell"];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
   
 /*   NSString *profileName = [pref objectForKey:PREF_USER_NAME];
    if (profileName.length>15) {
        NSString *newString = [profileName substringToIndex:15];
        newString = [newString stringByAppendingString:@"…"];
        
        _menuProfileNameLbl.text=newString;
    } else {
        _menuProfileNameLbl.text=profileName;
    }
 */
    _menuProfileNameLbl.text=[pref objectForKey:PREF_USER_NAME];
    [_menuProfileIcon downloadFromURL:[pref objectForKey:PREF_PROFILE_PIC] withOutLoader:nil];
    [menuList removeAllObjects];
    
    if([[pref valueForKey:PREF_SETTING_MENU_BOOK_RIDE] boolValue]){
        [menuList addObject:@"Book a Ride"];
        [menuListIcon addObject:@"Book_icon"];
//        [menuListIconSelected addObject:@"Book_icon"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_MY_RIDE] boolValue]){
        [menuList addObject:@"My Rides"];
        [menuListIcon addObject:@"Ride_icon"];
//        [menuListIconSelected addObject:@"Ride_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_PAYMENT] boolValue]){
        [menuList addObject:@"Payment"];
        [menuListIcon addObject:@"Payment_icon"];
//        [menuListIconSelected addObject:@"Payment_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_LOYALTY] boolValue]){
        [menuList addObject:@"Loyalty"];
        [menuListIcon addObject:@"Loyalty_icon"];
//        [menuListIconSelected addObject:@"Loyalty_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_REFERAL] boolValue]){
        [menuList addObject:@"Referral"];
        [menuListIcon addObject:@"Referral_icon"];
//        [menuListIconSelected addObject:@"Referral_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_NOTIFICATION] boolValue]){
        [menuList addObject:@"Notification"];
        [menuListIcon addObject:@"Notification_icon"];
//        [menuListIconSelected addObject:@"Notification_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_HELP] boolValue]){
        [menuList addObject:@"Help"];
        [menuListIcon addObject:@"Help_icon"];
//        [menuListIconSelected addObject:@"Help_select"];
    }
    if([[pref valueForKey:PREF_SETTING_MENU_ABOUT] boolValue]){
        [menuList addObject:@"About"];
        [menuListIcon addObject:@"About_icon"];
//        [menuListIconSelected addObject:@"About_select"];
    }
    [_MenuTableView reloadData];
}
- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (SCREEN_HEIGHT<=568) // iphone 4
    {
        _MenuTableView.scrollEnabled=YES;
    }
    else // iphone 5, 6 and 6+
    {
        _MenuTableView.scrollEnabled=NO;
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if([menuList count]==0){
        return 0;
    }
    return menuList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"MenuListCell";
    
    MenuListTableViewCell *cell = (MenuListTableViewCell *) [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
//    [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell == nil) {
//        [tableView registerNib:[UINib nibWithNibName:@"MenuListTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
//        cell=[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    }
    cell.label.font=[UIFont fontWithName:@"Dinpro-Medium" size:16];
    cell.label.backgroundColor=[UIColor clearColor];
    cell.label.textColor = [UIColor blackColor];
    if([menuList count]>0){
        cell.label.text=menuList[indexPath.row];
        cell.sideImage.image=nil;
        cell.sideImage.image=[UIImage imageNamed:menuListIcon[indexPath.row]];
        if (indexPath.row==selectedIndexPath.row) {
            cell.backGroundImage.image=[UIImage imageNamed:@"TVCell_selecetd"];
        }else{
            cell.backGroundImage.image=nil;
        }
        if (isProfile) {
//            cell.textLabel.textColor = [UIColor blackColor];
//            cell.imageView.image=[UIImage imageNamed:menuListIcon[indexPath.row]];
            selectedIndexPath=nil;
        }
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50.0; //or whatever value
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    selectedIndexPath=indexPath;
    isProfile=NO;
    if ([APPDELEGATE connected]) {
        MenuNavigationViewController *navigationController = [self.storyboard instantiateViewControllerWithIdentifier:@"contentController"];
        if(indexPath.section == 0 && indexPath.row == 0){   // && [menuList[indexPath.row] isEqualToString:@"Book a Ride"] -> this can not be done because the root view controller for menu is landingpage view controller.
            LandingPageViewController *bookingPageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LandingPageViewController"];
            navigationController.viewControllers = @[bookingPageViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"My Rides"]){
            MyRideViewController *myRideViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyRideViewController"];
            navigationController.viewControllers = @[myRideViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"Payment"]){
            PaymentMenuViewController *paymentPageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PaymentMenuViewController"];
            navigationController.viewControllers = @[paymentPageViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"Loyalty"]){
            loyalityViewController *loyaltyViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"loyalityViewController"];
            navigationController.viewControllers = @[loyaltyViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"Referral"]){
            referEarnViewController *referPageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"referEarnViewController"];
            navigationController.viewControllers = @[referPageViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"Notification"]){
            notificationViewController *helpViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"notificationViewController"];
            navigationController.viewControllers = @[helpViewController];
            ALog(@"notification");
        }else if([menuList[indexPath.row] isEqualToString:@"Help"]){
            HelpViewController *helpViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"HelpViewController"];
            navigationController.viewControllers = @[helpViewController];
        }else if([menuList[indexPath.row] isEqualToString:@"About"]){
            HelpViewController *aboutViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AboutUs"];
            navigationController.viewControllers = @[aboutViewController];
        }
        [tableView reloadData];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Gesture Action


- (void)menuProfileViewGesture:(UITapGestureRecognizer*)sender {
    if ([APPDELEGATE connected]) {
        isProfile=YES;
        MenuNavigationViewController *navigationController = [self.storyboard instantiateViewControllerWithIdentifier:@"contentController"];
        LandingPageViewController *profilePageViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ProfileVC"];
        navigationController.viewControllers = @[profilePageViewController];
        self.frostedViewController.contentViewController = navigationController;
        [self.frostedViewController hideMenuViewController];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}


@end
