//
//  MyRideViewController.h
//  
//
//  Created by ActiveMac03 on 10/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"


@interface MyRideViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}
- (IBAction)myRideMenu:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *myRidesEmptyView;
@property (weak, nonatomic) IBOutlet UIImageView *myRideEmptyCarIcon;
@property (weak, nonatomic) IBOutlet UILabel *myRideEmptyLabel;
@property NSInteger pageIndex;
@end
