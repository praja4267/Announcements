//
//  DEMOViewController.m
//  REFrostedViewControllerStoryboards
//
//  Created by Roman Efimov on 10/9/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMORootViewController.h"
#import "RideCompleteVC.h"

@interface DEMORootViewController ()

@end

@implementation DEMORootViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.contentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"contentController"];
    self.menuViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MenuListViewController"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"rideComplete" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rideCompleteNotification:) name:@"rideComplete" object:nil];
}

- (void) rideCompleteNotification:(NSNotification *)notification{
    RideCompleteVC *rideComplete =[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"rideCompleteController"];
    rideComplete.lastWalkId = @"-1";
    [self presentViewController:rideComplete animated:YES completion:nil];
}

@end
