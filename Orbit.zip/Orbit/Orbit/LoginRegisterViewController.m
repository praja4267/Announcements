//
//  LoginRegisterViewController.m
//
//
//  Created by ActiveMac03 on 14/11/15.
//
//

#import "LoginRegisterViewController.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"
#import "UtilityClass.h"
#import "lymoSingleton.h"
#import <GoogleSignIn/GoogleSignIn.h>
#import "googleSignInDataModal.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "UIColor+CustomColor.h"
#define ACCEPTABLE_CHARACTERS @" ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.\'"

@interface LoginRegisterViewController ()<GIDSignInUIDelegate>{
    BOOL internet;
    BOOL fixed;
    NSString *loginType;
    NSString  *currentDeviceId;
    CustomIOSAlertView *customAlertView;
    NSUserDefaults *pref;
}


@end

@implementation LoginRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //TEXTFIELD DELEGATE
    _signupNameTxt.delegate=self;
    _signupEmailTxt.delegate=self;
    _signupPasswordTxt.delegate=self;
    _loginEmailTxt.delegate=self;
    _loginPasswordTxt.delegate=self;
    _forgetPasswordEmailTxt.delegate=self;
    _socialMailNameTxt.delegate=self;
    _socialMailEmailTxt.delegate=self;
    
    //view corner radius
    _loginSubView.layer.cornerRadius=2;
    _signupSubView.layer.cornerRadius=2;
    _forgetPasswordSubView.layer.cornerRadius=2;
    _socialMailSubView.layer.cornerRadius=2;
    
    //button corner radius
    _homeFBBtn.layer.cornerRadius=2;
    _homeGoogleBtn.layer.cornerRadius=2;
    _homeLoginBtn.layer.cornerRadius=2;
    _homeSignupBtn.layer.cornerRadius=2;
    _signupBtn.layer.cornerRadius=2;
    _loginBtn.layer.cornerRadius=2;
    _forgetPasswordBtn.layer.cornerRadius=2;
    _socialMailConfirmBtn.layer.cornerRadius=2;
    
    [_homeFBBtn setExclusiveTouch:YES];
    [_homeGoogleBtn setExclusiveTouch:YES];
    [_homeLoginBtn setExclusiveTouch:YES];
    [_homeSignupBtn setExclusiveTouch:YES];
    
    UITapGestureRecognizer *singleTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
    singleTapGestureRecognizer.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:singleTapGestureRecognizer];
    
    _homeView.hidden=NO;
    _signupView.hidden=YES;
    _loginView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _socialMailView.hidden=YES;
    fixed=0;
    UIDevice *device = [UIDevice currentDevice];
    currentDeviceId = [[device identifierForVendor]UUIDString];
    [lymoSingleton sharedInstance].globaldictionary=[[NSMutableDictionary alloc] init];
     
    [GIDSignIn sharedInstance].uiDelegate = self;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
    pref =[NSUserDefaults standardUserDefaults];
    ALog(@"Logout Name......%@",[pref valueForKey:PREF_USER_NAME]);
    [self setOrbitYellowColor];
}


-(void)setOrbitYellowColor{
    _forgetPasswordBtn.backgroundColor=[UIColor orbitYellowColor];
    [_signupBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_loginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_forgetPasswordBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginEmailPage" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"googleSignIn" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginWithEmailProvided" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginEmailPageNotification:) name:@"loginEmailPage" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(googleSignInNotification:) name:@"googleSignIn" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginWithEmailProvidedFunction:) name:@"loginWithEmailProvided" object:nil];
    FBSDKLoginManager *fblogin = [[FBSDKLoginManager alloc] init];
    [fblogin logOut];
    [super viewWillAppear:animated];
}

- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginEmailPage" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"googleSignIn" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginWithEmailProvided" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [customAlertView close];
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginEmailPage" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"googleSignIn" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"loginWithEmailProvided" object:nil];
}

#pragma mark - button actions

-(IBAction)onClickLoginBtn:(id)sender {
    [self registerToReceivePushNotification];
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    _homeView.hidden=YES;
    _signupView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _socialMailView.hidden=YES;
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:nil
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self.view bringSubviewToFront:_loginView];
                        [self animateViewHeight:_loginView withAnimationType:kCATransitionFromTop];
                        self.view.userInteractionEnabled=YES;
                        fixed=1;
                    }];
    
}

-(IBAction)onClickSignupBtn:(id)sender{
    [self registerToReceivePushNotification];
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    _homeView.hidden=YES;
    _loginView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _socialMailView.hidden=YES;
    
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:nil
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self.view bringSubviewToFront:_signupView];
                        [self animateViewHeight:_signupView withAnimationType:kCATransitionFromTop];
                        self.view.userInteractionEnabled=YES;
                        fixed=1;
                    }];
}

-(IBAction)onClickFBBtn:(id)sender{
    [self registerToReceivePushNotification];
    if([APPDELEGATE connected])  {
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login logOut];
        login.loginBehavior = FBSDKLoginBehaviorBrowser;
        [login logInWithReadPermissions:@[@"email"] handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            {
                if (error) {
                    ALog(@"Process error");
                } else if (result.isCancelled) {
                    ALog(@"Cancelled");
                } else if ([result.grantedPermissions containsObject:@"email"]){
                        ALog(@"result is:%@",result);
                        ALog(@"Logged in");
                        if ([FBSDKAccessToken currentAccessToken]) {
                            
                            [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me"
                                                               parameters:@{@"fields": @"picture, email, id, name, first_name, last_name, middle_name"}]
                             startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                                 if (!error) {
                                     loginType=@"facebook";
                                     [pref setObject:loginType forKey:@"login_type"];
                                     ALog(@"email is %@", [result objectForKey:@"email"]);
                                     ALog(@"id is %@", [result objectForKey:@"id"]);
                                     ALog(@"name is %@", [result objectForKey:@"name"]);
                                     ALog(@"first_name is %@", [result objectForKey:@"first_name"]);
                                     ALog(@"last_name is %@", [result objectForKey:@"last_name"]);
                                     ALog(@"middle_name is %@", [result objectForKey:@"middle_name"]);
                                     //
                                     //                              NSString *pictureURL = [NSString stringWithFormat:@"%@",[result objectForKey:@"picture"]];
                                     //                              NSData  *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:pictureURL]];
                                     //                              UIImage *image = [UIImage imageWithData:data];
                                     //                              ALog(@"fetched user:%@", result);
                                     //
                                     //                              NSString* fbid = [result objectForKey:@"id"];
                                     //
                                     //                              NSString* name = [result objectForKey:@"name"];
                                     //                              NSString* fbfirstName = [result objectForKey:@"first_name"];
                                     //                              NSString* lastname = [result objectForKey:@"last_name"] ;
                                     //                              NSString* midname = [result objectForKey:@"middle_name"];
                                     //                              NSString* fbmailid = [result objectForKey:@"email"];
                                     
                                     ALog(@"%@",[result objectForKey:@"email"]);
                                     NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                                     [dictParam setValue:@"ios" forKey:PARAM_DEVICE_TYPE];
                                     [dictParam setValue:[pref valueForKey:PREF_DEVICE_TOKEN] forKey:PARAM_DEVICE_TOKEN];
                                     ALog(@"login device token = %@", [pref valueForKey:PREF_DEVICE_TOKEN]);
                                     [dictParam setValue:loginType forKey:PARAM_LOGIN_BY];
                                     if([loginType isEqualToString:@"facebook"]){
                                         [dictParam setValue:[result objectForKey:@"email"] forKey:PARAM_EMAIL];
                                         [dictParam setValue:[result objectForKey:@"id"] forKey:PARAM_SOCIAL_UNIQUE_ID];
                                         [dictParam setValue:[result objectForKey:@"name"] forKey:PARAM_FIRST_NAME];
                                     }
                                     [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
                                     [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
                                     AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                                     [afn getDataFromPath:FILE_LOGIN withParamData:dictParam withBlock:^(id response, NSError *error)
                                      {
                                          ALog(@"FB Login Response ---> %@",response);
                                          if (response == Nil){
                                              if (error.code == -1005) {
                                                  [APPDELEGATE stopLoader:self.view];
                                                  [self onClickFBBtn:sender];
                                                  
                                              }else {
                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                      [APPDELEGATE stopLoader:self.view];
                                                      [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                                                  });
                                              }
                                          }else if (response)
                                          {
                                              if([[response valueForKey:@"success"]boolValue])
                                              {
//                                                  NSString *strLog=[NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"LOGIN_SUCCESS", nil),[response valueForKey:@"first_name"]];
//                                                  [APPDELEGATE showToastMessage:strLog];
                                                  
                                                  //        [pref setObject:response forKey:PREF_LOGIN_OBJECT];
                                                  [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                                                  [pref setObject:[response valueForKey:@"lymo_device_id"] forKey:PREF_LYMO_DEVICE_ID];
                                                  [pref setObject:[response valueForKey:@"id"] forKey:PREF_USER_ID];
                                                  [pref setObject:[response valueForKey:@"is_referee"] forKey:PREF_IS_REFEREE];
                                                  [pref setObject:[response valueForKey:@"referral_code"] forKey:PREF_REFERRAL_CODE];
                                                  //[pref setObject:[response valueForKey:@"screen_status"] forKey:PREF_SCREEN_STATUS];
                                                  
                                                  [pref setObject:[response valueForKey:@"picture"] forKey:PREF_PROFILE_PIC];
                                                  [pref setObject:[response valueForKey:@"first_name"] forKey:PREF_USER_NAME];
                                                  [pref setObject:[response valueForKey:@"email"] forKey:PREF_USER_EMAIL];
                                                  
                                                  [pref setBool:YES forKey:PREF_IS_LOGIN];
                                                  
                                                  [pref setBool:YES forKey:PREF_IS_SOCIAL_LOGIN];
                                                  
                                                  [pref synchronize];
                                                  [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                                                  if([[response valueForKey:@"screen_status"] isEqual:@"1"]){
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                      [self performSegueWithIdentifier:STRING_SEGUE_BOOKING_PAGE sender:self];
                                                      });
                                                  }else if ([[response valueForKey:@"screen_status"] isEqual:@"3"]){
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                      [self performSegueWithIdentifier:STRING_SEGUE_SIGNUP_PHONE sender:self];
                                                      });
                                                  }else if ([[response valueForKey:@"screen_status"] isEqual:@"2"]){
                                                      [_signupEmailTxt resignFirstResponder];
                                                      [_signupNameTxt resignFirstResponder];
                                                      [_signupPasswordTxt resignFirstResponder];
                                                      [_loginEmailTxt resignFirstResponder];
                                                      [_loginPasswordTxt resignFirstResponder];
                                                      [_forgetPasswordEmailTxt resignFirstResponder];
                                                      [_socialMailEmailTxt resignFirstResponder];
                                                      [_socialMailNameTxt resignFirstResponder];
                                                      _homeView.hidden=YES;
                                                      _signupView.hidden=YES;
                                                      _forgetPasswordView.hidden=YES;
                                                      _loginView.hidden=YES;
                                                      
                                                      self.view.userInteractionEnabled=NO;
                                                      [UIView transitionWithView:nil
                                                                        duration:0.5
                                                                         options:UIViewAnimationOptionTransitionCrossDissolve
                                                                      animations:NULL
                                                                      completion:^(BOOL finished){
                                                                          [self.view bringSubviewToFront:_socialMailView];
                                                                          [self animateViewHeight:_socialMailView withAnimationType:kCATransitionFromTop];
                                                                          self.view.userInteractionEnabled=YES;
                                                                          fixed=1;
                                                                      }];
                                                      [pref setObject:[response objectForKey:@"first_name"] forKey:PREF_SOCIAL_NAME];
                                                      [pref synchronize];
                                                      _socialMailNameTxt.text=[pref objectForKey:PREF_SOCIAL_NAME];
                                                  }
                                              }
                                              else{
                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                      [APPDELEGATE showAlertOnTopMostControllerWithText:[response valueForKey:@"error"]];
                                                  });
                                              }
                                          }
                                          [APPDELEGATE stopLoader:self.view];
                                      }];
                                 }
                                 else{
                                     ALog(@"%@", [error localizedDescription]);
                                 }
                             }];
                        }
                    } else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [APPDELEGATE showAlertOnTopMostControllerWithText:PLEASE_GIVE_EMAIL_PERMISSION];
                        });
                    }

            }
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

-(IBAction)onClickGoogleBtn:(id)sender {
    [self registerToReceivePushNotification];
    if([APPDELEGATE connected])  {
        [[GIDSignIn sharedInstance] signIn];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)signupBtn:(id)sender {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    loginType=@"manual";
    [pref setObject:loginType forKey:@"login_type"];
    if([APPDELEGATE connected])  {
        if(_signupEmailTxt.text.length<1 || _signupNameTxt.text.length<1 || _signupPasswordTxt.text.length<1 ){
            if(_signupNameTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_NAME view:self.view]];
                [customAlertView show];
            }
            else if(_signupEmailTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_EMAIL view:self.view]];
                [customAlertView show];
            }
            else if(_signupPasswordTxt.text.length<6)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_PASSWORD view:self.view]];
                [customAlertView show];
            }
        }
        else {
            if([[UtilityClass sharedObject]validateEmail:_signupEmailTxt.text]) {
                NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                [dictParam setValue:_signupEmailTxt.text forKey:PARAM_EMAIL];
                [dictParam setValue:_signupNameTxt.text forKey:PARAM_FIRST_NAME];
                [dictParam setValue:_signupPasswordTxt.text forKey:PARAM_PASSWORD];
                ALog(@"signup device token is %@",[pref valueForKey:PREF_DEVICE_TOKEN]);
                if ([pref valueForKey:PREF_DEVICE_TOKEN]) {
                    [dictParam setValue:[pref valueForKey:PREF_DEVICE_TOKEN] forKey:PARAM_DEVICE_TOKEN];
                } else {
                    [dictParam setValue:@"0" forKey:PARAM_DEVICE_TOKEN];
                }
                [dictParam setValue:@"ios" forKey:PARAM_DEVICE_TYPE];
                [dictParam setValue:loginType forKey:PARAM_LOGIN_BY];
                [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
                ALog(@"the device request is %@",dictParam);
                [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
                AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                [afn getDataFromPath:FILE_REGISTER withParamData:dictParam withBlock:^(id response, NSError *error) {
                    
                    if (response == Nil){
                        if (error.code == -1005) {
                            [APPDELEGATE stopLoader:self.view];
                            [self signupBtn:sender];
                            
                        }else {
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [APPDELEGATE stopLoader:self.view];
                                [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                            });
                        }
                    }else if (response){
                        if([[response valueForKey:@"success"] boolValue]){
                            ALog(@"REGISTER RESPONSE --> %@",response);
//                            [APPDELEGATE showToastMessage:NSLocalizedString(@"REGISTER_SUCCESS", nil)];
               //             [pref setObject:response forKey:PREF_LOGIN_OBJECT];
                            [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                            [pref setObject:[response valueForKey:@"lymo_device_id"] forKey:PREF_LYMO_DEVICE_ID];
                            [pref setObject:[response valueForKey:@"id"] forKey:PREF_USER_ID];
                            [pref setObject:[response valueForKey:@"is_referee"] forKey:PREF_IS_REFEREE];
                            //[pref setObject:[response valueForKey:@"screen_status"] forKey:PREF_SCREEN_STATUS];
                            [pref setObject:[response valueForKey:@"picture"] forKey:PREF_PROFILE_PIC];
                            [pref setObject:[response valueForKey:@"first_name"] forKey:PREF_USER_NAME];
                            [pref setObject:[response valueForKey:@"referral_code"] forKey:PREF_REFERRAL_CODE];
                            [pref setObject:[response valueForKey:@"email"] forKey:PREF_USER_EMAIL];
                            [pref setBool:YES forKey:PREF_IS_LOGIN];
                            [pref setBool:NO forKey:PREF_IS_SOCIAL_LOGIN];
                            [pref synchronize];
                            [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                            if([[response valueForKey:@"screen_status"] isEqual:@"1"]){
                                dispatch_async(dispatch_get_main_queue(), ^{
                                [self performSegueWithIdentifier:STRING_SEGUE_BOOKING_PAGE sender:self];
                                });
                            }else if ([[response valueForKey:@"screen_status"] isEqual:@"3"]){
                                dispatch_async(dispatch_get_main_queue(), ^{
                                [self performSegueWithIdentifier:STRING_SEGUE_SIGNUP_PHONE sender:self];
                                });
                            }
                        }else{
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [APPDELEGATE showAlertOnTopMostControllerWithText:[response valueForKey:@"error"]];
                            });
                        }
                    }
                    [APPDELEGATE stopLoader:self.view];
                }];
            }else{
                
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_EMAIL view:self.view]];
                [customAlertView show];
            }
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)loginBtn:(id)sender {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    loginType=@"manual";
    [pref setObject:loginType forKey:@"login_type"];
    if([APPDELEGATE connected]){
        if(_loginEmailTxt.text.length<1 || _loginPasswordTxt.text.length<1 ){
            if(_loginEmailTxt.text.length==0){
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_REGISTERED_EMAIL view:self.view]];
                [customAlertView show];
            }else if(_loginPasswordTxt.text.length==0) {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_REGISTERED_PASSWORD view:self.view]];
                [customAlertView show];
            }
        } else {
            if([[UtilityClass sharedObject]validateEmail:_loginEmailTxt.text]){
                NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                [dictParam setValue:@"ios" forKey:PARAM_DEVICE_TYPE];
                [dictParam setValue:[pref valueForKey:PREF_DEVICE_TOKEN] forKey:PARAM_DEVICE_TOKEN];
                ALog(@"login device token = %@", [pref valueForKey:PREF_DEVICE_TOKEN]);
              //[dictParam setValue:currentDeviceId forKey:PARAM_DEVICE_TOKEN];
                [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
               [dictParam setValue:loginType forKey:PARAM_LOGIN_BY];
                if([loginType isEqualToString:@"manual"]){
                    [dictParam setValue:_loginEmailTxt.text forKey:PARAM_EMAIL];
                    [dictParam setValue:_loginPasswordTxt.text forKey:PARAM_PASSWORD];
                    
                }
                ALog(@"Login dictionary = %@", dictParam);
                [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
                AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                [afn getDataFromPath:FILE_LOGIN withParamData:dictParam withBlock:^(id response, NSError *error)
                 {
                     if (response == Nil){
                         if (error.code == -1005) {
                             [APPDELEGATE stopLoader:self.view];
                             [self loginBtn:sender];
                             
                         }else {
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [APPDELEGATE stopLoader:self.view];
                                 [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                             });
                         }
                     }else if (response)
                     {
                         if([[response valueForKey:@"success"]boolValue])
                         {
                             ALog(@"Login Response ---> %@",response);
//                             NSString *strLog=[NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"LOGIN_SUCCESS", nil),[response valueForKey:@"first_name"]];
//                             [APPDELEGATE showToastMessage:strLog];
                             [pref setBool:YES forKey:PREF_USER_OTP];
                             [pref setObject:response forKey:PREF_LOGIN_OBJECT];
                             [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                              [pref setObject:[response valueForKey:@"lymo_device_id"] forKey:PREF_LYMO_DEVICE_ID];
                             [pref setObject:[response valueForKey:@"id"] forKey:PREF_USER_ID];
                             [pref setObject:[response valueForKey:@"is_referee"] forKey:PREF_IS_REFEREE];
                             [pref setObject:[response valueForKey:@"referral_code"] forKey:PREF_REFERRAL_CODE];
                             
                             [pref setObject:[response valueForKey:@"picture"] forKey:PREF_PROFILE_PIC];
                             [pref setObject:[response valueForKey:@"first_name"] forKey:PREF_USER_NAME];
                             [pref setObject:[response valueForKey:@"email"] forKey:PREF_USER_EMAIL];
                             [pref setBool:YES forKey:PREF_IS_LOGIN];
                             [pref setBool:NO forKey:PREF_IS_SOCIAL_LOGIN];
                             
                             [pref synchronize];
                             [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                             if([[response valueForKey:@"screen_status"] isEqual:@"1"]){
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                 [self performSegueWithIdentifier:STRING_SEGUE_BOOKING_PAGE sender:self];
                                 });
                                 /*
                                  {
                                  [APPDELEGATE.window setRootViewController:nil];
                                  [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"rootViewController"]];
                                  }
                                  */
                             }else if ([[response valueForKey:@"screen_status"] isEqual:@"3"]){
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                 [self performSegueWithIdentifier:STRING_SEGUE_SIGNUP_PHONE sender:self];
                                 });
                             }
                         }
                         else{
                              ALog(@"Login Response ---> %@",response);
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [APPDELEGATE showAlertOnTopMostControllerWithText:[response valueForKey:@"error"]];
                             });
                         }
                     }
                     [APPDELEGATE stopLoader:self.view];
                 }];
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_EMAIL view:self.view]];
                [customAlertView show];
            }
        }
    }
    else
    {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)loginToForgetPassBtn:(id)sender {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    _homeView.hidden=YES;
    _signupView.hidden=YES;
    _loginView.hidden=YES;
    _socialMailView.hidden=YES;
    
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:nil
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self.view bringSubviewToFront:_forgetPasswordView];
                        [self animateViewHeight:_forgetPasswordView withAnimationType:kCATransitionFromTop];
                        self.view.userInteractionEnabled=YES;
                        fixed=1;
                    }];
}

-(BOOL)doesEmailIdHasASpace:(NSString*)emailId {
    
    if ([emailId componentsSeparatedByString:@"@"].count > 1){
        ALog(@"stringcontains @ symbol and the words are %@", [emailId componentsSeparatedByString:@"@"]);
        if([[UtilityClass sharedObject]validateEmail:emailId]) {
            return NO;
        } else {
            return YES;
        }
    } else {
        NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"1234567890"];
        s = [s invertedSet];
        NSRange r = [emailId rangeOfCharacterFromSet:s];
        if (r.location != NSNotFound) {
            NSLog(@"the string contains illegal characters");
        }

        if (([emailId componentsSeparatedByString:@" "].count > 1) || (r.location != NSNotFound) || ([emailId length] < 10)){
            ALog(@"stringcontains alphabets symbol and the words are %@", [emailId componentsSeparatedByString:@" "]);
            return YES;
        }
        return NO;
    }
}

- (IBAction)forgetPasswordBtn:(id)sender {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    if([APPDELEGATE connected]){
        if(_forgetPasswordEmailTxt.text.length<1)
        {
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_EMAIL_OR_PHONE_NUMBER view:self.view]];
            [customAlertView show];
        } else if ([self doesEmailIdHasASpace:_forgetPasswordEmailTxt.text]) {
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_NO_SPACE view:self.view]];
            [customAlertView show];
        }
        else{
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:@"2" forKey:PARAM_TYPE];
            [dictParam setValue:_forgetPasswordEmailTxt.text forKey:PARAM_EMAIL];
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_FORGET_PASSWORD withParamData:dictParam withBlock:^(id response, NSError *error){
                 ALog(@"ForgotPassword Response ---> %@",response);
                if (response == Nil){
                    if (error.code == -1005) {
                        [APPDELEGATE stopLoader:self.view];
                        [self socialMailConfirmBtn:sender];
                        
                    }else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [APPDELEGATE stopLoader:self.view];
                            [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                        });
                    }
                }else if (response){
                    if([[response valueForKey:@"success"] boolValue]){
                        _forgetPasswordEmailTxt.text=@"";
                        _forgetPasswordView.hidden=YES;
                        _loginView.hidden=NO;
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                            [customAlertView show];
                        });
                        
                        
                    }else{
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                            [customAlertView show];
                        });
                    }
                }
                [APPDELEGATE stopLoader:self.view];
            }];
        }
    }
    else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)socialMailConfirmBtn:(id)sender {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    if([APPDELEGATE connected])  {
        if(_socialMailEmailTxt.text.length<1 || _socialMailNameTxt.text.length<1){
            if(_socialMailNameTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_NAME view:self.view]];
                [customAlertView show];
            }
            else if(_socialMailEmailTxt.text.length<1)
            {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_EMAIL view:self.view]];
                [customAlertView show];
            }
        }
        else {
            if([[UtilityClass sharedObject]validateEmail:_socialMailEmailTxt.text]) {
                NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
                [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
                [dictParam setValue:_socialMailEmailTxt.text forKey:PARAM_EMAIL];
                [dictParam setValue:_socialMailNameTxt.text forKey:PARAM_NAME];
                [dictParam setValue:@"true" forKey:PARAM_UPDATE];
                [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
                [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
                AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                [afn getDataFromPath:FILE_LOGIN withParamData:dictParam withBlock:^(id response, NSError *error)
                 {
                     ALog(@"Login Response ---> %@",response);
                     if (response == Nil){
                         if (error.code == -1005) {
                             [APPDELEGATE stopLoader:self.view];
                             [self socialMailConfirmBtn:sender];
                             
                         }else {
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [APPDELEGATE stopLoader:self.view];
                                 [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                             });
                         }
                     }else if (response)
                     {
                         if([[response valueForKey:@"success"]boolValue])
                         {
//                             NSString *strLog=[NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"LOGIN_SUCCESS", nil),[response valueForKey:@"first_name"]];
//                             [APPDELEGATE showToastMessage:strLog];
                             //[pref setObject:response forKey:PREF_LOGIN_OBJECT];
                             [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                             [pref setObject:[response valueForKey:@"lymo_device_id"] forKey:PREF_LYMO_DEVICE_ID];
                             [pref setObject:[response valueForKey:@"id"] forKey:PREF_USER_ID];
                             [pref setObject:[response valueForKey:@"is_referee"] forKey:PREF_IS_REFEREE];
                             
                             [pref setObject:[response valueForKey:@"picture"] forKey:PREF_PROFILE_PIC];
                             [pref setObject:[response valueForKey:@"first_name"] forKey:PREF_USER_NAME];
                             
                             //[pref setObject:[response valueForKey:@"screen_status"] forKey:PREF_SCREEN_STATUS];
                             [pref setBool:YES forKey:PREF_IS_LOGIN];
                             [pref synchronize];
                             _socialMailNameTxt.text=@"";
                             _socialMailEmailTxt.text=@"";
                             if([[response valueForKey:@"screen_status"] isEqual:@"1"]){
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                 [self performSegueWithIdentifier:STRING_SEGUE_BOOKING_PAGE sender:self];
                                 });
                             }else if ([[response valueForKey:@"screen_status"] isEqual:@"3"]){
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                 [self performSegueWithIdentifier:STRING_SEGUE_SIGNUP_PHONE sender:self];
                                 });
                             }
                         } else {
                             dispatch_async(dispatch_get_main_queue(), ^{
                                 [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                                 [customAlertView show];
                             });
                         }
                     }
                     [APPDELEGATE stopLoader:self.view];
                 }];
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_EMAIL view:self.view]];
                [customAlertView show];
            }
            
        }
    }
}

#pragma mark- FaceBook Email Delegate methods

- (void) loginEmailPageNotification:(NSNotification *)notification{
    [self gotoIntermediateScreen];
}


-(void)gotoIntermediateScreen{
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    _homeView.hidden=YES;
    _signupView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _loginView.hidden=YES;
    
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:nil
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self.view bringSubviewToFront:_socialMailView];
                        [self animateViewHeight:_socialMailView withAnimationType:kCATransitionFromTop];
                        self.view.userInteractionEnabled=YES;
                        fixed=1;
                    }];
    _socialMailNameTxt.text=[pref objectForKey:PREF_SOCIAL_NAME];
}


-(void)loginWithEmailProvidedFunction:(NSNotification *)notification{
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    _homeView.hidden=YES;
    _signupView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _socialMailView.hidden=YES;
    self.view.userInteractionEnabled=NO;
    [UIView transitionWithView:nil
                      duration:0.5
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:NULL
                    completion:^(BOOL finished){
                        [self.view bringSubviewToFront:_loginView];
                        [self animateViewHeight:_loginView withAnimationType:kCATransitionFromTop];
                        self.view.userInteractionEnabled=YES;
                        fixed=1;
                        if([[pref objectForKey:@"login_type"] isEqualToString:@"manual"]){
                            ALog(@" registered email = %@", [pref objectForKey:PREF_USER_EMAIL]);
                            _loginEmailTxt.text=[pref objectForKey:PREF_USER_EMAIL];
                        }
                    }];
}

#pragma mark -Delegate animate bottom to top

- (void)animateViewHeight:(UIView*)animateView withAnimationType:(NSString*)animType {
    CATransition *animation = [CATransition animation];
    [animation setType:kCATransitionPush];
    [animation setSubtype:animType];
    [animation setDuration:0.2];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn]];
    [[animateView layer] addAnimation:animation forKey:kCATransition];
    animateView.hidden = !animateView.hidden;
}

#pragma mark - gesture actions

-(void)handleSingleTapGesture:(UITapGestureRecognizer *)tapGestureRecognizer {
    [_signupEmailTxt resignFirstResponder];
    [_signupNameTxt resignFirstResponder];
    [_signupPasswordTxt resignFirstResponder];
    [_loginEmailTxt resignFirstResponder];
    [_loginPasswordTxt resignFirstResponder];
    [_forgetPasswordEmailTxt resignFirstResponder];
    [_socialMailEmailTxt resignFirstResponder];
    [_socialMailNameTxt resignFirstResponder];
    
    // Social Intermediate Data Reset
    _socialMailNameTxt.text=@"";
    _socialMailEmailTxt.text=@"";
    
    CGPoint offset;
    offset=CGPointMake(0, 0);
    [self.loginScrollView setContentOffset:offset animated:YES];
    _signupView.hidden=YES;
    _loginView.hidden=YES;
    _forgetPasswordView.hidden=YES;
    _socialMailView.hidden=YES;
    
    if (fixed){
        self.view.userInteractionEnabled=NO;
        [UIView transitionWithView:self.view
                          duration:0.1
                           options:UIViewAnimationOptionTransitionNone
                        animations:NULL
                        completion:^(BOOL finished){
                            [self.view bringSubviewToFront:_homeView];
                            [self animateViewHeight:_homeView withAnimationType:kCATransitionFade];
                            self.view.userInteractionEnabled=YES;
                            fixed=0;
                        }];
        [UIView commitAnimations];
    }
}

#pragma mark - Google signin Delegate

- (void) googleSignInNotification:(NSNotification *)notification {
    googleSignInDataModal *googleSignInModel = notification.object;
    ALog(@"%@",googleSignInModel.userEmail);
    ALog(@"%@",googleSignInModel.userID);
    ALog(@"%@",googleSignInModel.userName);
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    loginType=@"google";
    [pref setObject:loginType forKey:@"login_type"];
    [dictParam setValue:@"ios" forKey:PARAM_DEVICE_TYPE];
    [dictParam setValue:[pref valueForKey:PREF_DEVICE_TOKEN] forKey:PARAM_DEVICE_TOKEN];
    ALog(@"login device token = %@", [pref valueForKey:PREF_DEVICE_TOKEN]);
    [dictParam setValue:loginType forKey:PARAM_LOGIN_BY];
    [pref setObject:loginType forKey:@"login_type"];
    [dictParam setValue:googleSignInModel.userName forKey:PARAM_FIRST_NAME];
    [dictParam setValue:googleSignInModel.userEmail forKey:PARAM_EMAIL];
    [dictParam setValue:googleSignInModel.userID forKey:PARAM_SOCIAL_UNIQUE_ID];
    [dictParam addEntriesFromDictionary:[APPDELEGATE deviceInfo]];
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    [afn getDataFromPath:FILE_LOGIN withParamData:dictParam withBlock:^(id response, NSError *error)
     {
         ALog(@"Login Response ---> %@",response);
         if (response == Nil){
             if (error.code == -1005) {
                 [APPDELEGATE stopLoader:self.view];
                 [self googleSignInNotification:notification];
             }else {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [APPDELEGATE stopLoader:self.view];
                     [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                 });
             }
         }else if (response)
         {
             if([[response valueForKey:@"success"]boolValue])
             {
//                 NSString *strLog=[NSString stringWithFormat:@"%@ %@",NSLocalizedString(@"LOGIN_SUCCESS", nil),[response valueForKey:@"first_name"]];
//                 [APPDELEGATE showToastMessage:strLog];
          //       [pref setObject:response forKey:PREF_LOGIN_OBJECT];
                 [pref setObject:[response valueForKey:@"token"] forKey:PREF_USER_TOKEN];
                 [pref setObject:[response valueForKey:@"lymo_device_id"] forKey:PREF_LYMO_DEVICE_ID];
                 [pref setObject:[response valueForKey:@"id"] forKey:PREF_USER_ID];
                 [pref setObject:[response valueForKey:@"is_referee"] forKey:PREF_IS_REFEREE];
                 [pref setObject:[response valueForKey:@"referral_code"] forKey:PREF_REFERRAL_CODE];
                 //[pref setObject:[response valueForKey:@"screen_status"] forKey:PREF_SCREEN_STATUS];
                 
                 [pref setObject:[response valueForKey:@"picture"] forKey:PREF_PROFILE_PIC];
                 [pref setObject:[response valueForKey:@"first_name"] forKey:PREF_USER_NAME];
                 [pref setObject:[response valueForKey:@"email"] forKey:PREF_USER_EMAIL];
                 [pref setBool:YES forKey:PREF_IS_LOGIN];
                 [pref setBool:YES forKey:PREF_IS_SOCIAL_LOGIN];
                 [pref synchronize];
                [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                 if([[response valueForKey:@"screen_status"] isEqual:@"1"]){
                     dispatch_async(dispatch_get_main_queue(), ^{
                     [self performSegueWithIdentifier:STRING_SEGUE_BOOKING_PAGE sender:self];
                     });
                 }else if ([[response valueForKey:@"screen_status"] isEqual:@"3"]){
                     dispatch_async(dispatch_get_main_queue(), ^{
                     [self performSegueWithIdentifier:STRING_SEGUE_SIGNUP_PHONE sender:self];
                     });
                 }
             }
             else{
                 [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                 [customAlertView show];
             }
         }
         [APPDELEGATE stopLoader:self.view];
     }];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}



#pragma mark - TextView Delegate
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    CGPoint offset;
    // Signup textview
    if(textField==_signupNameTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    if(textField==_signupEmailTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    if(textField==_signupPasswordTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    // Login textview
    if(textField==_loginEmailTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    if(textField==_loginPasswordTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    // Forgotpassword textview
    if(textField==_forgetPasswordEmailTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    // social email textview
    if(textField==_socialMailNameTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
    if(textField==_socialMailEmailTxt){
        offset=CGPointMake(0, 220);
        [self.loginScrollView setContentOffset:offset animated:YES];
    }
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    CGPoint offset;
    offset=CGPointMake(0, 0);
    [self.loginScrollView setContentOffset:offset animated:YES];
    
    NSInteger nextTag = textField.tag + 1;
    //  Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        //   Found next Responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        //  Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField layoutIfNeeded]; //Fixes iOS 9 text bounce glitch
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (textField == _loginPasswordTxt || textField == _signupPasswordTxt) {
        return YES;
    }
    if (range.location == 0 && [string isEqualToString:@" "]) {
        return NO;
    }
    if (textField == _signupNameTxt) {
        NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:ACCEPTABLE_CHARACTERS] invertedSet];
        
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
        
        return [string isEqualToString:filtered];
    }
    
//    if (textField == _forgetPasswordEmailTxt) {
//         NSString *newstr = [textField.text stringByReplacingCharactersInRange:range withString:string];
//            if (newstr.length > 1) {
//                if ([[newstr substringToIndex:1] isEqualToString:@"0"]) {
//                    if ([[newstr substringToIndex:2] isEqualToString:@"07"]) {
//                        if (newstr.length > 11) {
//                            return NO;
//                        }
//                        return YES;
//                    }else{
//                        textField.text =@"";
//                        [textField resignFirstResponder];
//                        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
//                        [customAlertView show];
//                        
//                        return NO;
//                    }
//                }
//            }
//    }
    return YES;
}


#pragma mark - push notificaiton
-(void)registerToReceivePushNotification {
    // Register for push notifications
    UIApplication* application =[UIApplication sharedApplication];
    if ([application respondsToSelector:@selector(registerUserNotificationSettings:)] || [application respondsToSelector:@selector(isRegisteredForRemoteNotifications)]) {
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge
                                                                                             |UIUserNotificationTypeSound
                                                                                             |UIUserNotificationTypeAlert) categories:nil];
        [application registerUserNotificationSettings:settings];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
}

@end
