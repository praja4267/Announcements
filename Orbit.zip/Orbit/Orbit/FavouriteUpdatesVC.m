//
//  FavouriteUpdatesVC.m
//
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import "FavouriteUpdatesVC.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"
//#import <GoogleMapsM4B/GoogleMaps.h>
#import <GoogleMaps/GoogleMaps.h>
#import <MapKit/MapKit.h>
#import "LocationManager.h"


@interface FavouriteUpdatesVC ()<GMSMapViewDelegate,UITextFieldDelegate,GMSMapViewDelegate,CLLocationManagerDelegate>{
    GMSMapView *mapView_;
    NSString *strForLatitude,*strForLongitude;
    // NSString *strForCurLatitude,*strForCurLongitude;
    UIButton *locationButton;
    CLLocationManager *locationManager;
    BOOL isFirstTime;
    
    UIView *favExpandView;
    UIView *sideMenuView;
    UIView *hideGoogleButton, *noInternetView;
    
    
}

@end

@implementation FavouriteUpdatesVC
@synthesize reach;

- (void)viewDidLoad {
    [super viewDidLoad];
    [[LocationManager sharedInstance] startUpdatingLocation];
    _favTitleTxt.delegate=self;
    isFirstTime=YES;
    // Do any additional setup after loading the view.
    if ([_toDisplay isEqualToString:@"Add"]) {
        _favSaveBtn.hidden=NO;
        _favUpdateBtn.hidden=YES;
        _favPlaceLbl.text= _favAddress;//[pref objectForKey:PREF_ADD_FAV_TEXT];
        strForLatitude= _favLat;// [pref objectForKey:PREF_ADD_FAV_LAT];
        strForLongitude=_favLong;//[pref objectForKey:PREF_ADD_FAV_LONG];
    }else{
        _favSaveBtn.hidden=YES;
        _favUpdateBtn.hidden=NO;
        _favPlaceLbl.text=_favAddress;
        _favTitleTxt.text=_favTag;
        strForLatitude=_favLat;
        strForLongitude=_favLong;
        
    }
    
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:[strForLatitude doubleValue] longitude:[strForLongitude doubleValue]zoom:15];
    mapView_ = [GMSMapView mapWithFrame:self.favViewForMap.bounds camera:camera];
    mapView_.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    mapView_.myLocationEnabled =  YES;
    mapView_.settings.myLocationButton = NO;
    mapView_.settings.scrollGestures=YES;
    [mapView_.settings setRotateGestures:NO];
    [mapView_.settings setTiltGestures:NO];
    [mapView_ setMinZoom:5 maxZoom:19];
    mapView_.delegate=self;
    mapView_.settings.allowScrollGesturesDuringRotateOrZoom = NO;
    [self.favViewForMap addSubview:mapView_];
    
    sideMenuView = [[UIView alloc] initWithFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, 16, self.view.frame.size.height)];
    favExpandView = [[UIView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height)];
    hideGoogleButton=[[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-30, 70, 30)];
    favExpandView.backgroundColor = [UIColor clearColor];
    
    //
    
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
    
    self.reach = [Reachability reachabilityForInternetConnection]; //retain reach
    [reach startNotifier];
    
    NetworkStatus remoteHostStatus = [reach currentReachabilityStatus];
    
    NSLog(@"???? ALWAYS INITS WITH Not Reachable ????");
    if(remoteHostStatus == NotReachable) {NSLog(@"init **** Not Reachable ****");}
    else if (remoteHostStatus == ReachableViaWiFi) {NSLog(@"int **** wifi ****"); }
    else if (remoteHostStatus == ReachableViaWWAN) {NSLog(@"init **** cell ****"); }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)addNoInternetView{
    noInternetView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    noInternetView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:noInternetView];
    noInternetView.hidden=YES;
    
    UITapGestureRecognizer *noInternetGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(checkForInternet:)];
    noInternetView.userInteractionEnabled = YES;
    [noInternetView setExclusiveTouch:YES];
    [noInternetView addGestureRecognizer:noInternetGesture];

}

- (void)checkForInternet:(UITapGestureRecognizer*)sender
{
    if ([APPDELEGATE connected]) {
        noInternetView.hidden=YES;
    }else{
        noInternetView.hidden=NO;
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}


- (void) reachabilityChanged:(NSNotification *)notice
{
    
    NSLog(@"!!!!!!!!!! CODE IS CALL NOW !!!!!!!!!!");
    
    NetworkStatus remoteHostStatus = [reach currentReachabilityStatus];
    
    if(remoteHostStatus == NotReachable) {
        NSLog(@"**** Not Reachable ****");
        noInternetView.hidden=NO;
    } else {
        noInternetView.hidden=YES;
        if (remoteHostStatus == ReachableViaWiFi) {NSLog(@"**** wifi ****"); }
        else if (remoteHostStatus == ReachableViaWWAN) {NSLog(@"**** cell ****");}
    }
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.view addSubview:sideMenuView];
    [self.view addSubview:hideGoogleButton];
    [self.view bringSubviewToFront:sideMenuView];
    [self.view bringSubviewToFront:hideGoogleButton];
    sideMenuView.backgroundColor=[UIColor clearColor];
    hideGoogleButton.backgroundColor=[UIColor clearColor];
    [self addNoInternetView];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

-(void)dealloc
{
    mapView_=nil;
}
#pragma mark -Text Field Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    
    [self.favViewForMap addSubview:favExpandView];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (range.location == 0 && [string isEqualToString:@" "]) {
        return NO;
    }
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [favExpandView removeFromSuperview];
    return YES;
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [[event touchesForView:favExpandView] anyObject];
    if (touch) {
        [_favTitleTxt resignFirstResponder];
        [favExpandView removeFromSuperview];
    }
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

#pragma mark- Button Actions

- (IBAction)favSaveBtn:(id)sender {
    [self.view endEditing:YES];
    if ([_favPlaceLbl.text isEqual:PLEASE_SELECT_PROPER_LOCATION]) {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_SELECT_PROPER_LOCATION view:self.view]];
        [customAlertView show];  //@"Please select proper location"
        return;
    }
    NSString* noSpacesString = [self removeWhitespacesin:_favTitleTxt.text];
    if(_favTitleTxt.text.length>0 && noSpacesString.length>0){
        if([APPDELEGATE connected]){
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:PARAM_INSERT forKey:PARAM_TYPE];
            [dictParam setValue:strForLatitude forKey:PARAM_LATITUDE];
            [dictParam setValue:strForLongitude forKey:PARAM_LONGITUDE];
            [dictParam setValue:_favTitleTxt.text forKey:PARAM_TAG];
            [dictParam setValue:_favPlaceLbl.text forKey:PARAM_ADDRESS];
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_FAVOURITES withParamData:dictParam withBlock:^(id response, NSError *error){
                ALog(@"favourites response is = %@",response);
                if (response == Nil){
                    if (error.code == -1005) {
                        [APPDELEGATE stopLoader:self.view];
                        [self favSaveBtn:sender];
                    }else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [APPDELEGATE stopLoader:self.view];
                            [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                        });
//                    [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                    [customAlertView show];
                    }
                }else if (response){
                    if([[response valueForKey:@"success"] boolValue]){
                        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
                //        [pref setBool:YES forKey:PREF_IS_FAV];
                          [pref setObject:@"no" forKey:PREF_ADD_FAV_VIEW];
                        
                        [pref setObject:_favPlaceLbl.text forKey:PREF_FAV_TEXT];
                        [pref setObject:@"Favourite" forKey:PREF_FAV_DELETEFAV];
                        
                        
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self.navigationController popViewControllerAnimated:YES];
                            [APPDELEGATE showAlertOnTopMostControllerWithText:ADDRESS_ADDED_SUCCESSFULLY];
                        });
                        
                    }
                    else{
                        [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                        [customAlertView show];
                    }
                     [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                }
                [APPDELEGATE stopLoader:self.view];
            }];
        }else{
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_TITLE view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)favUpdateBtn:(id)sender {
    [_favTitleTxt endEditing:YES];
    if ([_favPlaceLbl.text isEqual:PLEASE_SELECT_PROPER_LOCATION]) {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_SELECT_PROPER_LOCATION view:self.view]];
        [customAlertView show];
        return;
    }
    NSString* noSpacesString = [self removeWhitespacesin:_favTitleTxt.text];
    if(_favTitleTxt.text.length>0 && noSpacesString.length>0){
        if([APPDELEGATE connected]){
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:PARAM_UPDATE forKey:PARAM_TYPE];
            [dictParam setValue:strForLatitude forKey:PARAM_LATITUDE];
            [dictParam setValue:strForLongitude forKey:PARAM_LONGITUDE];
            [dictParam setValue:_favTitleTxt.text forKey:PARAM_TAG];
            [dictParam setValue:_favPlaceLbl.text forKey:PARAM_ADDRESS];
            [dictParam setValue:_favID forKey:PARAM_FAVORITE_ID];
            ALog(@"Address update dictionary is %@", dictParam);
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_FAVOURITES withParamData:dictParam withBlock:^(id response, NSError *error){
                ALog(@"response in update address title is = %@", response);
                if (response == Nil){
                    if (error.code == -1005) {
                        [APPDELEGATE stopLoader:self.view];
                        [self favUpdateBtn:sender];
                        
                    }else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [APPDELEGATE stopLoader:self.view];
                            [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                        });
//                    [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                    [customAlertView show];
                    }
                }else if (response){
                        if([[response valueForKey:@"success"] boolValue]){
                            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
                            //        [pref setBool:YES forKey:PREF_IS_FAV];
                            [pref setObject:@"no" forKey:PREF_ADD_FAV_VIEW];
                            
                            [pref setObject:_favPlaceLbl.text forKey:PREF_FAV_TEXT];
                            [pref setObject:@"Favourite" forKey:PREF_FAV_DELETEFAV];
                            //    [pref setObject:strForLatitude forKey:PREF_FAV_LAT];
                            //    [pref setObject:strForLongitude forKey:PREF_FAV_LONG];
                            
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [self.navigationController popViewControllerAnimated:YES];
                                [APPDELEGATE showAlertOnTopMostControllerWithText:ADDRESS_UPDATED_SUCCESSFULLY];
                            });

                            //[self performSegueWithIdentifier:STRING_SEGUE_FROM_SAVE_UPDATE_SEGUE sender:self];
                        }
                        else{
                            [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                            [customAlertView show];
                        }
                    //[self performSegueWithIdentifier:STRING_SEGUE_FROM_SAVE_UPDATE_SEGUE sender:self];
                     [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                }
                [APPDELEGATE stopLoader:self.view];
            }];
        }else{
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_TITLE view:self.view]];
        [customAlertView show];
        _favTitleTxt.text = @"";
    }
}

- (IBAction)FavUpdateLocationBtn:(id)sender{
    CLLocationCoordinate2D coordinate = [self updateLocationManagerr];
    CGPoint point = [mapView_.projection pointForCoordinate:coordinate];
    GMSCameraUpdate *camera =
    [GMSCameraUpdate setTarget:[mapView_.projection coordinateForPoint:point] zoom:15];
    [mapView_ animateWithCameraUpdate:camera];
}

- (IBAction)favSaveBackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark- Google Map Delegate

- (void)mapView:(GMSMapView *)mapView didChangeCameraPosition:(GMSCameraPosition *)position
{
    strForLatitude=[NSString stringWithFormat:@"%f",position.target.latitude];
    strForLongitude=[NSString stringWithFormat:@"%f",position.target.longitude];
}

- (void) mapView:(GMSMapView *)mapView idleAtCameraPosition:(GMSCameraPosition *)position
{
    [APPDELEGATE stopLoader:self.view];
    strForLatitude=[NSString stringWithFormat:@"%f",position.target.latitude];
    strForLongitude=[NSString stringWithFormat:@"%f",position.target.longitude];
    if (isFirstTime) {
        isFirstTime=NO;
        [self getAddressUsingGeocodefromLattitude:strForLatitude andLongitude: strForLongitude isFirstTime:YES];
    }else {
        NSString* strForCurFavLatitude = [NSString stringWithFormat:@"%f", position.target.latitude];
        NSString* strForCurFavLongitude= [NSString stringWithFormat:@"%f", position.target.longitude];
        [self getAddressUsingGeocodefromLattitude:strForCurFavLatitude andLongitude:strForCurFavLongitude isFirstTime:NO];
    }
}

-(void) mapView:(GMSMapView *)mapView willMove:(BOOL)gesture{
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
}

-(void)getAddressUsingGeocodefromLattitude: (NSString*) lattitude andLongitude: (NSString *)longitude isFirstTime:(BOOL)firstTime
{
    if([APPDELEGATE connected]) {
        NSString *url = [NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?latlng=%@,%@&sensor=false&key=%@",lattitude, longitude, GOOGLE_KEY];
        ALog(@"Geocode addres from latlong = %@", url);
        NSURL *URL = [NSURL URLWithString:url];
        NSData *data = [NSData dataWithContentsOfURL:URL];
        if (data) {
            NSDictionary *JSON = [NSJSONSerialization JSONObjectWithData: data
                                                                 options: NSJSONReadingMutableContainers
                                                                   error: nil];
            
            NSArray *results = [JSON valueForKey:@"results"];
            
            if (results.count!=0)
            {
                NSDictionary *address = [results firstObject];
                if([address valueForKey:@"formatted_address"]){
                    if (firstTime) {
                        _favPlaceLbl.text=_favAddress;
                    }else {
                        _favPlaceLbl.text=[address valueForKey:@"formatted_address"];
                    }
                }
            }else{
                _favPlaceLbl.text=PLEASE_SELECT_PROPER_LOCATION;
            }
        }
        //            [self setFavouriteButtonColor];
    } else {
            [APPDELEGATE stopLoader:self.view];
            [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
            [customAlertView show];
            return ;
        }
    }

-(CLLocationCoordinate2D)updateLocationManagerr
{
    [locationManager startUpdatingLocation];
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate=self;
    locationManager.desiredAccuracy=kCLLocationAccuracyBest;
    locationManager.distanceFilter=kCLDistanceFilterNone;
    
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    [locationManager startUpdatingLocation];
    CLLocation *location = [locationManager location];
    CLLocationCoordinate2D coordinate = [location coordinate];
    if (coordinate.latitude && coordinate.longitude) {
        ALog(@"returnning coordinates calculated by cllocation manager = %f, %f", coordinate.latitude, coordinate.longitude);
        return coordinate;
    }else {
         ALog(@"returnning coordinates calculated by cllocation manager = %f, %f", [LocationManager sharedInstance].currentLocation.coordinate.latitude, [LocationManager sharedInstance].currentLocation.coordinate.longitude);
        [[LocationManager sharedInstance] stopUpdatingLocation];
        return [LocationManager sharedInstance].currentLocation.coordinate;
    }
}


- (NSString *)removeWhitespacesin:(NSString *)testString {
    return [[testString componentsSeparatedByCharactersInSet:
             [NSCharacterSet whitespaceCharacterSet]]
            componentsJoinedByString:@""];
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
