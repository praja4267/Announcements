//
//  OutStandingPaymentsViewController.m
//  Orbit
//
//  Created by Active Mac05 on 05/07/16.
//  Copyright © 2016 techActive. All rights reserved.
//

#import "OutStandingPaymentsViewController.h"
#import "CardListViewController.h"
#import "UIImageView+Download.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"


@interface OutStandingPaymentsViewController ()<UIGestureRecognizerDelegate>{
    NSUserDefaults *pref;
}
@property BOOL hasSavedCards;

@end

@implementation OutStandingPaymentsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    pref= [NSUserDefaults standardUserDefaults];
        _balanceAmountLabel.text = [NSString stringWithFormat:@"%@%@", [pref valueForKey:PREF_SETTING_CURRENCY_TEXT], _outStandingAmount];
        _backButton.hidden=YES;
    
    [_backButton addTarget:self action:@selector(backButtonPressed) forControlEvents:UIControlEventTouchUpInside];
    [_payNowButton addTarget:self action:@selector(payNowButtPressed) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationController setNavigationBarHidden:YES];
    _cardDetailsBGImageView.userInteractionEnabled=YES;
    UITapGestureRecognizer* tapOncard = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openCardListScreen)];
    [tapOncard setDelegate:self];
    [_cardDetailsBGImageView addGestureRecognizer:tapOncard];
    if (_isPresentedFromBookingPage || _isPresentedFromCurrentRide){
        _backButton.hidden=YES;
        if ([_cardLastFourString length]) {
            _addCardButton.hidden=YES;
            ALog(@"lasat foru in ousstanding = %@", _cardLastFourString);
            [_cardNumberLabel setText:_cardLastFourString];
            [_cardImageView downloadFromURL:_cardImageUrl withOutLoader:nil];
                _balanceAmountLabel.text = [NSString stringWithFormat:@"%@%@", [pref valueForKey:PREF_SETTING_CURRENCY_TEXT], _outStandingAmount];
        }else if ([[pref valueForKey:PREF_SETTING_LAST_FOUR] length]) {
            ALog(@"lasat foru in ousstanding = %@", [pref valueForKey:PREF_SETTING_LAST_FOUR]);
            [_cardNumberLabel setText:[NSString stringWithFormat:@"**** %@", [pref valueForKey:PREF_SETTING_LAST_FOUR]]];
            [_cardImageView downloadFromURL:[pref valueForKey:PREF_SETTING_CARD_URL] withOutLoader:nil];
            _addCardButton.hidden=YES;
            _cancel_payment_id=[pref valueForKey:PREF_SETTING_CANCEL_PAYMENT_ID];
        }
    } else if ([[pref valueForKey:PREF_SETTING_LAST_FOUR] length]) {
        ALog(@"lasat foru in ousstanding = %@", [pref valueForKey:PREF_SETTING_LAST_FOUR]);
        [_cardNumberLabel setText:[NSString stringWithFormat:@"**** %@", [pref valueForKey:PREF_SETTING_LAST_FOUR]]];
        [_cardImageView downloadFromURL:[pref valueForKey:PREF_SETTING_CARD_URL] withOutLoader:nil];
        _addCardButton.hidden=YES;
//        _cancel_payment_id=[pref valueForKey:PREF_SETTING_CARD_URL];
    } else  {
         _hasSavedCards=NO;
    }
    
    [_addCardButton addTarget:self action:@selector(openCardListScreen) forControlEvents:UIControlEventTouchUpInside];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
        if (![[pref valueForKey:PREF_SETTING_CARD_PAYMENT] boolValue]) {
            _payNowButton.hidden=YES;
            _addCardButton.hidden=YES;
            _cardDetailsHolderView.hidden=YES;
        }
    // Do any additional setup after loading the view from its nib.
}


-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    ALog(@"The cancel request id = %@ and cancel payment id = %@", _request_id, _cancel_payment_id);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)backButtonPressed{
    if (_isPresentedFromSettings) {
        [self openBookingScreen];
    } else {
        if (_isPushed) {
            [self.navigationController popViewControllerAnimated:YES];
        }else{
            [self dismissViewControllerAnimated:YES completion:nil];
        }
    }
}

-(void)openBookingScreen{
    if ([APPDELEGATE connected]) {
        [APPDELEGATE.window setRootViewController:nil];
        [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"DEMORootViewController"]];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
}

-(void)payNowButtPressed{
    
    //
    //    UIStoryboard * sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //    UIViewController *ctl = [sb instantiateViewControllerWithIdentifier:@"OnBoardingLandingVC"];
    //    [self presentViewController:ctl animated:NO completion:^{
    //        ALog(@"completed ");
    //    }];
    
    if ([_cancel_payment_id length] == 0 || [_request_id length] == 0) {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_SELECT_A_CARD view:self.view]];  //@"Please select a card"
        [customAlertView show];
        return;
    }
    if([APPDELEGATE connected]){
        
        if (_isPresentedFromSettings) {
            [self payForMultipleRides];
        }else {
            [self payForSingleRide];
        }

    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

-(void)payForSingleRide{
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
    [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
    [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
    [dictParam setValue:_request_id forKey:PARAM_REQUEST_ID];
    [dictParam setValue:_cancel_payment_id forKey:PARAM_CANCEL_PAYMENT_ID];
    ALog(@"outstanding payment params are = %@", dictParam);
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    
    [afn getDataFromPath:FILE_CANCELLATION_PAYMENT_SINGLE_RIDE withParamData:dictParam withBlock:^(id response, NSError *error){
        if (response == Nil){
            if (error.code == -1005) {
                [APPDELEGATE stopLoader:self.view];
                [self payForSingleRide];
            }else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [APPDELEGATE stopLoader:self.view];
                    [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                });
            }
        }else if (response){
            ALog(@"response in cancel payment cancel response is %@", response);
            if ([[response valueForKey:@"success"] boolValue]) {
                 _backButton.hidden=NO;
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                customAlertView.tag=123;
                [customAlertView show];
            }else {
                if ([[response valueForKey:@"request_status"] boolValue]) {
                    customAlertView.tag=123;
                }
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                [customAlertView show];
            }
        }
        [APPDELEGATE stopLoader:self.view];
    }];
}

-(void)payForMultipleRides{
    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
    [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
    [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
    [dictParam setValue:_request_id forKey:@"request_ids"];
    [dictParam setValue:_cancel_payment_id forKey:@"cancel_payment_id"];
    [dictParam setValue:_outStandingAmount forKey:@"cancellation_balance"];
    ALog(@"outstanding payment params are = %@", dictParam);
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
    AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
    
    [afn getDataFromPath:FILE_CANCELLATION_PAYMENT_MULTIPLE_RIDES withParamData:dictParam withBlock:^(id response, NSError *error){
        if (response == Nil){
            if (error.code == -1005) {
                [APPDELEGATE stopLoader:self.view];
                [self payForMultipleRides];
            }else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [APPDELEGATE stopLoader:self.view];
                    [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                });
            }
        }else if (response){
            ALog(@"response in cancel payment cancel response is %@", response);
            if ([[response valueForKey:@"success"] boolValue]) {
                
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                customAlertView.tag=123;
                [customAlertView show];
                
            }else {
               if ([[response valueForKey:@"request_status"] boolValue]) {
                   customAlertView.tag=123;
               }
                [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                [customAlertView show];
            }
        }
        [APPDELEGATE stopLoader:self.view];
    }];

}

-(void)openCardListScreen{
    if ([APPDELEGATE connected]) {
        CardListViewController *cntl = [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"CardListViewController"];
        cntl.shouldShowCash=NO;
        cntl.cardListDelegate=self;
        cntl.isFromOutstanding=YES;
        [self.navigationController pushViewController:cntl animated:YES];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


-(void)selectedCardDetailsDictionaryis:(NSDictionary *)cardDetailsDict{
    
    [_cardImageView downloadFromURL:[cardDetailsDict valueForKey:@"image"] withOutLoader:nil];
    _cardNumberLabel.text= [NSString stringWithFormat:@"**** %@",[cardDetailsDict valueForKey:@"last_four"]];
    _cancel_payment_id = [NSString stringWithFormat:@"%@", [cardDetailsDict valueForKey:@"id"]];
    _addCardButton.hidden=YES;
    ALog(@"card list is responded through delegate");
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}


#pragma mark - CUstom ios alertview delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    if (alertView.tag == 123) {
        if (_isPresentedFromBookingPage) {
//            [self openBookingScreen];
            [self dismissViewControllerAnimated:YES completion:nil];
        } else if (_isPresentedFromCurrentRide) {
            [self.navigationController popToRootViewControllerAnimated:NO];
        }else {
            [self openBookingScreen];
        }
    }
    [alertView close];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
