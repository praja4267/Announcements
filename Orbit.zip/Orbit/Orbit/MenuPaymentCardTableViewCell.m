//
//  MenuPaymentCardTableViewCell.m
//  
//
//  Created by ActiveMac03 on 05/01/16.
//
//

#import "MenuPaymentCardTableViewCell.h"

@implementation MenuPaymentCardTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
