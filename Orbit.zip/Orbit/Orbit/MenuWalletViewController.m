//
//  MenuWalletViewController.m
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import "MenuWalletViewController.h"
#import "Constants.h"
#import "AppDelegate.h"
@interface MenuWalletViewController ()

@end

@implementation MenuWalletViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _totalAmountLabel.text = [NSString stringWithFormat:@"%@ 200", [[NSUserDefaults standardUserDefaults] valueForKey:PREF_SETTING_CURRENCY_TEXT]];
    [_addAmountToWalletButton setTitle:[NSString stringWithFormat:@"Add %@ 99 to your wallet", [[NSUserDefaults standardUserDefaults] valueForKey:PREF_SETTING_CURRENCY_TEXT]] forState:UIControlStateNormal];
    [_addAmountToWalletButton addTarget:self action:@selector(addWalletButtonAction) forControlEvents:UIControlEventTouchUpInside];
    // Do any additional setup after loading the view.
}

-(void)addWalletButtonAction{
    ALog(@"Add walled button pressed ");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
