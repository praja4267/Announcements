//
//  OTPViewController.m
//  
//
//  Created by ActiveMac03 on 07/12/15.
//
//

#import "OTPViewController.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"

@interface OTPViewController ()

@end

@implementation OTPViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    _otpResendBtn.hidden=NO;
    _otpResendLbl.hidden=NO;
    [_otpResendBtn setExclusiveTouch:YES];
    [_otpConfirmBtn setExclusiveTouch:YES];
    
    //KeyBoard done button
    UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
    [keyboardDoneButtonView sizeToFit];
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                   style:UIBarButtonItemStylePlain target:self
                                                                  action:@selector(doneClicked:)];
    [doneButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];
    [keyboardDoneButtonView setItems:[NSArray arrayWithObjects:flexibleSpaceLeft,doneButton, nil]];
    _otpTxt.inputAccessoryView = keyboardDoneButtonView;
    
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];

    _otpPhoneLbl.text = [NSString stringWithFormat:@"We have sent you a verification code to your mobile number %@ %@",[pref objectForKey:PREF_ISO_CODE],[pref objectForKey:PREF_USER_PHONE]];
    _otpTxt.delegate=self;
    _otpTxt.textColor=[UIColor orbitBlackColorhex7];
    if ([_screenStatus isEqualToString:@"editProfile"]) {
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        [pref setValue:PREF_SCREEN_STATUS_EDIT_PROFILE forKey:PREF_SCREEN_STATUS_EDIT_PROFILE];
        [pref synchronize];
    }
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - OTP page button action

- (IBAction)doneClicked:(id)sender
{
    [self.view endEditing:YES];    
}

- (IBAction)BackBtn:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)otpResendBtn:(id)sender {
    if([APPDELEGATE connected])  {
        _otpResendBtn.hidden=YES;
        _otpResendLbl.hidden=YES;
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_PHONE] forKey:PARAM_MOBILE_NUMBER];
        [dictParam setValue:[pref objectForKey:PREF_ISO_CODE] forKey:PARAM_ISO_CODE];
        [dictParam setValue:PARAM_RESEND forKey:PARAM_TYPE];
        [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_OTP withParamData:dictParam withBlock:^(id response, NSError *error)
         {
            ALog(@"Phonenumber Response ---> %@",response);
             if (response == Nil){
                 if (error.code == -1005) {
                     [APPDELEGATE stopLoader:self.view];
                     [self otpResendBtn:sender];
                     
                 }else {
                     dispatch_async(dispatch_get_main_queue(), ^{
                         [APPDELEGATE stopLoader:self.view];
                         [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                     });
                 }
             }else if (response)
            {
                if([[response valueForKey:@"success"]boolValue])
                {
               //     _otpResendBtn.hidden=YES;
               //     _otpResendLbl.hidden=YES;
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"message"] view:self.view]];
                    [customAlertView show];
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    customAlertView.tag=2;
                    [customAlertView show];
                }
                [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
            }
             [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)otpConfirmBtn:(id)sender {
    [_otpTxt resignFirstResponder];
    if([APPDELEGATE connected])  {
        if(_otpTxt.text.length<1){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_YOUR_OTP_NUMBER view:self.view]];
            [customAlertView show];
        }else{
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_PHONE] forKey:PARAM_MOBILE_NUMBER];
            [dictParam setValue:PARAM_RESPONSE forKey:PARAM_TYPE];
            [dictParam setValue:[pref objectForKey:PREF_ISO_CODE] forKey:PARAM_ISO_CODE];
            [dictParam setValue:_otpTxt.text forKey:PARAM_CODE];
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_OTP withParamData:dictParam withBlock:^(id response, NSError *error)
             {
//                 NSLog(@"Phonenumber otp apply Response ---> %@",response);
                 if (response == Nil){
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self otpConfirmBtn:sender];
                     }else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
                     }
                 }else if (response)
                 {
                     ALog(@"otp response is = %@", response);
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         if([_screenStatus isEqualToString:@"editProfile"]){
                             NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
                             [pref removeObjectForKey:PREF_SCREEN_STATUS_EDIT_PROFILE];
                             if ([response valueForKey:@"iso_code"]) {
                                 
                                 [pref setObject: [NSString stringWithFormat:@"+%@", [response valueForKey:@"iso_code"]] forKey:PREF_ISO_CODE];
                             }
                             if ([response valueForKey:@"country_code"]) {
                                 [pref setObject:[response valueForKey:@"country_code"] forKey:PREF_COUNTRY_CODE];
                             }
                             [self.navigationController popViewControllerAnimated:YES];
                         }else{
                             
                             if([[pref objectForKey:PREF_SCREEN_STATUS_EDIT_PROFILE] isEqualToString:PREF_SCREEN_STATUS_EDIT_PROFILE]){
                                 [pref removeObjectForKey:PREF_SCREEN_STATUS_EDIT_PROFILE];
                                 [pref setBool:YES forKey:PREF_USER_OTP];
                                 dispatch_async(dispatch_get_main_queue(), ^{
                                 [self performSegueWithIdentifier:STRING_SEGUE_OTP_TO_BOOKING_PAGE sender:self];
                                 });
                                 
                             }else{
                                 if ([[response valueForKey:@"referral_screen"]boolValue]) {
                                     dispatch_async(dispatch_get_main_queue(), ^{
                                         [self performSegueWithIdentifier:STRING_SEGUE_OTP_TO_REFERRAL sender:self];
                                     });
                                    
                                 } else {
                                     dispatch_async(dispatch_get_main_queue(), ^{
                                         [pref setBool:YES forKey:PREF_SHOW_BOARDING_SCREEN];
                                         [self performSegueWithIdentifier: STRING_SEGUE_OTP_TO_PAYMENT sender:self];
                                     });
                                 }
                             }
                         }
                     } else{
                         [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                         customAlertView.tag=1;
                         [customAlertView show];
                     }
                     [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                 }
                 [APPDELEGATE stopLoader:self.view];
             }];
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

#pragma mark - TextFeild Delegates

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    // Not found, so remove keyboard.
    [textField resignFirstResponder];
    return YES;
}
#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    if ([alertView tag] == 1) {
        _otpTxt.text=@"";
    }
    [alertView close];
}


@end
