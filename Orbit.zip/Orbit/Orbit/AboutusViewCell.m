//
//  AboutusViewCell.m
//  
//
//  Created by Active Mac06 on 17/12/15.
//
//

#import "AboutusViewCell.h"

@implementation AboutusViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
