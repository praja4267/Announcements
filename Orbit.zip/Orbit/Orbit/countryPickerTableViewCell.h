//
//  countryPickerTableViewCell.h
//  
//
//  Created by ActiveMac03 on 29/12/15.
//
//

#import <UIKit/UIKit.h>

@interface countryPickerTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *countryNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *countryCodeLbl;
@end
