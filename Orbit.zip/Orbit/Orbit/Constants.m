//
//  Constants.m
//
//
//  Created by ActiveMac03 on 14/11/15.
//
//

#import "Constants.h"

@implementation Constants

NSString * const STRING_EMPTY = @"";

#pragma mark - SEGUE NAME
NSString * const STRING_SEGUE_SIGNUP_PHONE = @"SignupToPhoneSegue";
NSString * const STRING_SEGUE_BOOKING_PAGE = @"BookingPageSegue";
NSString * const STRING_SEGUE_SEARCH_PAGE = @"searchViewSegue";
NSString * const STRING_SEGUE_SEARCH_TO_BOOK_PAGE = @"searchToBookSegue";
NSString * const STRING_SEGUE_PHONE_TO_OTP = @"phoneToOTPSegue";
NSString * const STRING_SEGUE_RIDE_COMPLETE = @"rideCompleteSegue";
NSString * const STRING_SEGUE_FROM_FAVORITES = @"favToBookSegue";
NSString * const STRING_SEGUE_TO_FAVORITES = @"toFavSegue";
NSString * const STRING_SEGUE_FROM_SAVE_UPDATE_SEGUE = @"fromSaveUpdateSegue";
NSString * const STRING_SEGUE_TO_SAVE_UPDATE_SEGUE = @"toSaveUpdateSegue";
NSString * const STRING_SEGUE_OTP_TO_REFERRAL = @"otpToReferralSegue";
NSString * const STRING_SEGUE_OTP_TO_PAYMENT = @"otpToPaymentSegue";
NSString * const STRING_SEGUE_OTP_TO_BOOKING_PAGE = @"otpToBookingPageSegue";
NSString * const STRING_SEGUE_REFERRAL_TO_PAYMENT = @"referralToPaymentSegue";
NSString * const STRING_SEGUE_RIDE_DETAILS = @"rideDetailsSegue";
NSString * const STRING_SEGUE_FAQ = @"faqSegue";
NSString * const STRING_SEGUE_CHANGE_PASSWORD = @"changePasswordSegue";
NSString * const STRING_SEGUE_PROFILE_UPDATE = @"profileUpdateSegue";
NSString * const STRING_SEGUE_ABOUT_TO_PRIVACY = @"aboutToPrivacySegue";
NSString * const STRING_SEGUE_EDIT_PROFILE_TO_OTP = @"editProfileToOTPSegue";
NSString * const STRING_SEGUE_HELP_TRIP_DETAIL = @"helpTripDetailSegue";
NSString * const STRING_SEGUE_BOOKING_TO_FARE = @"bookingToFareSegue";
NSString * const STRING_SEGUE_PHONE_TO_COUNTRYPICKER =@"phoneToCountrypickerSegue";
NSString * const STRING_SEGUE_RIDEDETAILS_TO_HELPTRIP=@"RidedetailsToHelptripSegue";
NSString * const STRING_SEGUE_RIDECOMPLETE_TO_HELPTRIP=@"rideCompleteTohelpTripSegue";
NSString * const STRING_SEGUE_CURRENT_RIDE = @"currentRideSegue";
NSString * const STRING_SEGUE_ADD_CARD = @"addCardSegue";
NSString * const STRING_SEGUE_ON_BOARDING_PAGE = @"onBoardingPageSegue";
NSString * const STRING_SEGUE_PAYMENT_ADD_NEW_CARD = @"paymentAddNewCardSegue";
NSString * const STRING_SEGUE_ADD_CARD_TO_GET_STARTED = @"addCardToGetStartedSegue";
NSString * const STRING_SEGUE_CARD_LIST_TO_ADD_CARD = @"cardListToAddCardSegue";
NSString * const STRING_SEGUE_CARD_LIST= @"cardListSegue";
NSString * const STRING_SEGUE_CARD_LIST_VIEW_CONTROLLER = @"OpenCardListViewController";

#pragma mark - PARAMETER NAME
NSString *const PARAM_EMAIL=@"email";
NSString *const PARAM_PASSWORD=@"password";
NSString *const PARAM_FIRST_NAME=@"first_name";
NSString *const PARAM_LAST_NAME=@"last_name";
NSString *const PARAM_PHONE=@"phone";
NSString *const PARAM_PICTURE=@"picture";
NSString *const PARAM_DEVICE_TOKEN=@"device_token";
NSString *const PARAM_DEVICE_TYPE=@"device_type";
NSString *const PARAM_BIO=@"bio";
NSString *const PARAM_ADDRESS=@"address";
NSString *const PARAM_KEY=@"key";
NSString *const PARAM_STATE=@"state";
NSString *const PARAM_COUNTRY=@"country";
NSString *const PARAM_ZIPCODE=@"zipcode";
NSString *const PARAM_LOGIN_BY=@"login_by";
NSString *const PARAM_SOCIAL_UNIQUE_ID=@"social_unique_id";
NSString *const PARAM_MOBILE_NUMBER=@"mobile_number";
NSString *const PARAM_SEND=@"send";
NSString *const PARAM_RESPONSE=@"response";
NSString *const PARAM_CODE=@"code";
NSString *const PARAM_RESEND=@"resend";
NSString *const PARAM_DATETIME=@"datetime";

NSString *const PARAM_NAME=@"name";
NSString *const PARAM_AGE=@"age";
NSString *const PARAM_NOTES=@"notes";
NSString *const PARAM_TYPE=@"type";
NSString *const PARAM_TAG=@"tag";
NSString *const PARAM_PAYMENT_OPT=@"payment_opt";
NSString *const PARAM_PAYMENT_TYPE=@"payment_type";
NSString *const PARAM_PAYMENT_ID=@"payment_id";
NSString *const PARAM_CANCEL_PAYMENT_ID=@"cancel_payment_id";
NSString *const PARAM_ID=@"id";
NSString *const PARAM_TOKEN=@"token";
NSString *const PARAM_LYMO_DEVICE_ID=@"lymo_device_id";
NSString *const PARAM_STRIPE_TOKEN=@"payment_token";
NSString *const PARAM_LAST_FOUR=@"last_four";
NSString *const PARAM_REFERRAL_SKIP=@"is_skip";
NSString *const PARAM_OLD_PASSWORD=@"old_password";
NSString *const PARAM_NEW_PASSWORD=@"new_password";

NSString *const PARAM_LATITUDE=@"latitude";
NSString *const PARAM_LONGITUDE=@"longitude";
NSString *const PARAM_D_LATITUDE=@"d_latitude";
NSString *const PARAM_D_LONGITUDE=@"d_longitude";
NSString *const PARAM_DISTANCE=@"distance";
NSString *const PARAM_REQUEST_ID=@"request_id";
NSString *const PARAM_CASH_CARD=@"cash_or_card";
NSString *const PARAM_DEFAULT_CARD=@"default_card_id";
NSString *const PARAM_COMMENT=@"comment";
NSString *const PARAM_RATING=@"rating";
NSString *const PARAM_REFERRAL_CODE=@"referral_code";
NSString *const PARAM_PROMO_CODE=@"promo_code";
NSString *const PARAM_UPDATE=@"update";
NSString *const PARAM_USER_LATITUDE=@"usr_lat";
NSString *const PARAM_USER_LONGITUDE=@"user_long";
NSString *const PARAM_CATEGORY_STATUS=@"category_stautus";
NSString *const PARAM_CATEGORY_MESSAGE=@"message";
NSString *const PARAM_RIDE_NOW_LATER=@"ride_now_later";
NSString *const PARAM_GENERAL=@"general";
NSString *const PARAM_LAST_WALKER_ID=@"last_walk_id";
NSString *const PARAM_CARD_ID=@"card_id";
NSString *const PARAM_PAYMENT_MODE=@"payment_mode";
NSString *const PREF_LAST_FOUR=@"last_four";

NSString *const PARAM_INSERT=@"insert";
NSString *const PARAM_GET=@"get";
NSString *const PARAM_DELETE=@"delete";
NSString *const PARAM_FAVORITE_ID=@"favorite_id";

NSString *const PARAM_REASON_ID=@"reason_id";
NSString *const PARAM_REASON=@"reason";
NSString *const PARAM_ISO_CODE=@"iso_code";
NSString *const PARAM_COUNTRY_CODE=@"country_code";
NSString *const PARAM_USER_PROFILE=@"userfile";

NSString *const PARAM_CARD_NAME=@"card_name";
NSString *const PARAM_CARD_NUMBER=@"card_number";
NSString *const PARAM_VALIDITY=@"validity";
NSString *const PARAM_CVV=@"cvv";
NSString *const PARAM_CARD_TOKEN=@"card_token";
NSString *const PARAM_CARD_TYPE=@"card_type";

NSString *const PARAM_DEVICE_ID=@"device_id";
NSString *const PARAM_OS_VERSION=@"os_version";
NSString *const PARAM_RESOLUTION=@"resolution";
NSString *const PARAM_SCREEN_DETAIL=@"screen_detail";
NSString *const PARAM_TIME_ZONE=@"time_zone";
NSString *const PARAM_APP_VERSION=@"app_version";
NSString *const PARAM_MANUFACTURE_TYPE=@"manufacture_type";
NSString *const PARAM_MANUFACTURE_MODEL=@"manufacture_model";
NSString *const PARAM_OPERATING_SYSTEM=@"operating_system";
NSString *const PARAM_DEVIC_TYPE=@"devic_type";
NSString *const PARAM_DEVICE_IP=@"device_ip";
NSString *const PARAM_PUBLIC_IP=@"public_ip";

NSString *const PARAM_SOURCE_ADDRESS=@"source_address";
NSString *const PARAM_DESTINATION_ADDRESS=@"destination_address";

NSString *const PARAM_HELP=@"help";
NSString *const PARAM_ISSUE_ID=@"issue_id";
NSString *const PARAM_ISSUE=@"issue";
NSString *const PARAM_ISSUE_TITLE=@"issue_title";

#pragma mark - Prefences key

NSString *const PREF_DEVICE_TOKEN=@"deviceToken";
NSString *const PREF_LYMO_DEVICE_ID=@"lymo_device_id";
NSString *const PREF_USER_TOKEN=@"usertoken";
NSString *const PREF_USER_ID=@"userid";
NSString *const PREF_REQ_ID=@"requestid";
NSString *const PREF_IS_LOGIN=@"islogin";
NSString *const PREF_IS_LOGOUT=@"islogout";
NSString *const PREF_LOGIN_OBJECT=@"loginobject";
NSString *const PREF_IS_WALK_STARTED=@"iswalkstarted";
NSString *const PREF_REFERRAL_CODE=@"referral_code";
NSString *const PREF_CUST_REFERRAL_CODE=@"cust_referal_code";
NSString *const PREF_IS_REFEREE=@"is_referee";
NSString *const PREF_FARE_AMOUNT=@"fare_amount";
NSString *const PRFE_HOME_ADDRESS=@"home_address";
NSString *const PREF_WORK_ADDRESS=@"work_address";
NSString *const PRFE_FARE_ADDRESS=@"fare_address";
NSString *const PRFE_PRICE_PER_DIST=@"price_dist";
NSString *const PRFE_PRICE_PER_TIME=@"price_time";
NSString *const PRFE_DESTINATION_ADDRESS=@"dist_address";
NSString *const PREF_IS_ETA=@"is_eta";
NSString *const PREF_USER_PHONE=@"userPhone";
NSString *const PREF_ISO_CODE=@"iso_code";
NSString *const PREF_SCREEN_STATUS=@"screen_status";
NSString *const PREF_SOCIAL_NAME=@"socialName";
NSString *const PREF_IS_SOCIAL_LOGIN=@"isSocialLogin";

NSString *const PREF_CATEGORY_TYPE_ID=@"catTypeID";
NSString *const PREF_CATEGORY_NAME=@"catName";
NSString *const PREF_CATEGORY_TIME=@"catTime";
NSString *const PREF_CATEGORY_BASE_FARE=@"catBaseFare";
NSString *const PREF_CATEGORY_MIN_FARE=@"catminFare";
NSString *const PREF_CATEGORY_IMAGE=@"catIcon";
NSString *const PREF_CAR_NAME=@"car_name";

NSString *const PREF_ADD_FAV_VIEW=@"addFavView";
NSString *const PREF_ADD_FAV_TEXT=@"addFavText";
NSString *const PREF_ADD_FAV_LAT=@"addFavLat";
NSString *const PREF_ADD_FAV_LONG=@"addFavLong";

NSString *const PREF_FAV_ORIG_ADDRESS_ID=@"favOriginAddressId";
NSString *const PREF_FAV_DEST_ADDRESS_ID=@"favDestinationAddressId";
NSString *const PREF_FAREEST_ORIG_ADDRESS_ID=@"FareEstimateOriginAddressId";
NSString *const PREF_FAREEST_DEST_ADDRESS_ID=@"FareEstimateDestinationAddressId";

NSString *const PREF_IS_FAV=@"isFav";
NSString *const PREF_FAV_TEXT=@"FavAddress";
NSString *const PREF_FAV_LAT=@"FavLat";
NSString *const PREF_FAV_LONG=@"FavLong";
NSString *const PREF_FAV_DELETEFAV=@"deleteFav";
NSString *const PREF_FAV_COUNT=@"fav_count";

NSString *const PREF_PROMO=@"promo";

NSString *const PREF_CURRENT_PAGE=@"currentPage";

NSString *const PREF_PAYMENT_OPT=@"payment_opt";
NSString *const PREF_PAYMENT_ID=@"payment_id";
NSString *const PREF_PAYMENT_CARD_NAME=@"payment_card_name";
NSString *const PREF_PAYMENT_CARD_ICON=@"payment_card_icon";
NSString *const PREF_CARD_URL=@"card_url";

NSString *const PREF_PROFILE_PIC=@"profile_pic";
NSString *const PREF_USER_NAME=@"user_name";
NSString *const PREF_USER_EMAIL=@"user_email";
NSString *const PREF_COUNTRY_CODE=@"country_code";

NSString *const PREF_SCREEN_STATUS_EDIT_PROFILE=@"screenStatusEditProfile";
NSString *const PREF_USER_OTP=@"userOtpSuccess";
NSString *const PREF_FARE_DESTINATIONTEXT=@"fareDestinationText";

NSString *const PREF_FROM_DESTINATION=@"fromDestination";
NSString *const PREF_SEARCH_EDIT_ADDRESS=@"searchEditAddress";
NSString *const PREF_SHOW_BOARDING_SCREEN=@"showOnboardingScreen";
//For setting API

#pragma mark- SETTINGS PREFERENCES KEY

NSString *const PREF_SETTING_UNIT_SET=@"unit_set";
NSString *const PREF_SETTING_RIDE_NOW=@"ride_now";
NSString *const PREF_SETTING_RIDE_LATER=@"ride_later";
NSString *const PREF_SETTING_RIDE_NOW_DESTINATION=@"ride_now_destination";
NSString *const PREF_SETTING_RIDE_LATER_DESTINATION=@"ride_later_destination";
NSString *const PREF_SETTING_PROMOCODE=@"promocode";
NSString *const PREF_SETTING_PROMOCODE_ON_CARD=@"promo_on_card";
NSString *const PREF_SETTING_PROMOCODE_ON_CASH=@"promo_on_cash";
NSString *const PREF_SETTING_REFERALCODE=@"referal_code";
NSString *const PREF_SETTING_REFERALCODE_ON_CARD=@"referal_on_card";
NSString *const PREF_SETTING_REFERALCODE_ON_CASH=@"referal_on_cash";
NSString *const PREF_SETTING_REFERED_AMOUNT=@"refered_amt";
NSString *const PREF_SETTING_REFEREEL_AMOUNT=@"refereel_amt";
NSString *const PREF_SETTING_COD=@"cod";
NSString *const PREF_SETTING_CARD_PAYMENT=@"card_payment";
NSString *const PREF_SETTING_RATE_DRIVER=@"rate_driver";
NSString *const PREF_SETTING_COMMENT_DRIVER=@"comment_driver";
NSString *const PREF_SETTING_CURRENCY_TEXT=@"currency_symb";
NSString *const PREF_SETTING_CURRENCY_SYMBOL=@"currency_symbol";
NSString *const PREF_SETTING_MENU_BOOK_RIDE=@"menu_book_ride";
NSString *const PREF_SETTING_MENU_MY_RIDE=@"menu_my_ride";
NSString *const PREF_SETTING_MENU_LOYALTY=@"menu_loyalty";
NSString *const PREF_SETTING_MENU_REFERAL=@"menu_referal";
NSString *const PREF_SETTING_MENU_PAYMENT=@"menu_payment";
NSString *const PREF_SETTING_MENU_NOTIFICATION=@"menu_notification";
NSString *const PREF_SETTING_MENU_HELP=@"menu_help";
NSString *const PREF_SETTING_MENU_ABOUT=@"menu_about";
NSString *const PREF_SETTING_REFERAL_TITLE=@"referal_title";
NSString *const PREF_SETTING_REFERAL_DESCRIPTION=@"referal_description";
NSString *const PREF_SETTING_ACCOUNT_STATUS=@"account_status";
NSString *const PREF_SETTING_LAST_FOUR=@"last_four";
NSString *const PREF_SETTING_CARD_URL=@"card_url";
NSString *const PREF_SETTING_SCREEN_STATUS=@"screen_status";
NSString *const PREF_SETTING_RIDE_LATER_TIME=@"ride_later_time";
NSString *const PREF_SETTING_RIDE_LATER_DAYS=@"ride_later_days";
NSString *const PREF_SETTING_RIDE_LATER_HOURS=@"ride_later_hours";
NSString *const PREF_SETTING_RIDE_LATER_MINUTES=@"ride_later_min";

NSString *const PREF_SETTING_REQUEST_ID_STATUS=@"request_id_status";
NSString *const PREF_SETTING_REQ_ID=@"settings_ride_complete_request_id";
NSString *const PREF_SETTING_CANCEL_PAYMENT_ID=@"settings_cancel_payment_id";
NSString *const PREF_SETTING_RIDE_LATER_MINIMUM_TIME=@"ride_later_time_limit";
NSString *const PREF_SETTING_GET_REQUEST_TIMER=@"get_request_timer";
NSString *const PREF_SETTING_PAYMENT_MODE=@"payment_mode";


#pragma mark - WEB SERVER

NSString *const FILE_REGISTER=@"register";
NSString *const FILE_LOGIN=@"login";
NSString *const FILE_OTP=@"otp";
NSString *const FILE_FORGET_PASSWORD=@"application/forgot-password";
NSString *const FILE_APPLICATION_TYPE=@"application/types1";
NSString *const FILE_APPLICATION_TYPES_TWO=@"application/types2";
NSString *const FILE_GET_PROVIDERS=@"provider_list";
NSString *const FILE_CREATE_REQUEST=@"createrequest";
NSString *const FILE_GET_REQUEST=@"getrequest";
NSString *const FILE_CANCEL_REQUEST=@"cancelrequest";
NSString *const FILE_FAVOURITES=@"favourites";
NSString *const FILE_HISTORY=@"history1";
NSString *const FILE_FAQ=@"faq";
NSString *const FILE_APPLY_REFERRAL=@"apply-referral";
NSString *const FILE_REQUEST_DETAIL=@"request_detail";
NSString *const FILE_RATING=@"rating";
NSString *const FILE_HELP=@"help";
NSString *const FILE_PROMOCODE=@"apply-promo1";
NSString *const FILE_UPDATE=@"update1";
NSString *const FILE_PAGES=@"application/pages";
NSString *const FILE_NOTIFICATIONS=@"notifications";
NSString *const FILE_GET_PROFILE=@"get_profile";
NSString *const FILE_REQUEST_HELP=@"request_help";
NSString *const FILE_HELP_DETAIL=@"help_detail";
NSString *const FILE_PEAK_TIME_TEST=@"peak_time_test";
NSString *const FILE_LOYALTY=@"loyalty";
NSString *const FILE_REFERRAL_LOGS=@"referral-logs?";
NSString *const FILE_FARE=@"fare1";
NSString *const FILE_CREATE_REQUEST_LATER=@"createrequestlater";
NSString *const FILE_LOGOUT=@"logout1";
NSString *const FILE_CARD=@"cards";
NSString *const FILE_REQUEST_PATH=@"requestpath";
NSString *const FILE_STORE_CARD=@"store_card";
NSString *const FILE_WORLDPAY_STORE_CARD=@"wp_store_card?";
NSString *const FILE_SPLASH_SETTING=@"splash_setting";
NSString *const FILE_SELECTED_CARD=@"selectcard";
NSString *const FILE_DELETE_CARD=@"delete_card";
NSString *const FILE_SET_DESTINATION=@"setdestination";
NSString *const FILE_WORLD_PAY_STORE_CARD=@"wp_store_card";
NSString *const FILE_WORLD_PAY_AES_KEY=@"aes_key";
NSString *const FILE_RECEIPT=@"receipt";
NSString *const FILE_CANCELLATION_PAYMENT_SINGLE_RIDE=@"cancellation_payment";
NSString *const FILE_CANCELLATION_PAYMENT_MULTIPLE_RIDES=@"cancelled_payment";
NSString *const FILE_SEND_CANCEL_EMAIL=@"send-cancel-email";

#pragma mark - CONSTANT STRINGS

NSString *const NO_INTERNET=@"We are having trouble reaching Orbit network. Please check your data connectivity or try again in some time.";

NSString *const UNABLE_TO_REACH=@"E500-We are having trouble reaching Orbit network. Please retry in some time.";
NSString *const UNABLE_TO_REACH_UNKNOWN=@"E100-We are having trouble reaching Orbit network. Please retry in some time.";     // NSURLErrorUnknown = -1
NSString *const UNABLE_TO_REACH_CANCELLED=@"E200-We are having trouble reaching Orbit network. Please retry in some time.";   //NSURLErrorCancelled = -999
NSString *const UNABLE_TO_REACH_BAD_URL=@"E300-We are having trouble reaching Orbit network. Please retry in some time.";     //NSURLErrorBadURL = -1000
NSString *const UNABLE_TO_REACH_TIME_OUT=@"E400-We are having trouble reaching Orbit network. Please retry in some time.";    //NSURLErrorTimedOut = -1001
NSString *const UNABLE_TO_REACH_UNSUPPORTED_URL=@"E404-We are having trouble reaching Orbit network. Please retry in some time."; //NSURLErrorUnsupportedURL = -1002
NSString *const UNABLE_TO_REACH_CANNOT_FIND_HOST=@"E600-We are having trouble reaching Orbit network. Please retry in some time."; //NSURLErrorCannotFindHost = -1003
NSString *const UNABLE_TO_REACH_CANNOT_CONNECT_TO_HOST=@"E700-We are having trouble reaching Orbit network. Please retry in some time.";
//NSURLErrorCannotConnectToHost = -1004
NSString *const UNABLE_TO_REACH_RESOURCE_UNAVAILABLE=@"E800-We are having trouble reaching Orbit network. Please retry in some time.";
// NSURLErrorResourceUnavailable = -1008
NSString *const UNABLE_TO_REACH_NETWORK_CONNECTION_LOST=@"E900-We are having trouble reaching Orbit network. Please retry in some time.";
// NSURLErrorNetworkConnectionLost = -1005

NSString *const UNABLE_TO_REACH_EXCEED_MAXDATA=@"E1000-We are having trouble reaching Orbit network. Please retry in some time.";
NSString *const UNABLE_TO_REACH_BAD_RESPONSE=@"E1011-We are having trouble reaching Orbit network. Please retry in some time."; //NSURLErrorBadServerResponse = -1011

// NSURLErrorDataLengthExceedsMaximum = -1103



NSString *const PLEASE_ENABLE_LOCATION_SERVICES=@"Please Enable location access from Setting -> Orbit -> Privacy -> Location services";
NSString *const NO_DRIVERS_FOUND_MESSAGE=@"We regret informing you that we are unable to locate any nearby driver to complete your ride request";
NSString *const NO_DRIVERS_FOUND_TITLE=@"Driver Not Found";

NSString *const PLEASE_ENTER_NAME=@"Please enter your Name";
NSString *const PLEASE_ENTER_EMAIL=@"Please enter a valid email";
NSString *const PLEASE_ENTER_VALID_EMAIL=@"Please enter a valid email";
NSString *const PLEASE_ENTER_PASSWORD=@"Choose a password to login";
NSString *const PLEASE_ENTER_VALID_MOBILE_NUMBER=@"Enter your 10 digit valid mobile number";
NSString *const PLEASE_ENTER_VALID_UK_MOBILE_NUMBER=@"Please enter valid UK mobile number";
NSString *const PLEASE_ENTER_YOUR_OTP_NUMBER=@"Enter the verification code sent to your registered mobile number";
NSString *const PLEASE_ENTER_REGISTERED_EMAIL=@"Please enter your registered email to login";
NSString *const PLEASE_ENTER_REGISTERED_PASSWORD=@"Please enter your registered password to login";
NSString *const PLEASE_ENTER_NO_SPACE=@"Enter your registered email or a 10 digit mobile number";

NSString *const PLEASE_ENTER_YOUR_REFERRAL=@"Enter a valid referral code";
NSString *const PLEASE_ENTER_EMAIL_OR_PHONE_NUMBER=@"Enter your registered email or a 10 digit mobile number";
NSString *const PLEASE_ENTER_USER_Name=@"Please enter your Name";
NSString *const PLEASE_ENTER_VALID_PHONE_NUMBER=@"Enter your 10 digit valid mobile number";
NSString *const PLEASE_GIVE_EMAIL_PERMISSION=@"Please give permission to get Email id";
NSString *const PLEASE_ENTER_COUNTRY_CODE=@"Please select your country code";

NSString *const PLEASE_ENTER_CARD_NAME=@"Enter the card name";
NSString *const PLEASE_ENTER_CARD_NUMBER=@"Enter your credit/debit card number";
NSString *const PLEASE_ENTER_VALID_CARD_NUMBER=@"Enter a valid credit/debit card number";
NSString *const PLEASE_ENTER_MONTH_YEAR=@"Enter card validity as printed on the card";
NSString *const PLEASE_ENTER_CVV=@"Enter CVV number as printed on the card";
NSString *const PLEASE_ENTER_PROMO_CODE=@"Enter a valid promo code";
NSString *const PLEASE_SELECT_A_CARD=@"Please select a card";

NSString *const PLEASE_ENTER_ALL_FIELDS=@"Please enter all the fields";
NSString *const PLEASE_ENTER_OLD_PASSWORD=@"Enter your existing password";
NSString *const PLEASE_ENTER_NEW_PASSWORD=@"Enter your new password";
NSString *const PLEASE_REPEAT_NEW_PASSWORD=@"Repeat your new password";
NSString *const PLEASE_ENTER_NEW_PASSWORD_NOT_OLD=@"Enter a new password, this should not be same as old password";
NSString *const RETYPE_PASSWORD_MISMATCH=@"Retype password mismatch. New password & Repeat password does not match. Try again";

NSString *const RIDE_IS_CANCELLED_200=@"A200- Your booking has been cancelled. Kindly make a new booking.";
NSString *const RIDE_IS_CANCELLED_100=@"A100 - We are unable to serve your request now. Please retry";
NSString *const RIDE_CANCELLED_BY_CUSTOMER=@"Your ride with Orbit is cancelled successfully. Hope to see you soon!";
NSString *const RIDE_CANCELLED_BY_DRIVER=@"D300- The driver has cancelled this booking. Kindly make a new booking.";
NSString *const SURGE_DESCRIPTION=@"To serve the heavy demand, this trip will have surge pricing applicable.";

NSString *const PLEASE_ENTER_SOURCE=@"Please enter valid source address";
NSString *const PLEASE_ENTER_DESTINATION=@"Please enter valid destination address";
NSString *const PLEASE_SELECT_PROPER_LOCATION=@"Please enter proper location";


NSString *const PLEASE_GIVE_DRIVER_RATING=@"Please give driver rating";
NSString *const PLEASE_COMMENT_ON_DRIVER=@"Comments is mandatory";

NSString *const PLEASE_SELECT_AN_ISSUE=@"Choose the type of issue you want to post to us";
NSString *const PLEASE_ENTER_ISSUE_DESCRIPTION=@"A brief desctipion is required to understand your concern";

NSString *const NO_FAVOURITES=@"Start adding your favourite location to the list. Example: Home Location, Office Location, etc...";
NSString *const PLEASE_ENTER_TITLE=@"Enter a title to identify your favourite location. Example: Home, Office, etc...";
NSString *const ADDRESS_ADDED_SUCCESSFULLY=@"New favourite location is successfully added";
NSString *const ADDRESS_DELETED_SUCCESSFULLY=@"Selected favourite is successfully deleted";
NSString *const ADDRESS_UPDATED_SUCCESSFULLY=@"This favourite locaiton is successfully updated";

NSString *const ARE_U_SURE_LOGOUT=@"Are you sure you want to logout";

@end
