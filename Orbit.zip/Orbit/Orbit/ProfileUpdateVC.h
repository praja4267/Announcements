//
//  ProfileUpdateVC.h
//  
//
//  Created by Active Mac06 on 17/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@protocol ProfileUpdateVCProtocol;

@interface ProfileUpdateVC : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}
@property (nonatomic, weak) id<ProfileUpdateVCProtocol> profileUpdateVCDelegate;

@property (strong, nonatomic) IBOutlet UIButton *editProfileCountryCodeBtn;
- (IBAction)editProfileCountryCodeBtn:(id)sender;

// Button
@property (strong, nonatomic) IBOutlet UIButton *BackBtn;
@property (strong, nonatomic) IBOutlet UIButton *DoneBtn;

// Action

- (IBAction)Back:(id)sender;
- (IBAction)Done:(id)sender;

// ImageView
@property (strong, nonatomic) IBOutlet UIImageView *profilePic;
@property (weak, nonatomic) IBOutlet UIImageView *profilePicEdit;


// TextView
@property (strong, nonatomic) IBOutlet UITextField *UserNameTxt;
@property (strong, nonatomic) IBOutlet UITextField *EmailTxt;
@property (strong, nonatomic) IBOutlet UITextField *PhoneTxt;

@property (strong, nonatomic) IBOutlet UIScrollView *profileScrl;
@property (strong, nonatomic) UIImage *proPic_img;
@property (strong, nonatomic) NSString *phoneCode;
@end


@protocol ProfileUpdateVCProtocol <NSObject>

-(void)isNewImageSelected:(BOOL )selected;

@end
