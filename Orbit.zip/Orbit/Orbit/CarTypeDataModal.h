//
//  CarTypeDataModal.h
//  UberforXOwner
//
//  Created by Deep Gami on 14/11/14.
//  Copyright (c) 2014 Jigs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarTypeDataModal : NSObject
@property (nonatomic,strong) NSString *id_;
@property (nonatomic,strong) NSString *catName;
@property int carType_count;
@property (nonatomic,strong) NSString *catTypeName;
@property (nonatomic,strong) NSString *seating;
@property (nonatomic,strong) NSString *baseFare;
@property (nonatomic, strong) NSString *min_fare;
@property (nonatomic,strong) NSString *icon;
@property (nonatomic,strong) NSString *is_default;
@property (nonatomic,strong) NSString *price_per_unit_time;
@property (nonatomic,strong) NSString *price_per_unit_distance;
@property (nonatomic,strong) NSString *basePrice;
@property (nonatomic,strong) NSString *baseKM;
@property (nonatomic,strong) NSString *baseAfterPrice;
@property (nonatomic,strong) NSString *map_icon;
@property (nonatomic,strong) NSString *TimeKM;
@property (nonatomic, strong) NSString *ios_cat_image;
@property (nonatomic,assign)BOOL isSelected;

@end
