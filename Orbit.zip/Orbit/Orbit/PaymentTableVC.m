//
//  PaymentTableVC.m
//  
//
//  Created by Active Mac06 on 23/11/15.
//
//

#import "PaymentTableVC.h"
#import "Constants.h"


@interface PaymentTableVC ()
@property (strong, nonatomic) IBOutlet UITableView *tbl_Paymentsetup;

@end

@implementation PaymentTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _tbl_Paymentsetup.delegate=self;
    
    
    _tbl_Paymentsetup.tableFooterView = [UIView new];
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
}


#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([[[NSUserDefaults standardUserDefaults] valueForKey:PREF_SETTING_CARD_PAYMENT] boolValue]) {
        return 2;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PaymentCells" forIndexPath:indexPath];
    
    // Configure the cell...
    cell.textLabel.textColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1];
    
    cell.textLabel.font=[UIFont fontWithName:@"Dinpro" size:18];
    
   
    if(indexPath.row==0){
        cell.textLabel.text=@"Cash";
        cell.imageView.image=[UIImage imageNamed:@"Cash_icon"];
    }else{
        cell.textLabel.text=@"Add Credit/Debit Cards";
        cell.imageView.image=[UIImage imageNamed:@"Card_icon"];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
       return 50.0;  
    
}

# pragma -TableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([APPDELEGATE connected]) {
        if(indexPath.row==0){
            [self performSegueWithIdentifier:STRING_SEGUE_ON_BOARDING_PAGE sender:self];
        }else{
            [self performSegueWithIdentifier:STRING_SEGUE_ADD_CARD sender:self];
        }
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button Actions

- (IBAction)paymentBackBtn:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - addcard viewcontroller delegate method

-(void)cardAddedFromWebViewWithMessage:(NSString *)message{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:message message:@"" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark - Segue Actions

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_ADD_CARD]){
        addCardViewController *addCardController = (addCardViewController *)segue.destinationViewController;
        addCardController.addcardDelegate=self;
        addCardController.strForCurrentPage=@"login";
    }
}


#pragma mark - Custom Popup Delegate
- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}


@end
