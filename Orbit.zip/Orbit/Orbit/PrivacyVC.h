//
//  PrivacyVC.h
//  
//
//  Created by Active Mac06 on 18/12/15.
//
//

#import <UIKit/UIKit.h>

@interface PrivacyVC : UIViewController

@property (nonatomic,strong) NSString *toTitle;
@property (nonatomic,strong) NSString *toContent;

@end
