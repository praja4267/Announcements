//
//  HelpViewController.h
//  
//
//  Created by ActiveMac03 on 18/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface HelpViewController : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

@property (weak, nonatomic) IBOutlet UIButton *helpMenuBtn;
@property (weak, nonatomic) IBOutlet UIButton *helpFAQBtn;
@property (weak, nonatomic) IBOutlet UITableView *helpTableView;
- (IBAction)helpMenuBtn:(id)sender;
- (IBAction)helpFAQBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *helpEmptyView;

@end
