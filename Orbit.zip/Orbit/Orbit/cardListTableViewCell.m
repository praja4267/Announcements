//
//  cardListTableViewCell.m
//  
//
//  Created by ActiveMac03 on 08/01/16.
//
//

#import "cardListTableViewCell.h"

@implementation cardListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
