//
//  cardListTableViewCell.h
//  
//
//  Created by ActiveMac03 on 08/01/16.
//
//

#import <UIKit/UIKit.h>

@interface cardListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cardListName;
@property (weak, nonatomic) IBOutlet UIImageView *cardListIcon;
@property (weak, nonatomic) IBOutlet UILabel *cardListNumber;
@property (strong, nonatomic) IBOutlet UIImageView *cardListDefaultSelectedImgView;

@end
