//
//  AppDelegate.m
//  lymo
//
//  Created by Active Mac06 on 02/11/15.
//  Copyright © 2015 techActive. All rights reserved.
//

#import "AppDelegate.h"
#import "MBProgressHUD.h"
//#import <GoogleMapsM4B/GoogleMaps.h>
#import <GoogleMaps/GoogleMaps.h>
#import "Constants.h"
#import "googleSignInDataModal.h"
#import "TJSpinner.h"
#import <Crittercism/Crittercism.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <sys/utsname.h>
#import "AFNHelper.h"
#import "RideCompleteVC.h"
#import "OutStandingPaymentsViewController.h"
#include <ifaddrs.h>
#include <arpa/inet.h>
#import "SystemServices.h"
#import "ATAppUpdater.h"

NSString *const kTJCircularSpinner = @"TJCircularSpinner";

@interface AppDelegate (){
    TJSpinner *circularSpinner;
    NSString *public_ip;
    NSString *device_ip;
    UILabel *myLabel;
    UIView *holderView;
    int notificationCount;
    CustomIOSAlertView *commonCustomAlertView;
    BOOL ActivateForceUpdate;
    ATAppUpdater *updater;
}

//@property (nonatomic, strong) LLARingSpinnerView *spinnerView;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    //    [self deleteAllFilesStoredInDocumentsDirectory];
    ActivateForceUpdate = YES;  // appstoreId : 1149945930 -> for force update ActivateForceUpdate = YES and for optional Update use ActivateForceUpdate = NO
    updater = [ATAppUpdater sharedUpdater];
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
    notificationCount=0;
    [GMSServices provideAPIKey:GOOGLE_KEY];
    
    [GIDSignIn sharedInstance].clientID = kClientId;
    
    [GIDSignIn sharedInstance].delegate = self;
    
    [Crittercism enableWithAppID:CRITTERCISM_APP_ID];
    [[UITextField appearance] setTintColor:[UIColor blackColor]];
    [[UITextView appearance] setTintColor:[UIColor blackColor]];
    [[NSUserDefaults standardUserDefaults] setValue:@(NO) forKey:@"_UIConstraintBasedLayoutLogUnsatisfiable"];
    //-- Set Notification
    
    if ([application respondsToSelector:@selector(registerUserNotificationSettings:)] || [application respondsToSelector:@selector(isRegisteredForRemoteNotifications)]) {
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeBadge
                                                                                             |UIUserNotificationTypeSound
                                                                                             |UIUserNotificationTypeAlert) categories:nil];
        [application registerUserNotificationSettings:settings];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    [pref setValue:@"0" forKey:PREF_DEVICE_TOKEN];
    [pref setValue:@"-1" forKey:PREF_SETTING_REQ_ID];
    [pref synchronize];
    [self getPublicIPAddress];
    device_ip = [self getDeviceIPAddress];
    
    
    commonCustomAlertView = [[CustomIOSAlertView alloc] init];
    [commonCustomAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [commonCustomAlertView setDelegate:self];
    [commonCustomAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [commonCustomAlertView setUseMotionEffects:true];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [FBSDKAppEvents activateApp];
    
    
    if (ActivateForceUpdate) {
        [updater showUpdateWithForce];
    }else{
        [updater showUpdateWithConfirmation];
    }
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    //    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    //    if([CLLocationManager locationServicesEnabled]&&
    //       [CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied)
    //    {
    //        if ([pref boolForKey:@"locationStatus"]) {
    //            UIAlertView* locationAlert=[[UIAlertView alloc] initWithTitle:@"This app does not have access to Location services" message:@"Please allow Orbit to use location services .Turn it on from settings" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Settings", nil];
    //                locationAlert.tag=1;
    //                 [locationAlert show];
    //        }else{
    //
    //        }
    //    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==1 && buttonIndex == 1)
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }else if (alertView.tag==2){
        [APPDELEGATE logout:^(BOOL completion){
            ALog(@"successfully logged out");
        }];
        //         [APPDELEGATE logout];
        
    }
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    // Saves changes in the application's managed object context before the application terminates.
    //    [self saveContext];
}


#pragma mark - Directory Path Methods

- (NSString *)applicationCacheDirectoryString
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cacheDirectory = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return cacheDirectory;
}

- (BOOL)connected
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
}

-(void)showToastMessage:(NSString *)message
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window
                                              animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabelText = message;
    hud.margin = 10.f;
    hud.yOffset = 150.f;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:2.0];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                                          openURL:url
                                                sourceApplication:sourceApplication
                                                       annotation:annotation
            ] || [[GIDSignIn sharedInstance] handleURL:url sourceApplication:sourceApplication annotation:annotation];
}

- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    if(error==nil){
        googleSignInDataModal *googleSignInModel = [[googleSignInDataModal alloc]init];
        googleSignInModel.userName=user.profile.name;
        googleSignInModel.userID=user.userID;
        googleSignInModel.userEmail=user.profile.email;
        [[NSNotificationCenter defaultCenter] postNotificationName: @"googleSignIn" object:googleSignInModel];
        [self didTapSignOut:nil];
    }else{
        ALog(@"%@",error);
    }
}

- (IBAction)didTapSignOut:(id)sender {
    [[GIDSignIn sharedInstance] signOut];
}

#pragma mark - Device information

-(NSMutableDictionary *)deviceInfo{
    NSMutableDictionary *deviceInfoDict=[[NSMutableDictionary alloc]init];
    
    NSString* currentDeviceId = [[[UIDevice currentDevice] identifierForVendor]UUIDString];
    NSTimeZone *timeZone = [NSTimeZone localTimeZone];
    NSString *tzName = [timeZone name];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    float scale = [[UIScreen mainScreen] scale];
    float ppi = scale * ((UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) ? 132 : 163);
    float width = ([[UIScreen mainScreen] bounds].size.width * scale);
    float height = ([[UIScreen mainScreen] bounds].size.height * scale);
    float horizontal = width / ppi, vertical = height / ppi;
    float inches = sqrt(pow(horizontal, 2) + pow(vertical, 2));
    
    NSString *deviceType;
    NSString *resolution = [NSString stringWithFormat:@"%d*%d",(int)roundf(SCREEN_WIDTH*SCREEN_SCALE),(int)roundf(SCREEN_HEIGHT*SCREEN_SCALE)];
    
    if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPad) {
        deviceType=@"IPAD";
    }else{
        deviceType=@"IPHONE";
    }
    
    [deviceInfoDict setValue:currentDeviceId forKey:PARAM_DEVICE_ID];
    [deviceInfoDict setValue:[[UIDevice currentDevice] systemVersion] forKey:PARAM_OS_VERSION];
    [deviceInfoDict setValue:resolution forKey:PARAM_RESOLUTION];
    [deviceInfoDict setValue:[NSString stringWithFormat:@"%.1f",inches] forKey:PARAM_SCREEN_DETAIL];
    [deviceInfoDict setValue:tzName forKey:PARAM_TIME_ZONE];
    [deviceInfoDict setValue:version forKey:PARAM_APP_VERSION];
    [deviceInfoDict setValue:deviceType forKey:PARAM_DEVIC_TYPE];
    [deviceInfoDict setValue:[self deviceName] forKey:PARAM_MANUFACTURE_TYPE];
    [deviceInfoDict setValue:[[SystemServices sharedServices] systemDeviceTypeFormatted] forKey:PARAM_MANUFACTURE_MODEL];
    [deviceInfoDict setValue:@"iOS" forKey:PARAM_OPERATING_SYSTEM];
    [deviceInfoDict setValue:device_ip forKey:PARAM_DEVICE_IP];
    if (public_ip) {
        [deviceInfoDict setValue:public_ip forKey:PARAM_PUBLIC_IP];
    } else {
        [self getPublicIPAddress];
        [deviceInfoDict setValue:public_ip forKey:PARAM_PUBLIC_IP];
    }
    ALog(@"device info = %@", deviceInfoDict);
    return deviceInfoDict;
}

- (NSString *)getDeviceIPAddress {
    
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    ALog(@"device address = %@", address);
    return address;
    
}

-(void)getPublicIPAddress {
    if ([self connected]) {
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSError *error;
            __block NSString *publicIP = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"https://icanhazip.com/"] encoding:NSUTF8StringEncoding error:&error];
            if (publicIP) {
                publicIP = [publicIP stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]]; // IP comes with a newline for some reason
                public_ip = publicIP;
                ALog(@"My public IP address using icanhazip is: %@", publicIP);
            }
            else {
                ALog(@"could not get the public ip address , error = %@", error.description);
                publicIP = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://bot.whatismyipaddress.com/"] encoding:NSUTF8StringEncoding error:nil];
                if (publicIP) {
                    publicIP = [publicIP stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]]; // IP comes with a newline for some reason
                    public_ip = publicIP;
                    ALog(@"My public IP address using bot.whatismyipaddress.com is: %@", publicIP);
                }
            }
            
            ALog(@"My public IP address using bot.whatismyipaddress.com is: %@", publicIP);
        });
    }
}


- (NSString* ) deviceName {
    struct utsname systemInfo;
    uname(&systemInfo);
    
    return [NSString stringWithCString:systemInfo.machine
                              encoding:NSUTF8StringEncoding];
}

#pragma mark - Loader

- (void)startLoader:(UIView*)view giveSpaceFornavigationBar:(BOOL)navigationBar {
    /*Loader*/
    UIWindow* mainWindow = [[UIApplication sharedApplication] keyWindow];
    
    if(navigationBar){
        _overlayView = [[UIView alloc] initWithFrame:CGRectMake(0, 67, view.frame.size.width, view.frame.size.height)];
        _overlayView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.0];
        UIImageView *spinBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 81,81)];
        spinBG.center=CGPointMake(view.center.x, view.center.y-67);
        [spinBG setImage:[UIImage imageNamed:@"spinerView"]];
        [_overlayView addSubview:spinBG];
        circularSpinner = [[TJSpinner alloc] initWithSpinnerType:kTJCircularSpinner];
        circularSpinner.hidesWhenStopped = NO;
        circularSpinner.radius = 20.0f;
        circularSpinner.pathColor = [UIColor whiteColor];
        circularSpinner.fillColor = [UIColor orbitYellowColor];
        circularSpinner.thickness = 4;
        circularSpinner.center=CGPointMake(view.center.x, view.center.y-69);
        [_overlayView addSubview:circularSpinner];
        [mainWindow addSubview:_overlayView];
        [circularSpinner startAnimating];
    }else{
        _overlayView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _overlayView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.0];
        _innerOverlayView = [[UIView alloc] initWithFrame:CGRectMake(0, 67, view.frame.size.width, view.frame.size.height)];
        _innerOverlayView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.0];
        [_overlayView addSubview:_innerOverlayView];
        UIImageView *spinBG = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 81,81)];
        spinBG.center=view.center;
        [spinBG setImage:[UIImage imageNamed:@"spinerView"]];
        [_overlayView addSubview:spinBG];
        
        circularSpinner = [[TJSpinner alloc] initWithSpinnerType:kTJCircularSpinner];
        circularSpinner.hidesWhenStopped = NO;
        circularSpinner.radius = 20.0f;
        circularSpinner.pathColor = [UIColor whiteColor];
        circularSpinner.fillColor = [UIColor orbitYellowColor];
        circularSpinner.thickness = 4;
        circularSpinner.center=CGPointMake(view.center.x, view.center.y-2);
        [_overlayView addSubview:circularSpinner];
        [mainWindow addSubview:_overlayView];
        [circularSpinner startAnimating];
    }
    
}

- (void)stopLoader:(UIView*)view {
    [circularSpinner stopAnimating];
    [_overlayView removeFromSuperview];
}

-(void)changeLoaderBackgroundColorwithAlpha:(UIColor*)color {
    [_innerOverlayView setBackgroundColor:color];
}
#pragma mark - Push notification

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString * deviceTokenString = [[[[deviceToken description]
                                      stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                     stringByReplacingOccurrencesOfString: @">" withString: @""]
                                    stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    //ALog(@"the generated device token string is : %@",deviceToken);
    ALog(@"My device token is: %@", deviceTokenString);
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    [pref setValue:deviceTokenString forKey:PREF_DEVICE_TOKEN];
    [pref synchronize];
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
    ALog(@"Failed to get token, error: %@", error);
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    [pref setValue:@"0" forKey:PREF_DEVICE_TOKEN];
    [pref synchronize];
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        notificationCount = 0;
        ALog(@"the notification is  %@",userInfo);
        ALog(@"the keys are %@",[userInfo allKeys]);
        NSMutableAttributedString *AattrString;
        UIFont *ArialFont = [UIFont fontWithName:@"Dinpro-Medium" size:16.0];
        NSDictionary *arialdict = [NSDictionary dictionaryWithObject: ArialFont forKey:NSFontAttributeName];
        AattrString = [[NSMutableAttributedString alloc] initWithString:@"Orbit Notification Received" attributes: arialdict];
        if([[userInfo valueForKey:@"aps"] valueForKey:@"title"]){
            AattrString = [[NSMutableAttributedString alloc] initWithString:[[userInfo valueForKey:@"aps"] valueForKey:@"title"] attributes: arialdict];
        }else {
            AattrString = [[NSMutableAttributedString alloc] initWithString:[[userInfo valueForKey:@"aps"] valueForKey:@"alert"] attributes: arialdict];
        }
        
        UIFont *VerdanaFont = [UIFont fontWithName:@"Dinpro" size:14.0];
        NSDictionary *veradnadict = [NSDictionary dictionaryWithObject:VerdanaFont forKey:NSFontAttributeName];
        if([[userInfo valueForKey:@"aps"] valueForKey:@"message"]){
            NSMutableAttributedString *VattrString = [[NSMutableAttributedString alloc]initWithString: [NSString stringWithFormat:@"%@\n%@", @"\n", [[userInfo valueForKey:@"aps"] valueForKey:@"message"]] attributes:veradnadict];
            ALog(@"the message is %@", [NSString stringWithFormat:@"%@\n%@", @"\n", [[userInfo valueForKey:@"aps"] valueForKey:@"title"]]);
            [VattrString addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:(NSMakeRange(0, VattrString.length - 1))];
            
            [AattrString appendAttributedString:VattrString];
        }
        
        UIViewController *topController=[AppDelegate topMostController];
        [topController.view endEditing:YES];
        [commonCustomAlertView setContainerView:[self createDemoViewWithAttributedString:AattrString view:topController.view]];
        [commonCustomAlertView show];
    } else {
        notificationCount += 1;
        [[UIApplication sharedApplication] setApplicationIconBadgeNumber:notificationCount];
    }
}

-(void)showAlertOnTopMostControllerWithText:(NSString*)message{
    UIViewController *topController=[AppDelegate topMostController];
    [commonCustomAlertView setContainerView:[self createDemoView:message view:topController.view]];
    [commonCustomAlertView show];
}

//-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    [super touchesBegan:touches withEvent:event];
//    CGPoint locationPoint = [[touches anyObject] locationInView:self.window];
//    UIView* viewYouWishToObtain = [self.window hitTest:locationPoint withEvent:event];
//    if (viewYouWishToObtain.tag == 1010 || viewYouWishToObtain.tag == 1011) {
//    }
//
//}

#pragma mark - Custom AlertView
- (UIView *)createDemoView:(NSString*)message view:(UIView*)view
{
    UILabel *fromLabel = [[UILabel alloc] initWithFrame:CGRectMake(50,0, self.window.frame.size.width-100,100)];
    fromLabel.text=message;
    fromLabel.numberOfLines=0;
    fromLabel.lineBreakMode = NSLineBreakByWordWrapping;
    fromLabel.textAlignment=NSTextAlignmentCenter;
    fromLabel.font = [UIFont fontWithName:@"Dinpro" size:15];
    [fromLabel sizeToFit];
    UIView *demoHolderView= [UIView new];
    if (fromLabel.frame.size.height < self.window.frame.size.height - 100) {
        demoHolderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.window.frame.size.width - 80, fromLabel.frame.size.height + 40)];
        [demoHolderView setBackgroundColor: [UIColor whiteColor]];
        fromLabel.center=demoHolderView.center;
        [demoHolderView addSubview:fromLabel];
    }else {
        demoHolderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.window.frame.size.width - 80, self.window.frame.size.height - 100)];
        UIScrollView *scrlView = [[UIScrollView alloc] initWithFrame:demoHolderView.frame];
        [scrlView setScrollEnabled:YES];
        [scrlView setContentSize:CGSizeMake(self.window.frame.size.width - 80, fromLabel.frame.size.height + 50)];
        [scrlView setBackgroundColor: [UIColor whiteColor]];
        fromLabel.frame = CGRectMake(0, 0, self.window.frame.size.width - 80, fromLabel.frame.size.height + 40);
        [scrlView addSubview:fromLabel];
        [demoHolderView addSubview:scrlView];
    }
    return demoHolderView;
}


- (UIView *)createDemoViewWithAttributedString:(NSMutableAttributedString*)message view:(UIView*)view
{
    UILabel *fromLabel = [[UILabel alloc] initWithFrame:CGRectMake(50,0, self.window.frame.size.width-100,100)];
    fromLabel.attributedText=message;
    fromLabel.numberOfLines=0;
    fromLabel.lineBreakMode = NSLineBreakByWordWrapping;
    fromLabel.textAlignment=NSTextAlignmentCenter;
    [fromLabel sizeToFit];
    
    UIView *demoHolderView= [UIView new];
    
    if (fromLabel.frame.size.height < 200) {
        demoHolderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.window.frame.size.width - 80, 200)];
        ALog(@"fromLabel.frame.size.height + 40 = %f and text = %@", fromLabel.frame.size.height + 40, message);
        [demoHolderView setBackgroundColor: [UIColor whiteColor]];
        fromLabel.center=demoHolderView.center;
        [demoHolderView addSubview:fromLabel];
    }else {
        demoHolderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.window.frame.size.width - 80, 200)];
        UIScrollView *scrlView = [[UIScrollView alloc] initWithFrame:demoHolderView.frame];
        [scrlView setScrollEnabled:YES];
        [scrlView setContentSize:CGSizeMake(self.window.frame.size.width - 80, fromLabel.frame.size.height + 50)];
        [scrlView setBackgroundColor: [UIColor whiteColor]];
        fromLabel.frame = CGRectMake(0, 0, self.window.frame.size.width - 80, fromLabel.frame.size.height + 40);
        [scrlView addSubview:fromLabel];
        [demoHolderView addSubview:scrlView];
    }
    
    return demoHolderView;
}

- (CGFloat)getLabelHeightWithString:(NSString*)message
{
    CGSize constraint = CGSizeMake(self.window.frame.size.width - 100, CGFLOAT_MAX);
    CGSize size;
    
    NSStringDrawingContext *context = [[NSStringDrawingContext alloc] init];
    CGSize boundingBox = [message boundingRectWithSize:constraint
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:@{NSFontAttributeName:[UIFont fontWithName:@"Dinpro" size:15]}
                                               context:context].size;
    
    size = CGSizeMake(ceil(boundingBox.width), ceil(boundingBox.height));
    
    return size.height;
}

- (void)logout: (myCompletion) completionBlock {
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        ALog(@"Logout parameters are %@", dictParam);
        ALog(@"Device token at logout is %@", [pref objectForKey:PREF_DEVICE_TOKEN]);
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_LOGOUT withParamData:dictParam withBlock:^(id response, NSError *error){
            ALog(@"The response in logout is %@", response);
            if (response == Nil){
                [circularSpinner stopAnimating];
                [_overlayView removeFromSuperview];
            }else if (response){
                NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
                [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
                [APPDELEGATE.window setRootViewController:nil];
                [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil]instantiateViewControllerWithIdentifier:@"LoginRegisterViewController"]];
                [self logOutFromFaceBook];
                completionBlock(YES);
            }
        }];
    }else{
        [commonCustomAlertView setContainerView:[self createDemoView:NO_INTERNET view:[AppDelegate topMostController].view]];
        [commonCustomAlertView show];
    }
}


-(void) logOutFromFaceBook {
    [[FBSDKLoginManager new] logOut];
    NSHTTPCookieStorage* cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray* facebookCookies = [cookies cookiesForURL:[NSURL URLWithString:@"https://facebook.com/"]];
    
    for (NSHTTPCookie* cookie in facebookCookies) {
        [cookies deleteCookie:cookie];
    }
}


-(void) deleteAllFilesStoredInDocumentsDirectory{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if ([paths count] > 0)
    {
        NSError *error = nil;
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        // Print out the path to verify we are in the right place
        NSString *directory = [paths objectAtIndex:0];
        NSLog(@"Directory: %@", directory);
        
        // For each file in the directory, create full path and delete the file
        for (NSString *file in [fileManager contentsOfDirectoryAtPath:directory error:&error])
        {
            NSString *filePath = [directory stringByAppendingPathComponent:file];
            NSLog(@"File : %@", filePath);
            
            BOOL fileDeleted = [fileManager removeItemAtPath:filePath error:&error];
            
            if (fileDeleted != YES || error != nil)
            {
                // Deal with the error...
            }
        }
        
    }
}

#pragma mark - Setting API

-(void) myMethod:(myCompletion) compblock {
    //do stuff
    compblock(YES);
}

-(NSString*)getTheErrorMessageFromError : (NSError*)error{
    NSString *message = @"";
    if (error.code == -1) {
        message = UNABLE_TO_REACH_UNKNOWN;
    }else if (error.code == -999){
        message = UNABLE_TO_REACH_CANCELLED;
    }else if (error.code == -1000){
        message = UNABLE_TO_REACH_BAD_URL;
    }else if (error.code == -1001){
        message = UNABLE_TO_REACH_TIME_OUT;
    }else if (error.code == -1002){
        message = UNABLE_TO_REACH_UNSUPPORTED_URL;
    }else if (error.code == -1003){
        message = UNABLE_TO_REACH_CANNOT_FIND_HOST;
    }else if (error.code == -1004){
        message = UNABLE_TO_REACH_CANNOT_CONNECT_TO_HOST;
    }else if (error.code == -1008){
        message = UNABLE_TO_REACH_RESOURCE_UNAVAILABLE;
    }else if (error.code == -1103){
        message = UNABLE_TO_REACH_EXCEED_MAXDATA;
    }else if (error.code == -1011){
        message = UNABLE_TO_REACH_BAD_RESPONSE;
    }else {
        message = UNABLE_TO_REACH;
    }
    ALog(@"error message = %@ and error = %@", message, error);
    return message;
}
-(void)customerSetting:(NSMutableDictionary *)setting ShowRideComplete:(BOOL)rideComplete ShowCancelPayment : (BOOL)paymentStatus FromViewController:(UIViewController*) currentViewController {
    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
    if ([APPDELEGATE settingsStatus:setting]) {
        [pref setObject:[setting valueForKey:@"unit_set"] forKey:PREF_SETTING_UNIT_SET];
        [pref setObject:[setting valueForKey:@"ride_now"] forKey:PREF_SETTING_RIDE_NOW];
        [pref setObject:[setting valueForKey:@"ride_later"] forKey:PREF_SETTING_RIDE_LATER];
        [pref setObject:[setting valueForKey:@"ride_now_destination"] forKey:PREF_SETTING_RIDE_NOW_DESTINATION];
        [pref setObject:[setting valueForKey:@"ride_later_destination"] forKey:PREF_SETTING_RIDE_LATER_DESTINATION];
        [pref setObject:[setting valueForKey:@"promocode"] forKey:PREF_SETTING_PROMOCODE];
        [pref setObject:[setting valueForKey:@"promo_on_card"] forKey:PREF_SETTING_PROMOCODE_ON_CARD];
        [pref setObject:[setting valueForKey:@"promo_on_cash"] forKey:PREF_SETTING_PROMOCODE_ON_CASH];
        [pref setObject:[setting valueForKey:@"referal_code"] forKey:PREF_SETTING_REFERALCODE];
        [pref setObject:[setting valueForKey:@"referal_on_card"] forKey:PREF_SETTING_REFERALCODE_ON_CARD];
        [pref setObject:[setting valueForKey:@"referal_on_cash"] forKey:PREF_SETTING_REFERALCODE_ON_CASH];
        [pref setObject:[setting valueForKey:@"refered_amt"] forKey:PREF_SETTING_REFERED_AMOUNT];
        [pref setObject:[setting valueForKey:@"refereel_amt"] forKey:PREF_SETTING_REFEREEL_AMOUNT];
        [pref setObject:[setting valueForKey:@"cod"] forKey:PREF_SETTING_COD];
        [pref setObject:[setting valueForKey:@"card_payment"] forKey:PREF_SETTING_CARD_PAYMENT];
        [pref setObject:[setting valueForKey:@"payment_mode"] forKey:PREF_SETTING_PAYMENT_MODE];
        [pref setObject:[setting valueForKey:@"rate_driver"] forKey:PREF_SETTING_RATE_DRIVER];
        [pref setObject:[setting valueForKey:@"comment_driver"] forKey:PREF_SETTING_COMMENT_DRIVER];
        [pref setObject:[setting valueForKey:@"currency_symb"] forKey:PREF_SETTING_CURRENCY_TEXT];
        [pref setObject:[setting valueForKey:@"currency_symbol"] forKey:PREF_SETTING_CURRENCY_SYMBOL];
        [pref setObject:[setting valueForKey:@"menu_book_ride"] forKey:PREF_SETTING_MENU_BOOK_RIDE];
        [pref setObject:[setting valueForKey:@"menu_my_ride"] forKey:PREF_SETTING_MENU_MY_RIDE];
        [pref setObject:[setting valueForKey:@"menu_loyalty"] forKey:PREF_SETTING_MENU_LOYALTY];
        [pref setObject:[setting valueForKey:@"menu_referal"] forKey:PREF_SETTING_MENU_REFERAL];
        [pref setObject:[setting valueForKey:@"menu_payment"] forKey:PREF_SETTING_MENU_PAYMENT];
        [pref setObject:[setting valueForKey:@"menu_notification"] forKey:PREF_SETTING_MENU_NOTIFICATION];
        [pref setObject:[setting valueForKey:@"menu_help"] forKey:PREF_SETTING_MENU_HELP];
        [pref setObject:[setting valueForKey:@"menu_about"] forKey:PREF_SETTING_MENU_ABOUT];
        [pref setObject:[setting valueForKey:@"referal_title"] forKey:PREF_SETTING_REFERAL_TITLE];
        [pref setObject:[setting valueForKey:@"referal_description"] forKey:PREF_SETTING_REFERAL_DESCRIPTION];
        [pref setObject:[setting valueForKey:@"account_status"] forKey:PREF_SETTING_ACCOUNT_STATUS];
        [pref setObject:[setting valueForKey:@"ride_later_time_limit"] forKey:PREF_SETTING_RIDE_LATER_MINIMUM_TIME];
        [pref setObject:[setting valueForKey:@"get_request_timer"] forKey:PREF_SETTING_GET_REQUEST_TIMER];
        [pref setObject:[NSString stringWithFormat:@"%@", [setting valueForKey:@"last_four"]] forKey:PREF_SETTING_LAST_FOUR];
        [pref setObject:[setting valueForKey:@"card_url"] forKey:PREF_SETTING_CARD_URL];
        [pref setObject:[NSString stringWithFormat:@"%@", [setting valueForKey:@"payment_id"]] forKey:PREF_SETTING_CANCEL_PAYMENT_ID];
        
        [pref setObject:[setting valueForKey:@"screen_status"] forKey:PREF_SETTING_SCREEN_STATUS];
        if ([setting valueForKey:@"referral_code"]) {
            [pref setObject:[setting valueForKey:@"referral_code"] forKey:PREF_REFERRAL_CODE];
        }
        [pref setObject:[setting valueForKey:@"cust_referal_code"] forKey:PREF_CUST_REFERRAL_CODE];
        [pref setObject:[setting valueForKey:@"ride_later_time"] forKey:PREF_SETTING_RIDE_LATER_TIME];
        [pref setObject:[setting valueForKey:@"ride_later_days"] forKey:PREF_SETTING_RIDE_LATER_DAYS];
        [pref setObject:[setting valueForKey:@"ride_later_hours"] forKey:PREF_SETTING_RIDE_LATER_HOURS];
        [pref setObject:[setting valueForKey:@"ride_later_min"] forKey:PREF_SETTING_RIDE_LATER_MINUTES];
        
        
        NSString *new_req_id =[NSString stringWithFormat:@"%@",[setting valueForKey:@"request_id"]];
        ALog(@"settings request id in app delegate =%@ ",new_req_id);
        //        [pref setValue:new_req_id forKey:PREF_REQ_ID];
        NSString *balanceAmount = [setting valueForKey:@"cancellation_balance"];
        
        if (![new_req_id isEqualToString:@"-1"]) {  //current request id is not -1 that means show ride complete screen
            ALog(@"new_req_id in app delegate =%@ ",new_req_id);
            ALog(@"old_req_id in app delegate =%@ ", [pref valueForKey:PREF_SETTING_REQ_ID]);
            if (![new_req_id isEqualToString:[pref valueForKey:PREF_SETTING_REQ_ID]]) {
                
                if (rideComplete)
                {
                    [pref setBool:YES forKey:PREF_SETTING_REQUEST_ID_STATUS];
                    ALog(@"Showing ride complete because old_req_id = %@ and new_req_id = %@",[pref valueForKey:PREF_SETTING_REQ_ID], new_req_id);
                    //to avoid displaying multiple ride complete screens for single ride compare previous settings reqid and curret settings reqid. if both are same dont display the ride complete screen.
                    RideCompleteVC *rideComplete =[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"RideCompleteVC"];
                    rideComplete.lastWalkId = @"-1";
                    rideComplete.strRideCompleteRequestId=new_req_id;
                    [pref setValue:new_req_id forKey:PREF_SETTING_REQ_ID];
                    [currentViewController presentViewController:rideComplete animated:YES completion:nil];
                }
            }
        } else if(![balanceAmount isEqualToString:@"0.00"]) {  // unpaid amount is there so show outstanding payment screen
            if (paymentStatus) {
                ALog(@"Showing payment screen in appdelegate because ride complete is not available and old balance is %@ .", balanceAmount);
                OutStandingPaymentsViewController *paymentVC = [[OutStandingPaymentsViewController alloc] initWithNibName:@"OutStandingPaymentsViewController" bundle:nil];
                paymentVC.isPushed=NO;
                paymentVC.isPresentedFromSettings=YES;
                paymentVC.isPresentedFromBookingPage=YES;
                paymentVC.request_id=[NSString stringWithFormat:@"%@", [setting valueForKey:@"cancelled_requests"]];
                paymentVC.cancel_payment_id=[NSString stringWithFormat:@"%@", [setting valueForKey:@"payment_id"]];
                paymentVC.outStandingAmount =[NSString stringWithFormat:@"%@", balanceAmount];
                paymentVC.cardLastFourString= [NSString stringWithFormat:@"%@", [setting valueForKey:@"last_four"]];
                paymentVC.cardImageUrl= [NSString stringWithFormat:@"%@", [setting valueForKey:@"card_url"]];
                UINavigationController * navCntl = [[UINavigationController alloc] initWithRootViewController :paymentVC];
                [currentViewController presentViewController:navCntl animated:YES completion:nil];
            }
        } else {
            [pref setValue:new_req_id forKey:PREF_SETTING_REQ_ID];
        }
        [pref synchronize];
        
    } else {
        if (![[setting valueForKey:@"token_status"] boolValue]) {
            UIAlertView* logoutAlert=[[UIAlertView alloc] initWithTitle:@"Your session is expired. Login again." message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            logoutAlert.tag=2;
            [logoutAlert show];
        } else {
            UIAlertView* logoutAlert=[[UIAlertView alloc] initWithTitle:@"Invalid user" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            logoutAlert.tag=2;
            [logoutAlert show];
        }
        
    }
}

-(BOOL)settingsStatus :(NSMutableDictionary* )setting{
    return ([[setting valueForKey:@"account_status"] boolValue] && [[setting valueForKey:@"token_status"] boolValue] && [[setting valueForKey:@"lymo_device_status"] boolValue]);
}

+ (UIViewController*) topMostController
{
    UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
    
    while (topController.presentedViewController) {
        topController = topController.presentedViewController;
    }
    
    return topController;
}

#pragma mark - CheckForAppStoreUpdate

-(void)checkForUpdate{
    if (ActivateForceUpdate) {
        [updater showUpdateWithForce];
    }else{
        [updater showUpdateWithConfirmation];
    }
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
    
}

@end
