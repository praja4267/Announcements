//
//  lymoSingleton.m
//  
//
//  Created by ActiveMac03 on 14/11/15.
//
//

#import "lymoSingleton.h"

@implementation lymoSingleton

+ (lymoSingleton *)sharedInstance
{
    static lymoSingleton *sharedControllerInstance = nil;
    static dispatch_once_t predicate;
    
    dispatch_once(&predicate, ^{
        sharedControllerInstance = [[self alloc] init];
    });
    return sharedControllerInstance;
}

- (id) init
{
    self = [super init];
    if (self) {
        _arrCarDetails = [[NSMutableArray alloc] init];
        _arrCarTypeCount = [[NSMutableArray alloc] init];
        _arrCarTypeDetails = [[NSMutableArray alloc] init];
        _globaldictionary = [[NSMutableDictionary alloc] init];
        _arrCarCatID=[[NSMutableArray alloc] init];
    }
    return self;
}

- (void) reset
{
    _arrCarDetails = nil;
    _arrCarTypeCount = nil;
    _arrCarTypeDetails = nil;
    _arrCarCatID=nil;
}
@end
