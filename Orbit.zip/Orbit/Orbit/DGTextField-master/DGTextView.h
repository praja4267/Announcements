//
//  DGTextView.h
//
//  Created by Denis Chaschin on 24.07.13.
//  Copyright (c) 2013 Denis Chaschin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DGTextView : UITextView

@property (nonatomic, strong) UIColor *cursorColor;

@end
