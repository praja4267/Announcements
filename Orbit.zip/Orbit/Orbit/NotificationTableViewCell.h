//
//  NotificationTableViewCell.h
//  
//
//  Created by ActiveMac03 on 21/12/15.
//
//

#import <UIKit/UIKit.h>

@interface NotificationTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *dateLbl;
@property (weak, nonatomic) IBOutlet UILabel *titleLbl;
@property (weak, nonatomic) IBOutlet UILabel *messageLbl;

@property (strong, nonatomic) IBOutlet UITextView *messagetxt;

@end
