//
//  ChatDetailsTableViewCell.m
//  
//
//  Created by ActiveMac03 on 04/01/16.
//
//

#import "ChatDetailsTableViewCell.h"

@implementation ChatDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
