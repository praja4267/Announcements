//
//  phoneViewController.m
//
//
//  Created by ActiveMac03 on 26/11/15.
//
//

#import "phoneViewController.h"
#import "Constants.h"
#import "AppDelegate.h"
#import "AFNHelper.h"
#import "LoginRegisterViewController.h"

@interface phoneViewController (){
    NSString *phoneisocode;
    NSString *phoneCountryCode;
}
@end

@implementation phoneViewController

- (void)viewDidLoad {
    _phoneTxt.delegate=self;
    _phoneTxt.textAlignment = NSTextAlignmentLeft;
  
    phoneisocode=@"+44";
    phoneCountryCode=@"gb";
    [_countryCodeBtn setTitle:phoneisocode forState: UIControlStateNormal];
    [_countryCodeBtn setTitleColor:[UIColor orbitBlackColorhex7] forState: UIControlStateNormal];
    //KeyBoard done button
    UIToolbar *keyboardDoneButtonView = [[UIToolbar alloc] init];
    [keyboardDoneButtonView sizeToFit];
    UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                   style:UIBarButtonItemStylePlain target:self
                                                                  action:@selector(doneClicked:)];
    [doneButton setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor blackColor], NSForegroundColorAttributeName,nil]
                              forState:UIControlStateNormal];
    [keyboardDoneButtonView setItems:[NSArray arrayWithObjects:flexibleSpaceLeft,doneButton, nil]];
    _phoneTxt.inputAccessoryView = keyboardDoneButtonView;
    _phoneTxt.textColor=[UIColor orbitBlackColorhex7];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCountryCode:) name:@"PhoneNumberPage" object:nil];
    
    
    
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
    alreadyRegisteredAlert = [[CustomIOSAlertView alloc] init];
    [alreadyRegisteredAlert setButtonTitles:[NSMutableArray arrayWithObjects:@"Login", @"Add new number", nil]];
    [alreadyRegisteredAlert setDelegate:self];
    [alreadyRegisteredAlert setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [alreadyRegisteredAlert setUseMotionEffects:true];

    
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    
    [_backButton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

#pragma mark - Button actions
- (IBAction)phoneVerifyBtn:(id)sender
{
    [_phoneTxt resignFirstResponder];
    NSString *newPhoneString = [_phoneTxt.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    if([APPDELEGATE connected]){
        if([phoneisocode isEqual:@""]){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_COUNTRY_CODE view:self.view]];
            [customAlertView show];
        }else if(_phoneTxt.text.length<1){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_MOBILE_NUMBER view:self.view]];
            [customAlertView show];
        }else if(newPhoneString.length<10){
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_MOBILE_NUMBER view:self.view]];
            [customAlertView show];
        }else  {
            if ([phoneCountryCode isEqualToString:@"gb"]) {
                NSString *firstLetter = [newPhoneString substringToIndex:1];
                NSString *firstTwoLetters = [newPhoneString substringToIndex:2];
                if ([firstLetter isEqualToString:@"0"]) {
                    if(!([firstTwoLetters isEqualToString:@"07"] && newPhoneString.length == 11)) {
                        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                        [customAlertView show];
                        return;
                    }
                } else if([firstLetter isEqualToString:@"7"]) {
                    if (newPhoneString.length != 10) {
                        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                        [customAlertView show];
                        return;
                    }
                } else {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                    [customAlertView show];
                    return;
                }
            }
            
            NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
            
            
            NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
            [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
            [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
            [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
            //  [dictParam setValue:_phoneTxt.text forKey:PARAM_MOBILE_NUMBER];
            [dictParam setValue:newPhoneString forKey:PARAM_MOBILE_NUMBER];
            [dictParam setValue:phoneisocode forKey:PARAM_ISO_CODE];
            [dictParam setValue:phoneCountryCode forKey:PARAM_COUNTRY_CODE];
            [dictParam setValue:PARAM_SEND forKey:PARAM_TYPE];
            [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:NO];
            AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
            [afn getDataFromPath:FILE_OTP withParamData:dictParam withBlock:^(id response, NSError *error)
             {
                 ALog(@"Phonenumber Response ---> %@",response);
                 if (response == Nil){
                     if (error.code == -1005) {
                         [APPDELEGATE stopLoader:self.view];
                         [self phoneVerifyBtn:sender];
                     }else {
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [APPDELEGATE stopLoader:self.view];
                             [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                         });
                     }
                 }else if (response)
                 {
                     if([[response valueForKey:@"success"]boolValue])
                     {
                         //                         NSString *strLog=[NSString stringWithFormat:@"%@",[response valueForKey:@"message"]];
                         //       [APPDELEGATE showToastMessage:strLog];
                         [pref setObject:[response valueForKey:@"phone"] forKey:PREF_USER_PHONE];
                         [pref setValue:phoneisocode forKey:PREF_ISO_CODE];
                         [pref synchronize];
                         //   _phoneTxt.text=@"";
                         //   phoneisocode=@"";
                         dispatch_async(dispatch_get_main_queue(), ^{
                             [self performSegueWithIdentifier:STRING_SEGUE_PHONE_TO_OTP sender:self];
                         });
                     }
                     else{
                         if ([response valueForKey:@"already_registered"]) {
                             if ([[response valueForKey:@"already_registered"] boolValue]) {
                                 [alreadyRegisteredAlert setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                                 [alreadyRegisteredAlert show];
                             }else{
                                 [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                                 [customAlertView show];
                             }
                         }else{
                             [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                             [customAlertView show];
                         }
                         
                         
                     }
                     [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:NO ShowCancelPayment:NO FromViewController:self];;
                 }
                 [APPDELEGATE stopLoader:self.view];
             }];
        }
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)doneClicked:(id)sender
{
    [self.view endEditing:YES];
}
#pragma mark - Phone To Countrypicker

- (void) getCountryCode:(NSNotification *)notification {
    
     NSDictionary *codeInfo = notification.userInfo;
    phoneisocode=[codeInfo valueForKey:@"isocode"];
    phoneCountryCode=[codeInfo valueForKey:@"code"];
    ALog(@"country iso %@",phoneCountryCode);
    [_countryCodeBtn setTitle:[codeInfo valueForKey:@"isocode"] forState: UIControlStateNormal];
    
    if ([phoneCountryCode isEqualToString:@"gb"]) {
        if ((_phoneTxt.text.length == 1) && !(([_phoneTxt.text isEqualToString:@"0"]) || ([_phoneTxt.text isEqualToString:@"7"])) ) {
            [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
            _phoneTxt.text=@"";
            [customAlertView show];
        }else if (_phoneTxt.text.length == 2) {
            if([[_phoneTxt.text substringToIndex:1] isEqualToString:@"0"]) {
                if (![[_phoneTxt.text substringToIndex:2] isEqualToString:@"07"]) {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                    _phoneTxt.text=@"";
                    [customAlertView show];
                }
            }
        }else if (_phoneTxt.text.length > 2){
            if ([[_phoneTxt.text substringToIndex:1] isEqualToString:@"0"]) {
                if (![[_phoneTxt.text substringToIndex:2] isEqualToString:@"07"] || _phoneTxt.text.length > 12) {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                    _phoneTxt.text=@"";
                    [customAlertView show];
                }
            }else if ([[_phoneTxt.text substringToIndex:1] isEqualToString:@"7"]) {
                if (_phoneTxt.text.length > 11) {
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                    _phoneTxt.text=@"";
                    [customAlertView show];
                }
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                _phoneTxt.text=@"";
                [customAlertView show];
            }
        }
    }
}


- (IBAction)countryCode:(id)sender {
    
    [self performSegueWithIdentifier:STRING_SEGUE_PHONE_TO_COUNTRYPICKER sender:self];
}


#pragma mark - TextFeild Delegates

-(BOOL) textFieldShouldReturn:(UITextField *)textField {
    // Not found, so remove keyboard.
    [textField resignFirstResponder];
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    NSArray *components = [newString componentsSeparatedByCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
    NSString *decimalString = [components componentsJoinedByString:@""];
    //        ALog(@"decimal string is %@", decimalString);
    
        if ([phoneCountryCode isEqualToString:@"gb"]){
            if (decimalString.length == 1) {
                if(!([decimalString isEqualToString:@"0"] || [decimalString isEqualToString:@"7"])){
                    [textField resignFirstResponder];
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                    [customAlertView show];
                    return NO;
                }
            }else if (decimalString.length == 2){
                if([[decimalString substringToIndex:1] isEqualToString:@"0"]){
                    if(!([[decimalString substringToIndex:2] isEqualToString:@"07"])){
                        [textField resignFirstResponder];
                        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                        [customAlertView show];
                        textField.text=@"";
                        return NO;
                    }
                }
            }else if (decimalString.length > 2){
                if ([[decimalString substringToIndex:1] isEqualToString:@"7"]){
                    if (decimalString.length > 10) {
                        return NO;
                    }
                }if (decimalString.length > 11) {
                    return NO;
                }
            }
            
            /*
             
            else if (([[decimalString substringToIndex:1] isEqualToString:@"0"] || [[decimalString substringToIndex:1] isEqualToString:@"7"]) && decimalString.length < 12){
                if ([[decimalString substringToIndex:1] isEqualToString:@"0"]) {
                    if (![[decimalString substringToIndex:2] isEqualToString:@"07"]) {
                        [textField resignFirstResponder];
                        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_UK_MOBILE_NUMBER view:self.view]];
                        [customAlertView show];
                        textField.text=@"";
                        return NO;

                    }
                }else{
                    if (decimalString.length > 10) {
                        return NO;
                    }
                }
            }
             
             */
        }
    
    if ([decimalString  isEqual: @"00000"]) {
        [textField resignFirstResponder];
        [customAlertView setContainerView:[APPDELEGATE createDemoView:PLEASE_ENTER_VALID_MOBILE_NUMBER view:self.view]];
        [customAlertView show];
        return NO;
    }
    
    NSUInteger length = decimalString.length;
    
    NSUInteger index = 0;
    NSMutableString *formattedString = [NSMutableString string];
    if (range.location == 0 && [string isEqualToString:@" "]) {
        return NO;
    }
    
    if (length == 0 || (length > 11)) {
        textField.text = decimalString;
        return NO;
    }
    
    if (length - index > 5) {
        NSString *prefix = [decimalString substringWithRange:NSMakeRange(index, 5)];
        [formattedString appendFormat:@"%@ ",prefix];
        index += 5;
    }
    
//    if (length - index > 2) {
//        NSString *prefix1 = [decimalString substringWithRange:NSMakeRange(index, 2)];
//        [formattedString appendFormat:@"%@ ",prefix1];
//        index += 2;
//    }
//    
    
    NSString *remainder = [decimalString substringFromIndex:index];
    [formattedString appendString:remainder];
    textField.text = formattedString;
    return NO;
    
}

-(void)backButtonAction :(UIButton*) sender{
    [self.view endEditing:YES];
    [self openLoginScreen];
}

-(void)openLoginScreen{
    [APPDELEGATE.window setRootViewController:nil];
    [APPDELEGATE.window setRootViewController:[[UIStoryboard storyboardWithName:@"Main" bundle: nil] instantiateViewControllerWithIdentifier:@"LoginRegisterViewController"]];
    ALog(@"login type is = %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"login_type"]);
    if([[[NSUserDefaults standardUserDefaults] objectForKey:@"login_type"] isEqualToString:@"manual"]){
        ALog(@"login type inside if is = %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"login_type"]);
        [[NSNotificationCenter defaultCenter] postNotificationName: @"loginWithEmailProvided" object:nil];
    }else{
        ALog(@"login type inside else is = %@", [[NSUserDefaults standardUserDefaults] objectForKey:@"login_type"]);
    }
   
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    if (alertView == alreadyRegisteredAlert) {
        [alertView close];
        if (buttonIndex == 0) {
            [self openLoginScreen];
        }else{
            [_phoneTxt becomeFirstResponder];
        }
    }else{
        [alertView close];
    }
}

@end
