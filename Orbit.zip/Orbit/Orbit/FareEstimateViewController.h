//
//  FareEstimateViewController.h
//  
//
//  Created by ActiveMac03 on 25/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"
@protocol FareEstimateViewControllerDelegate <NSObject>
@optional
-(void) fareEstmateFavouriteselectedAddressDetails :(NSDictionary*)addressDict sender : (UIViewController*)cntl;
-(void) deselectOriginFromFareEstimate;
-(void) deselectDestimationFromFareEstimate;
-(void) resetTheBookingScreen;
@end

@interface FareEstimateViewController : UIViewController<CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

@property (nonatomic, weak) id<FareEstimateViewControllerDelegate> fareEstDelegate;

@property NSString *OriginLatitude,*OriginLongitude,*OriginText,*DestinationLatitude,*DestinationLongitude,*DestinationText,*screenStatus;
@property NSString *strForCurrentLatitude,*strForCurrentLongitude, *currentLatLongString;
//@property NSString *originImageName, *destinationImageName;
@property (strong, nonatomic)UIImage* favButtonOriginImage;
@property (strong, nonatomic)UIImage* favButtonDestinationImage;

@property (weak, nonatomic) IBOutlet UITextField *fareOriginTxt;
@property (weak, nonatomic) IBOutlet UITextField *fareDestinationTxt;
@property (weak, nonatomic) IBOutlet UIButton *fareOriginFavBtn;
@property (weak, nonatomic) IBOutlet UIButton *fareDestinationFavBtn;
@property (strong, nonatomic) IBOutlet UIView *fareOriginSearchBarVW;
@property (strong, nonatomic) IBOutlet UIView *fareDestinationSearchBarVW;


- (IBAction)fareOriginFavBtn:(id)sender;
- (IBAction)fareDestinationFavBtn:(id)sender;
- (IBAction)fareCalculateBtn:(id)sender;


@property (weak, nonatomic) IBOutlet UIButton *fareCalculateBtn;
@property (weak, nonatomic) IBOutlet UILabel *fareEstimateLbl;
@property (weak, nonatomic) IBOutlet UILabel *farePriceLbl;
@property (weak, nonatomic) IBOutlet UILabel *fareTimeLbl;
@property (weak, nonatomic) IBOutlet UILabel *fareTimeCostLbl;
@property (weak, nonatomic) IBOutlet UIButton *fareRateCardBtn;


- (IBAction)fareRateCardBtn:(id)sender;
- (IBAction)fareBackBtn:(id)sender;
- (IBAction)fareDoneBtn:(id)sender;

@end
