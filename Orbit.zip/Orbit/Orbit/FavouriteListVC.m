//
//  FavouriteListVC.m
//  
//
//  Created by Active Mac06 on 24/11/15.
//
//

#import "FavouriteListVC.h"
#import "FavouriteUpdatesVC.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"



@interface FavouriteListVC ()
{
    NSString *toFavListPass,*toFavLat,*toFavLong,*toFavAddress,*toFavTag,*toFavID;
    BOOL disableEdit;
    BOOL isEmpty;
    NSUserDefaults *pref;
    
}
@property (strong, nonatomic) IBOutlet UITableView *FavList_tbl;
@property (strong, nonatomic) NSMutableArray *FavPlaces;
@property (strong, nonatomic) NSMutableArray *DescFav;
@property (strong, nonatomic) NSMutableArray *FavPlacesID;
@property (strong, nonatomic) NSMutableArray *FavPlaceLat;
@property (strong, nonatomic) NSMutableArray *FavPlaceLong;
@property (strong, nonatomic) IBOutlet UIButton *Click_Add_btn;
- (IBAction)Click_Add:(id)sender;

@end

@implementation FavouriteListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    pref=[NSUserDefaults standardUserDefaults];
//    _addFavLabel.text=[pref objectForKey:PREF_ADD_FAV_TEXT];
//    _isDisplayAddFav=[[pref objectForKey:PREF_ADD_FAV_VIEW] boolValue];
    _FavList_tbl.tableFooterView = [UIView new];
    _FavList_tbl.tableHeaderView = [UIView new];
    _FavPlaces=[[NSMutableArray alloc]init];
    _DescFav=[[NSMutableArray alloc]init];
    _FavPlacesID=[[NSMutableArray alloc]init];
    _FavPlaceLat=[[NSMutableArray alloc]init];
    _FavPlaceLong=[[NSMutableArray alloc]init];

        isEmpty=NO;
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    if (self.view.frame.size.height > 600) {
        _imageTopSpaceConstraint.constant = (self.view.frame.size.height - 450) / 2;
    }else {
        _imageTopSpaceConstraint.constant = 50;
    }
       // default it was 58
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    ALog(@"the selected address id = %@",[pref objectForKey:PREF_FAV_ORIG_ADDRESS_ID]);
    
}
- (void)viewDidLayoutSubviews{
    _addFavLabel.text=_addFavText;
//    [pref objectForKey:PREF_ADD_FAV_TEXT];
    _isDisplayAddFav=[[pref objectForKey:PREF_ADD_FAV_VIEW] boolValue];
    
    ALog(@"Fav Text %@",[pref objectForKey:PREF_ADD_FAV_TEXT]);
        
    if(_isDisplayAddFav){
        _FavList_tbl.frame =CGRectMake(_FavList_tbl.frame.origin.x,
                                       _FavList_tbl.frame.origin.y,
                                       _FavList_tbl.frame.size.width,
                                       self.view.frame.size.height-300);
        
        _addFavView.hidden=NO;
        [_FavList_tbl setNeedsLayout];
        [_FavList_tbl setNeedsUpdateConstraints];
        
    }else{
        _FavList_tbl.frame =CGRectMake(_FavList_tbl.frame.origin.x,
                                       _FavList_tbl.frame.origin.y,
                                       _FavList_tbl.frame.size.width,
                                       _FavList_tbl.frame.size.height);
        _addFavView.hidden=YES;
    }
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [APPDELEGATE stopLoader:self.view];
    _favEmptyView.hidden=YES;
    _FavList_tbl.hidden=YES;

    [self getFavoritesData];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)getFavoritesData{
    if([APPDELEGATE connected]){
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:PARAM_GET forKey:PARAM_TYPE];
         [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_FAVOURITES withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getFavoritesData];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                    //                [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
                    //                [customAlertView show];
                }
            }else if (response){
                isEmpty=YES;
                if([[response valueForKey:@"success"]boolValue]){
                    
//                    ALog(@"pick up......%@",response);
                    if([[response valueForKey:@"success"]boolValue]){
                        [_FavPlaces removeAllObjects];
                        [_DescFav removeAllObjects];
                        [_FavPlacesID removeAllObjects];
                        [_FavPlaceLat removeAllObjects];
                        [_FavPlaceLong removeAllObjects];
                       NSMutableArray *favPlacesDetails=[response valueForKey:@"favorites"];
                        if(favPlacesDetails.count>0){
                        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:PREF_FAV_COUNT];
                        for(NSMutableDictionary *places in favPlacesDetails){
                            [_FavPlaces addObject:[places objectForKey:@"tag"]];
                            [_DescFav addObject:[places objectForKey:@"address"]];
                            [_FavPlacesID addObject:[places objectForKey:@"id"]];
                            [_FavPlaceLat addObject:[places objectForKey:@"latitude"]];
                            [_FavPlaceLong addObject:[places objectForKey:@"logtitude"]];
                        }
                        } else {
                            [[NSUserDefaults standardUserDefaults] setBool:NO forKey:PREF_FAV_COUNT];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [APPDELEGATE showAlertOnTopMostControllerWithText:NO_FAVOURITES];
                            });
                            
                        }
                        [[NSUserDefaults standardUserDefaults] setObject:_DescFav forKey:@"fav_places_array"];
                   }
                }else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
            }
             [_FavList_tbl reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if([_FavPlaces count]==0){
        return 1;
    }
    return _FavPlaces.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FavouriteListCell" forIndexPath:indexPath];
        // Configure the cell...
   
  //  cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"FavouriteListCell"];
   
    cell.textLabel.textColor = [UIColor blackColor];
     cell.detailTextLabel.textColor = [UIColor colorWithRed:0.6 green:0.6 blue:0.6 alpha:1];
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    cell.textLabel.font=[UIFont fontWithName:@"Dinpro" size:14];
    cell.imageView.image=[UIImage imageNamed:@"Fav_fill"];
    cell.detailTextLabel.font=[UIFont fontWithName:@"Dinpro" size:12];
    
    if([_FavPlaces count]>0){
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:PREF_FAV_COUNT];
        _favEmptyView.hidden=YES;
        _FavList_tbl.hidden=NO;
        cell.detailTextLabel.hidden=NO;
       NSString *places=[_FavPlaces objectAtIndex:indexPath.row];
        cell.textLabel.text=places;
        NSString *desc=[_DescFav objectAtIndex:indexPath.row];
        cell.detailTextLabel.text=desc;
        disableEdit=YES;
        cell.userInteractionEnabled=YES;
    }else{
        if (isEmpty) {
            _favEmptyView.hidden=NO;
        }
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:PREF_FAV_COUNT];
        _FavList_tbl.hidden=YES;
        disableEdit=NO;
        cell.textLabel.text = @"No More Favourites";
        cell.detailTextLabel.hidden=YES;
        cell.userInteractionEnabled=NO;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60; //or whatever value
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}

#pragma mark - UITableViewDataSource

// Swipe to delete.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [_FavPlaces removeObjectAtIndex:indexPath.row];
        [_FavList_tbl deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
}


-(NSArray *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(disableEdit){
        UITableViewRowAction *editAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"Edit" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){
            
            if ([APPDELEGATE connected]) {
                //insert your editAction here
                toFavListPass=@"Edit";
                toFavLat=[_FavPlaceLat objectAtIndex:indexPath.row];
                toFavLong=[_FavPlaceLong objectAtIndex:indexPath.row];
                toFavAddress=[_DescFav objectAtIndex:indexPath.row];
                toFavTag=[_FavPlaces objectAtIndex:indexPath.row];
                toFavID=[_FavPlacesID objectAtIndex:indexPath.row];
                
                [self performSegueWithIdentifier:STRING_SEGUE_TO_SAVE_UPDATE_SEGUE sender:self];
            }else {
                [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
                [customAlertView show];
            }
            
        }];
        editAction.backgroundColor = [UIColor colorWithRed:1 green:0.584 blue:0 alpha:1];
        
        UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:@"Delete"  handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){
            if([APPDELEGATE connected]){
                NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
                [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
                [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
                [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
                [dictParam setValue:PARAM_DELETE forKey:PARAM_TYPE];
                [dictParam setValue:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PARAM_FAVORITE_ID];
                //   [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
                AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
                [afn getDataFromPath:FILE_FAVOURITES withParamData:dictParam withBlock:^(id response, NSError *error){
                    if (response == Nil){
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [APPDELEGATE stopLoader:self.view];
                            [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                        });
//                        [customAlertView setContainerView:[APPDELEGATE createDemoView:UNABLE_TO_REACH view:self.view]];
//                        [customAlertView show];
                    }else if (response){
                        ALog(@"Favourites Delete Response %@",response);
                        if([[response valueForKey:@"success"]boolValue])
                        {
                            NSString *addressId = [_FavPlacesID objectAtIndex:indexPath.row];
                            
                            if ([self.favouritesDelegate conformsToProtocol:@protocol(FavouriteListVCDelegate)]) {
                                if ([_searchingTextField  isEqual: @"fav_origin"] || [_searchingTextField  isEqual: @"fav_dest"] ){
                                    
                                    if ([addressId isEqualToString: [pref valueForKey:PREF_FAV_ORIG_ADDRESS_ID]]) {
                                        if ([self.favouritesDelegate respondsToSelector:@selector(deselectOriginButton)]) {
                                            ALog(@"deselecting landing page origin" );
                                            [pref removeObjectForKey:PREF_FAV_ORIG_ADDRESS_ID];
                                            [self.favouritesDelegate deselectOriginButton];
                                        }
                                    }
                                    if ([addressId isEqualToString:[pref objectForKey:PREF_FAV_DEST_ADDRESS_ID]]) {
                                        if ([self.favouritesDelegate respondsToSelector:@selector(deselectDestinationButton)]) {
                                            [self.favouritesDelegate deselectDestinationButton];
                                            [pref removeObjectForKey:PREF_FAV_DEST_ADDRESS_ID];
                                            ALog(@"deselecting landing page destination" );
                                        }
                                    }
                                }else if ([_searchingTextField  isEqual: @"estimate_origin"] || [_searchingTextField  isEqual: @"estimate_dest"]) {
                                    
                                    if ([addressId isEqualToString:[pref objectForKey:PREF_FAREEST_ORIG_ADDRESS_ID]]) {
                                        if ([self.favouritesDelegate respondsToSelector:@selector(deselectOriginButton)]) {
                                            [self.favouritesDelegate deselectOriginButton];
                                            ALog(@"deselecting fare estiMATE page origin %@", [pref objectForKey:PREF_FAREEST_ORIG_ADDRESS_ID] );
                                            [pref removeObjectForKey:PREF_FAREEST_ORIG_ADDRESS_ID];
                                            
                                        }
                                    }
                                    if ([addressId isEqualToString:[pref objectForKey:PREF_FAREEST_DEST_ADDRESS_ID]]) {
                                        if ([self.favouritesDelegate respondsToSelector:@selector(deselectDestinationButton)]) {
                                            [self.favouritesDelegate deselectDestinationButton];
                                            ALog(@"deselecting fare estiMATE page destination %@", [pref objectForKey:PREF_FAREEST_DEST_ADDRESS_ID]);
                                              [pref removeObjectForKey:PREF_FAREEST_DEST_ADDRESS_ID];
                                        }
                                    }
                                }
                            }
                            ALog(@"deleted address id = %@", addressId );
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [APPDELEGATE showAlertOnTopMostControllerWithText:ADDRESS_DELETED_SUCCESSFULLY];
                            });
                            [_FavPlaces removeObjectAtIndex:indexPath.row];
                            [_FavPlacesID removeObjectAtIndex:indexPath.row];
                            [_DescFav removeObjectAtIndex:indexPath.row];
                            [_FavPlaceLat removeObjectAtIndex:indexPath.row];
                            [_FavPlaceLong removeObjectAtIndex:indexPath.row];
                            [[NSUserDefaults standardUserDefaults] setObject:_DescFav forKey:@"fav_places_array"];
                            if(indexPath.row==0){
                                [_FavList_tbl reloadData];
                            }else{
                                [_FavList_tbl deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
//                                [pref setBool:NO forKey:PREF_IS_FAV];
                            }
                             [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
                        }
                    }
                    [APPDELEGATE stopLoader:self.view];
                }];
            }else{
                [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
                [customAlertView show];
            }
        }];
        deleteAction.backgroundColor = [UIColor colorWithRed:1 green:0.231 blue:0.188 alpha:1];
        return @[deleteAction,editAction];
    }else{
        return nil;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([APPDELEGATE connected]) {
        if ([_searchingTextField  isEqual: @"fav_origin"]) {
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row]  forKey:PREF_FAV_ORIG_ADDRESS_ID];
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAREEST_ORIG_ADDRESS_ID];
        }else if ([_searchingTextField  isEqual: @"fav_dest"]) {
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAV_DEST_ADDRESS_ID];
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAREEST_DEST_ADDRESS_ID];
        }else if ([_searchingTextField  isEqual: @"estimate_origin"]) {
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAREEST_ORIG_ADDRESS_ID];
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row]  forKey:PREF_FAV_ORIG_ADDRESS_ID];
        }else if ([_searchingTextField  isEqual: @"estimate_dest"]) {
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAREEST_DEST_ADDRESS_ID];
            [pref setObject:[_FavPlacesID objectAtIndex:indexPath.row] forKey:PREF_FAV_DEST_ADDRESS_ID];
        }
        
        if([_strForCurrentPage isEqualToString:@"fareEstimate"]){
            //        NSDictionary* userInfo = @{@"text": [_DescFav objectAtIndex:indexPath.row],
            //                                   @"isFav":@"yes"};
            //         [[NSNotificationCenter defaultCenter] postNotificationName: @"fareEstimatePage" object:self userInfo:userInfo];
        }else{
            [pref removeObjectForKey:PREF_FARE_DESTINATIONTEXT];
            [pref setObject:[_DescFav objectAtIndex:indexPath.row] forKey:PREF_FAV_TEXT];
            [pref setObject:[_FavPlaceLat objectAtIndex:indexPath.row] forKey:PREF_FAV_LAT];
            [pref setObject:[_FavPlaceLong objectAtIndex:indexPath.row] forKey:PREF_FAV_LONG];
        }
        NSDictionary* AddressData = @{@"searchingField": _searchingTextField, @"selectedLat":[_FavPlaceLat objectAtIndex:indexPath.row], @"selectedLong":[_FavPlaceLong objectAtIndex:indexPath.row], @"selectedAddress" : [_DescFav objectAtIndex:indexPath.row], @"addressId":[_FavPlacesID objectAtIndex:indexPath.row]};
        if ([_searchingTextField isEqualToString:@"fav_origin"]) {
            if ([self.favouritesDelegate conformsToProtocol:@protocol(FavouriteListVCDelegate)]) {
                [self.favouritesDelegate reloadTheDataOfNewLocationWithLattitude:[_FavPlaceLat objectAtIndex:indexPath.row] andLongitude:[_FavPlaceLong objectAtIndex:indexPath.row]];
            }
        }
        
        [self doThisWithParams:AddressData onCompletion:^{
            [self.navigationController popViewControllerAnimated:YES];
        }];
    } else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}



#pragma mark - Button actions

- (IBAction)Click_Add:(id)sender
{
    if ([APPDELEGATE connected]) {
        toFavListPass=@"Add";
        [self performSegueWithIdentifier:STRING_SEGUE_TO_SAVE_UPDATE_SEGUE sender:self];
    }else {
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}

- (IBAction)addFavBackBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
//    [pref setBool:NO forKey: PREF_IS_FAV];  //added on 28062016
  // [[NSNotificationCenter defaultCenter] postNotificationName:@"abcdefgh" object:nil];
//    NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
//    [pref removeObjectForKey:PREF_FAV_DELETEFAV];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Segue Action

 //In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if([segue.identifier isEqualToString:STRING_SEGUE_TO_SAVE_UPDATE_SEGUE]) {
        FavouriteUpdatesVC *Favactivity = (FavouriteUpdatesVC *)segue.destinationViewController;
        if ([toFavListPass isEqualToString:@"Add"]) {
            Favactivity.toDisplay=toFavListPass;
            Favactivity.favLat=_addFavLat;
            Favactivity.favLong=_addFavLong;
            Favactivity.favAddress=_addFavText;
             ALog(@"The lat long sent from fav to save fav = %@, %@, %@", _addFavLat, _addFavLong, _addFavText);
        }else{
            Favactivity.toDisplay=toFavListPass;
            Favactivity.favLat=toFavLat;
            Favactivity.favLong=toFavLong;
            Favactivity.favAddress=toFavAddress;
            Favactivity.favTag=toFavTag;
            Favactivity.favID=toFavID;
             ALog(@"The lat long sent from fav to save fav = %@, %@", toFavLat, toFavLong);
        }
       
    }
}

-(void)doThisWithParams: (NSDictionary*)paramDictionary onCompletion:(void (^) (void))completion {
    if ([self.favouritesDelegate conformsToProtocol:@protocol(FavouriteListVCDelegate)]) {
        [self.favouritesDelegate selectedAddressDictionary:paramDictionary sender:self];
    }
    completion();
}

#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}

@end
