//
//  CancelTableViewCell.h
//  
//
//  Created by ActiveMac03 on 29/12/15.
//
//

#import <UIKit/UIKit.h>

@interface CancelTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cancelReasonCell;
@property (strong, nonatomic) IBOutlet UIImageView *cancelBGImgView;

@end
