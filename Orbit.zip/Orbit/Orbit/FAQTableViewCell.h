//
//  FAQTableViewCell.h
//  
//
//  Created by Active Mac06 on 11/12/15.
//
//

#import <UIKit/UIKit.h>

@interface FAQTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *Mark;
@property (strong, nonatomic) IBOutlet UILabel *lbl_points;


@property (strong, nonatomic) IBOutlet UITextView *txt_details;
@end
