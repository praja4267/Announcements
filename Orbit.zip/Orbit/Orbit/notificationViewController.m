//
//  notificationViewController.m
//  
//
//  Created by ActiveMac03 on 21/12/15.
//
//

#import "notificationViewController.h"
#import "Constants.h"
#import "AFNHelper.h"
#import "AppDelegate.h"
#import "NotificationTableViewCell.h"
#import "REFrostedViewController.h"


@interface notificationViewController (){
    NSMutableArray *notificationTitle,*notificationMessage,*notificationDate;
    UIRefreshControl *refreshControl;
    
    
}
@end

@implementation notificationViewController

- (void)viewDidLoad {
       [super viewDidLoad];
    [APPDELEGATE startLoader:self.view giveSpaceFornavigationBar:YES];
    _notificationTableView.tableFooterView = [UIView new];
    _noNotificationsView.hidden=YES;
    notificationDate=[[NSMutableArray alloc]init];
    notificationTitle=[[NSMutableArray alloc]init];
    notificationMessage=[[NSMutableArray alloc]init];
    
    [self getNotificationData];
    
    refreshControl = [[UIRefreshControl alloc] init];
    refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:@"Pull to Refresh"];
    refreshControl.tintColor=[UIColor orbitYellowColor];
    [refreshControl addTarget:self action:@selector(refreshTable) forControlEvents:UIControlEventValueChanged];
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.notificationTableView;
    tableViewController.refreshControl = refreshControl;
 
    
    //Alert view
    customAlertView = [[CustomIOSAlertView alloc] init];
    [customAlertView setButtonTitles:[NSMutableArray arrayWithObjects:@"OK", nil]];
    [customAlertView setDelegate:self];
    [customAlertView setOnButtonTouchUpInside:^(CustomIOSAlertView *alertView, int buttonIndex) {
        ALog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, (int)[alertView tag]);
        [alertView close];
    }];
    [customAlertView setUseMotionEffects:true];
    
     _notificationTableView.estimatedRowHeight = 126.0 ;
     _notificationTableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [customAlertView close];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
   [self getNotificationData];
    
}

#pragma mark - Notificatoin API

- (void)getNotificationData{
    if([APPDELEGATE connected]){
        NSUserDefaults *pref=[NSUserDefaults standardUserDefaults];
        NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
        [dictParam setValue:[pref objectForKey:PREF_USER_ID] forKey:PARAM_ID];
        [dictParam setValue:[pref objectForKey:PREF_USER_TOKEN] forKey:PARAM_TOKEN];
        [dictParam setValue:[pref objectForKey:PREF_LYMO_DEVICE_ID] forKey:PARAM_LYMO_DEVICE_ID];
        [dictParam setValue:@"ios" forKey:PARAM_DEVICE_TYPE];
        AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:POST_METHOD];
        [afn getDataFromPath:FILE_NOTIFICATIONS withParamData:dictParam withBlock:^(id response, NSError *error){
            if (response == Nil){
                if (error.code == -1005) {
                    [APPDELEGATE stopLoader:self.view];
                    [self getNotificationData];
                    
                }else {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [APPDELEGATE stopLoader:self.view];
                        [APPDELEGATE showAlertOnTopMostControllerWithText:[APPDELEGATE getTheErrorMessageFromError:error]];
                    });
                }
            }else if (response){
                if([[response valueForKey:@"success"]boolValue]){
                    NSMutableArray *notifications=[response valueForKey:@"notifications"];
                    if(notifications.count>0){
                        [notificationTitle removeAllObjects];
                        [notificationDate removeAllObjects];
                        [notificationMessage removeAllObjects];
                        for(NSMutableDictionary *info in notifications){
                            [notificationTitle addObject:[info valueForKey:@"title"]];
                            [notificationMessage addObject:[info valueForKey:@"message"]];
                            [notificationDate addObject:[info valueForKey:@"sent_date"]];
                        }
                    } else {
                        _noNotificationsView.hidden=NO;
                        _notificationTableView.hidden=YES;
                    }
                }
                else{
                    [customAlertView setContainerView:[APPDELEGATE createDemoView:[response valueForKey:@"error"] view:self.view]];
                    [customAlertView show];
                }
                 [APPDELEGATE customerSetting:[response valueForKey:@"customer_setting"] ShowRideComplete:YES ShowCancelPayment:YES FromViewController:self];;
            }
            [_notificationTableView reloadData];
            [APPDELEGATE stopLoader:self.view];
        }];
    }else{
        [customAlertView setContainerView:[APPDELEGATE createDemoView:NO_INTERNET view:self.view]];
        [customAlertView show];
    }
}


#pragma mark - TableView Datasource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (notificationTitle.count==0) {
        return 0;
    }
    return notificationTitle.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NotificationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"notificationCell" forIndexPath:indexPath];
    if (cell == nil) {
        cell=[[NotificationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"notificationCell"];
    }
    if(notificationTitle.count>0){
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        cell.titleLbl.text=[notificationTitle objectAtIndex:indexPath.row];
        cell.dateLbl.text=[notificationDate objectAtIndex:indexPath.row];
        cell.messageLbl.text=[notificationMessage objectAtIndex:indexPath.row];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//
//    static NotificationTableViewCell *cell = nil;
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        cell = (NotificationTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
//    });
    
//    
//    if(IS_OS_8_OR_LATER>8.0){
//      return UITableViewAutomaticDimension;
//    }
//    
    return UITableViewAutomaticDimension;

}


//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    NotificationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"notificationCell" forIndexPath:indexPath];
//    if (cell == nil) {
//        cell=[[NotificationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"notificationCell"];
//    }
//
//    UILabel  * label = [[UILabel alloc] initWithFrame:CGRectMake(8, 50, cell.frame.size.width, 9999)];
//    label.numberOfLines=0;
//    label.font = [UIFont fontWithName:@"dinpro" size:15];
//    label.text = [notificationMessage objectAtIndex:indexPath.row];
//
//    CGSize maximumLabelSize = CGSizeMake(cell.frame.size.width, 9999);
//    CGSize expectedSize = [label sizeThatFits:maximumLabelSize];
//    return expectedSize.height;
//}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if(IS_OS_8_OR_LATER>8.0){
//        return UITableViewAutomaticDimension;
//    }
//    return true;
    
    return UITableViewAutomaticDimension;

}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}


#pragma mark - refresh table view

- (void)refreshTable{
    [self getNotificationData];
    [self performSelector:@selector(stopRefresh) withObject:nil afterDelay:2.5];
}

- (void)stopRefresh
{
    [refreshControl endRefreshing];
}

#pragma mark - Button Actions

- (IBAction)menuBtn:(id)sender {
    [APPDELEGATE stopLoader:self.view];
    [self.view endEditing:YES];
    [self.frostedViewController.view endEditing:YES];
    [self.frostedViewController presentMenuViewController];
}
#pragma mark - Custom Popup Delegate

- (void)customIOS7dialogButtonTouchUpInside: (CustomIOSAlertView *)alertView clickedButtonAtIndex: (NSInteger)buttonIndex
{
    ALog(@"Delegate: Button at position %d is clicked on alertView %d.", (int)buttonIndex, (int)[alertView tag]);
    [alertView close];
}
@end
/*
 
 To obtain the OAuth2 token this is the curl:
 
 curl -X POST -vu clientapp:123456 http://dev-api.nauroo2.com/oauth/token -H "Accept: application/json" -d "password=hola&username=52-5541302206&grant_type=password&scope=read%20write&client_secret=123456&client_id=clientapp”
 
 The current token is : 7e14f71e-c04e-4ba7-a2dc-3f9305ab1d65
 
 To obtain the search result they should do a POST Request to:
 
 http://dev-api.nauroo2.com/userClient/search with a header:
 
 Authorization: Bearer *OAuth2 token* example: Authorization: Bearer 7e14f71e-c04e-4ba7-a2dc-3f9305ab1d65
 
 With the following Json Body:
 
 { "page" : 1, "startDate" : "2016-07-01 19:00", "endDate" : "2016-07-01 23:00", "address" : { "street" : "Calle San Pedro 91312", "number" : 0, "city" : "Mexico City", "country" : "Mexico", "zipcode" : "04600", "longitude" : -99.157178, "addresTypeIdAddressType" : 1, "latitude" : 19.314252, "state" : "DF" } }
 
 
 */
