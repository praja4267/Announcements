//
//  countrySearchViewController.m
//
//
//  Created by ActiveMac03 on 29/12/15.
//
//

#import "countrySearchViewController.h"
#import "countryPickerTableViewCell.h"
#import "Constants.h"

@interface countrySearchViewController ()
{
    
    NSMutableDictionary *FilteredData;
    NSMutableDictionary *SourceData;
}

@end

@implementation countrySearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _countryTableView.tableFooterView = [UIView new];
    
    NSArray *CountryCode=[[NSArray alloc]init];
    
    FilteredData=[[NSMutableDictionary alloc]init];
    SourceData=[[NSMutableDictionary alloc]init];
    
    
    // Coountry Code Picker
//    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"CountryCodes" ofType:@"json"];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"country" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    CountryCode = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
//    NSLog(@"Country.... %@",CountryCode);
    int i=0;
    
    
    for(NSMutableArray *CountryData in CountryCode){
        
        [SourceData setObject:@[[CountryData objectAtIndex:0],[CountryData objectAtIndex:2],[CountryData objectAtIndex:1]] forKey:[NSString stringWithFormat:@"%ld",(long)i]];
        
        
        //        [SourceData setObject:@[[CountryData valueForKey:@"name"],[CountryData valueForKey:@"dial_code"],[CountryData valueForKey:@"code"]] forKey:[NSString stringWithFormat:@"%ld",(long)i]];
        
//        NSLog(@"Country Data.... %@",SourceData);
        i++;
    }
    
    /*
    for(NSMutableDictionary *CountryData in CountryCode){
        [SourceData setObject:@[[CountryData valueForKey:@"name"],[CountryData valueForKey:@"dial_code"],[CountryData valueForKey:@"code"]] forKey:[NSString stringWithFormat:@"%ld",(long)i]];
        
//        ALog(@"Country Data.... %@",SourceData);
        i++;
    }
     
     */
    [_countryTableView reloadData];
    
}

#pragma mark - TableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(tableView == [[self searchDisplayController] searchResultsTableView])
    {
        return [FilteredData count];
    }
    return [SourceData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"CountryCodeCell";
    // Configure the cell...
    countryPickerTableViewCell *cell =(countryPickerTableViewCell *) [_countryTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell=[[countryPickerTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    
    if(tableView == [[self searchDisplayController] searchResultsTableView])
    {
        cell.countryNameLbl.text=[[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:0];
        cell.countryCodeLbl.text=[[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1];
    }
    else
    {
        if(SourceData.count > 0){
            
            cell.countryNameLbl.text=[[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:0];
            cell.countryCodeLbl.text=[[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1];
        }
    }
    return cell;
}


# pragma -mark TAbleViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
    if ([_screenStatus isEqualToString:@"editProfile"]) {
        if(tableView == [[self searchDisplayController] searchResultsTableView])
        {
           NSDictionary* userInfo = @{@"isocode": [[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1],
                                     @"code":[[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:2]};
           
            [[NSNotificationCenter defaultCenter] postNotificationName: @"EditProfilePage" object:nil userInfo:userInfo];
        }
        else{
            NSDictionary* userInfo = @{@"isocode": [[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1],
                                       @"code":[[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:2]};

           [[NSNotificationCenter defaultCenter] postNotificationName: @"EditProfilePage" object:nil userInfo:userInfo];
        }

    }else{
        if(tableView == [[self searchDisplayController] searchResultsTableView])
        {
            NSDictionary* userInfo = @{@"isocode": [[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1],
                                       @"code":[[FilteredData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:2]};

            [[NSNotificationCenter defaultCenter] postNotificationName: @"PhoneNumberPage" object:nil userInfo:userInfo];
        }
        else{
            NSDictionary* userInfo = @{@"isocode": [[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:1],
                                       @"code":[[SourceData valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] objectAtIndex:2]};
            
            [[NSNotificationCenter defaultCenter] postNotificationName: @"PhoneNumberPage" object:nil userInfo:userInfo];
        }
    }
    [self dismissViewControllerAnimated:YES completion:nil];
    
    
}
#pragma search delegate methods

-(void) filterForSearchText:(NSString *) text scope:(NSString *) scope
{
    [FilteredData removeAllObjects];
    [SourceData enumerateKeysAndObjectsUsingBlock:^(id key, id object, BOOL *stop) {
        NSString* abbr= [object objectAtIndex:0];
        NSString* abbr1 = [object objectAtIndex:1];
        if([abbr rangeOfString:text options:NSCaseInsensitiveSearch].location==0) {
            [FilteredData setObject:object forKey:[NSString stringWithFormat:@"%ld",(long)[FilteredData count]]];
        }
//        ([abbr1 rangeOfString:text options:NSCaseInsensitiveSearch].location==1) in + is there before countrycode.
        if(([abbr1 rangeOfString:text options:NSCaseInsensitiveSearch].location==0) || ([abbr1 rangeOfString:text options:NSCaseInsensitiveSearch].location==1)){
            [FilteredData setObject:object forKey:[NSString stringWithFormat:@"%ld",(long)[FilteredData count]]];
        }
    }];
    
}

-(BOOL) searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchScope:(NSInteger)searchOption
{
    [self filterForSearchText:self.searchDisplayController.searchBar.text scope:
     [[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:searchOption]];
    return YES;
}

-(BOOL) searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterForSearchText:searchString scope:[[[[self searchDisplayController] searchBar] scopeButtonTitles] objectAtIndex:[[[self searchDisplayController] searchBar] selectedScopeButtonIndex] ]];
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
    searchBar.showsScopeBar = NO;
    [searchBar sizeToFit];
    
    [searchBar setShowsCancelButton:NO animated:YES];
    return YES;
}
- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar {
    searchBar.showsScopeBar = NO;
    [searchBar sizeToFit];
    
    [searchBar setShowsCancelButton:NO animated:YES];
    
    return YES;
}


//- (void)searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
//{
//    controller.searchBar.showsCancelButton = NO;
//}



- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.separatorInset = UIEdgeInsetsZero;
    [cell setLayoutMargins:UIEdgeInsetsZero];
    if(IS_OS_8_OR_LATER){
        cell.preservesSuperviewLayoutMargins = false;
    }
}

- (IBAction)Menu:(id)sender {
    [self.view endEditing:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end
