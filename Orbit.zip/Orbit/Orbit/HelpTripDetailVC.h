//
//  HelpTripDetailVC.h
//  
//
//  Created by Active Mac06 on 22/12/15.
//
//

#import <UIKit/UIKit.h>
#import "TPKeyboardAvoidingScrollView.h"
#import "TPFloatRatingView.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "CustomIOSAlertView.h"

@interface HelpTripDetailVC : UIViewController <UITableViewDataSource,UITableViewDelegate,TPFloatRatingViewDelegate,UITextViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

@property NSString *request_id,*strForCurrentPage;

@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *HelpTripScrlVW;
@property (strong, nonatomic) IBOutlet UIView *HelpData;
@property (strong, nonatomic) IBOutlet UILabel *SelectIssueLbl;
@property (strong, nonatomic) IBOutlet UILabel *PlaceholderLbl;
@property (strong, nonatomic) IBOutlet UIView *TextVW_View;

// Back
@property (strong, nonatomic) IBOutlet UIButton *BackBtn;
- (IBAction)Back:(id)sender;

// Receipt
@property (strong, nonatomic) IBOutlet UIButton *ReceiptBtn;
- (IBAction)Receipt:(id)sender;


// Details Status Header
@property (strong, nonatomic) IBOutlet UILabel *classLbl;
@property (strong, nonatomic) IBOutlet UILabel *IDLbl;
@property (strong, nonatomic) IBOutlet UILabel *DateLbl;
@property (strong, nonatomic) IBOutlet UILabel *TimeLbl;
@property (strong, nonatomic) IBOutlet UIImageView *mapImageView;

// Driver Details

@property (strong, nonatomic) IBOutlet UIImageView *DriverPic;
@property (strong, nonatomic) IBOutlet UILabel *DriverNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *CarNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *CarNoLbl;

// Trip Total
@property (strong, nonatomic) IBOutlet UILabel *TotalLbl;
@property (strong, nonatomic) IBOutlet TPFloatRatingView *StarRatingView;

// Origin
@property (strong, nonatomic) IBOutlet UILabel *OriginLbl;
@property (strong, nonatomic) IBOutlet UILabel *OriginDateTimeLbl;

// Destination
@property (strong, nonatomic) IBOutlet UILabel *DestinationLbl;
@property (strong, nonatomic) IBOutlet UILabel *destDateTimeLbl;

// Drop Down
@property (strong, nonatomic) IBOutlet UIView *DropDownHelp;
@property (strong, nonatomic) IBOutlet UITextView *CommentTxtView;

// Submit Action
@property (strong, nonatomic) IBOutlet UIButton *Submit;
- (IBAction)Submit:(id)sender;

// Table View Issues
@property (strong, nonatomic) IBOutlet UIView *HelpDropDownContentView;

@property (strong, nonatomic) IBOutlet UITableView *HelpTableVW;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *HelpTableVWHeightConstraint;

// Chat Table View
@property (strong, nonatomic) IBOutlet UITableView *ChatTableView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *ChatTableViewHeightConstraint;

@property (strong, nonatomic) IBOutlet UIView *LastView;

@property (strong, nonatomic) IBOutlet UIImageView *dropDownImageView;


// Invoice
@property (strong, nonatomic) IBOutlet UIView *inVoiceBigView;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *inVoiceKBAvoidingScrollView;
@property (strong, nonatomic) IBOutlet UIView *inVoiceInnerContainerView;
@property (strong, nonatomic) IBOutlet UIView *inVoicePopUpView;
@property (strong, nonatomic) IBOutlet UILabel *invoiceTitleLabel;
@property (strong, nonatomic) IBOutlet UITextField *invoiceEmailTextField;
@property (strong, nonatomic) IBOutlet UIButton *invoiceSendButton;
@property (strong, nonatomic) IBOutlet UIButton *invoiceCancelButton;






@end
