//
//  LandingPageViewController.h
//  lymo
//
//  Created by Active Mac06 on 02/11/15.
//  Copyright © 2015 techActive. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
//#import <MapKit/MapKit.h>
#import "SliderViewController.h"
#import "SearchViewController.h"
#import "TPFloatRatingView.h"
#import "CustomIOSAlertView.h"
#import "TPKeyboardAvoidingScrollView.h"
#import <CoreLocation/CoreLocation.h>

@interface LandingPageViewController : UIViewController<MKMapViewDelegate,UITextFieldDelegate,SliderViewControllerDelegate,CLLocationManagerDelegate,TPFloatRatingViewDelegate,CustomIOSAlertViewDelegate>{
    CustomIOSAlertView *customAlertView,*customAlertViewForLocation;
}
@property BOOL isFav;
@property NSString *FavAddress;
@property NSString *FavLatitude;
@property NSString *FavLongitude;

@property NSString *requestID;
@property BOOL currentRide;


//@property (strong, nonatomic) IBOutlet MKMapView *mapView;

@property (weak, nonatomic) IBOutlet UIView *navBackView;
@property (weak, nonatomic) IBOutlet UIView *viewGoogleMap;
@property (weak, nonatomic) IBOutlet UIImageView *mapPin;
@property (strong, nonatomic) IBOutlet UIView *viewForSideMenuOnMapView;

#pragma mark - Booking page

@property (weak, nonatomic) IBOutlet UIButton *bookRideNowBtn;
@property (weak, nonatomic) IBOutlet UIButton *bookRideLaterBtn;

@property (weak, nonatomic) IBOutlet UIView *navigationView;
@property (weak, nonatomic) IBOutlet UIView *rateCardView;
@property (weak, nonatomic) IBOutlet UIView *rateCardSubView;
@property (weak, nonatomic) IBOutlet UIView *rideNowLaterBtnView;
@property (weak, nonatomic) IBOutlet UIImageView *lymo_Logo;
@property (weak, nonatomic) IBOutlet UIButton *navMenuBtn;
- (IBAction)navMenuBtn:(id)sender;
//- (IBAction)favBtn:(id)sender;
- (IBAction)bookRideLaterBtn:(id)sender;
- (IBAction)bookRideNowBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *bookLocationBtn;
@property (weak, nonatomic) IBOutlet UIButton *startRideLocationBtn;
- (IBAction)bookLocationBtn:(id)sender;



#pragma mark -Nav View page
@property (strong, nonatomic) IBOutlet UIView *OriginTextFieldAndFavButtonHolder;
@property (strong, nonatomic) IBOutlet UIView *originTextFieldHolder;

//@property (strong, nonatomic) IBOutlet UIView *searchBarHolder;
@property (weak, nonatomic) IBOutlet UIImageView *navOriginSearchBtn;
@property (strong, nonatomic) IBOutlet UITextField *originTextFiled;

//@property (weak, nonatomic) IBOutlet UITextField *searchBar;
@property (weak, nonatomic) IBOutlet UIButton *navOriginFavBtn;
@property (weak, nonatomic) IBOutlet UILabel *lymoArrivingLbl;
@property (weak, nonatomic) IBOutlet UILabel *confromRideLbl;
- (IBAction)navOriginFavBtn:(id)sender;

#pragma mark - Destination View
@property (strong, nonatomic) IBOutlet UIView *destinationTextFieldHolder;

//@property (strong, nonatomic) IBOutlet UIView *destinationSerachBar;
@property (weak, nonatomic) IBOutlet UIView *destinationView;
@property (strong, nonatomic) IBOutlet UITextField *destinationTextFiled;

//@property (weak, nonatomic) IBOutlet UITextField *destinationSearchTxt;
@property (weak, nonatomic) IBOutlet UIImageView *destinationSearchBtn;
@property (weak, nonatomic) IBOutlet UIButton *destinationFavBtn;
- (IBAction)destinationFavBtn:(id)sender;


#pragma mark -RideNow page

@property (weak, nonatomic) IBOutlet UIView *rideNowBigView;
- (IBAction)RideNowBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *rideNowButtonInBigView;
@property (weak, nonatomic) IBOutlet UIView *RideNowBtnView;
@property (weak, nonatomic) IBOutlet UIView *RideNowView;
@property (weak, nonatomic) IBOutlet UIImageView *rideNowIcon;
@property (weak, nonatomic) IBOutlet UILabel *rideNowCarCat;  //changing the name as type name like bently on 22062016
@property (weak, nonatomic) IBOutlet UILabel *rideNowFare;
@property (weak, nonatomic) IBOutlet UILabel *rideNowTime;
@property (weak, nonatomic) IBOutlet UIView *rideNowPromoView;
@property (weak, nonatomic) IBOutlet UILabel *rideNowCouponLbl;
@property (weak, nonatomic) IBOutlet UIImageView *rideNowCouponIcon;
@property (weak, nonatomic) IBOutlet UIView *rideNowFareEstimateView;
@property (weak, nonatomic) IBOutlet UIView *rideNowPaymentView;
@property (weak, nonatomic) IBOutlet UILabel *rideNowPaymentCardName;
@property (weak, nonatomic) IBOutlet UIImageView *rideNowPaymentCardIcon;


#pragma mark -RideLater page

@property (weak, nonatomic) IBOutlet UIView *rideLaterBigView;
- (IBAction)RideLaterBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *RideLaterBtnView;
@property (weak, nonatomic) IBOutlet UIView *RideLaterView;
@property (weak, nonatomic) IBOutlet UIImageView *rideLaterIcon;
@property (weak, nonatomic) IBOutlet UILabel *rideLaterCarCat;
@property (weak, nonatomic) IBOutlet UILabel *rideLaterFare;
@property (strong, nonatomic) IBOutlet UILabel *rideLaterPickupAtLabel;
@property (weak, nonatomic) IBOutlet UILabel *rideLaterDateLabel;
@property (weak, nonatomic) IBOutlet UIView *rideLaterPaymentView;
@property (weak, nonatomic) IBOutlet UIView *rideLaterPromoView;
@property (weak, nonatomic) IBOutlet UIView *rideLaterFareEstimateView;
@property (weak, nonatomic) IBOutlet UILabel *rideLaterCouponLbl;
@property (weak, nonatomic) IBOutlet UILabel *rideLaterPaymentCardName;
@property (weak, nonatomic) IBOutlet UIImageView *rideLaterPaymentCardIcon;



#pragma mark -Ride Later Popup view
@property (strong, nonatomic) IBOutlet UIView *rideLaterPopupBigView;
@property (strong, nonatomic) IBOutlet UIView *rideLaterPopupView;
- (IBAction)rideLaterPopupOKBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *rideLaterPopupContent;


#pragma mark - RateCard View

@property (weak, nonatomic) IBOutlet UILabel *rateCardFirstPrice;
@property (weak, nonatomic) IBOutlet UILabel *rateCardSecondPrice;
@property (weak, nonatomic) IBOutlet UILabel *rateCardThirdPrice;
//@property (weak, nonatomic) IBOutlet UILabel *rateCardFirstKMS;
//@property (weak, nonatomic) IBOutlet UILabel *rateCardSecondKMS;
@property (weak, nonatomic) IBOutlet UILabel *rateCardCarCatLbl;
@property (strong, nonatomic) IBOutlet UILabel *rateCardFirstCurrency;
@property (strong, nonatomic) IBOutlet UILabel *rateCardSecondCurrency;
@property (strong, nonatomic) IBOutlet UILabel *rateCardThirdCurrency;
@property (strong, nonatomic) IBOutlet UILabel *rateCardCarTypes;
//@property (strong, nonatomic) IBOutlet UILabel *rateCardThirdKMS;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *minimumFareViewHeightConstraint;
@property (strong, nonatomic) IBOutlet UILabel *minimumFareLabel;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *baseFareViewHeightConstraint;
@property (strong, nonatomic) IBOutlet UILabel *baseFareLabel;
@property (strong, nonatomic) IBOutlet UILabel *surChargeLabel;


#pragma mark - StartRide View

@property (weak, nonatomic) IBOutlet UIView *startRideView;
@property (weak, nonatomic) IBOutlet UIImageView *startRideIcon;
@property (weak, nonatomic) IBOutlet UILabel *startRideName;
@property (weak, nonatomic) IBOutlet UILabel *startRideCarType;
@property (weak, nonatomic) IBOutlet UILabel *startRideCarNumber;
@property (weak, nonatomic) IBOutlet TPFloatRatingView *startRideRatingView;
@property (weak, nonatomic) IBOutlet UILabel *startRideRating;

#pragma mark - StartRide Detail View

@property (weak, nonatomic) IBOutlet UIView *startRideDetailBigView;
@property (weak, nonatomic) IBOutlet UIView *startRideDetailView;
@property (weak, nonatomic) IBOutlet UIImageView *startRideDetailIcon;
@property (weak, nonatomic) IBOutlet UILabel *startRideDetailName;
@property (weak, nonatomic) IBOutlet UILabel *startRideDetailCarType;
@property (weak, nonatomic) IBOutlet UILabel *startRideDetailCarNumber;
@property (weak, nonatomic) IBOutlet TPFloatRatingView *startRideDetailRatingView;
@property (weak, nonatomic) IBOutlet UILabel *startRideDetailRating;
@property (weak, nonatomic) IBOutlet UIImageView *startRideCancelIcon;
@property (weak, nonatomic) IBOutlet UILabel *startRideCancelLbl;

@property (weak, nonatomic) IBOutlet UIView *startRideDetailCallDriverView;
@property (weak, nonatomic) IBOutlet UIView *startRideDetailCancelView;
@property (weak, nonatomic) IBOutlet UIView *startRideDetailShareView;

#pragma mark - Cancel Alert view

@property (weak, nonatomic) IBOutlet UIView *cancelAlertBigView;
@property (weak, nonatomic) IBOutlet UIView *cancelAlertView;
- (IBAction)cancelAlertYesBtn:(id)sender;
- (IBAction)cancelAlertNoBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *cancelTableView;
@property (weak, nonatomic) IBOutlet UIButton *cancelAlertYesBtn;


#pragma mark - Driver call view

@property (weak, nonatomic) IBOutlet UIView *driverCallBigView;
@property (weak, nonatomic) IBOutlet UILabel *driverCallPhoneLbl;
- (IBAction)driverCallBtn:(id)sender;
- (IBAction)driverCallCancelBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *driverCallView;

#pragma mark - Pulse View

@property (weak, nonatomic) IBOutlet UIView *pulseView;
@property (strong, nonatomic) IBOutlet UIButton *pulseView_cancelButton;

- (IBAction)pulseViewCancelBtn:(id)sender;

#pragma mark - promo code View
@property (weak, nonatomic) IBOutlet UIView *promoCodeBigView;
@property (strong, nonatomic) IBOutlet TPKeyboardAvoidingScrollView *promocodeKeyBoardAvoidingScrollView;
@property (strong, nonatomic) IBOutlet UIView *promocodeContainerView;

@property (weak, nonatomic) IBOutlet UIView *promoCodeView;
@property (weak, nonatomic) IBOutlet UITextField *promoCodeTxt;
- (IBAction)promoCodeCancelBtn:(id)sender;
- (IBAction)promoCodeApplyBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *promoCodeApplyBtn;



#pragma mark - Surge View
@property (strong, nonatomic) IBOutlet UIView *surgeBigView;
@property (strong, nonatomic) IBOutlet UIView *surgeView;
@property (strong, nonatomic) IBOutlet UILabel *surgeLbl;
@property (strong, nonatomic) IBOutlet UILabel *surgeDescriptionLabel;

- (IBAction)surgeCancelBtn:(id)sender;
- (IBAction)surgeConfirmBtn:(id)sender;

#pragma mark - Alert message

//@property (weak, nonatomic) IBOutlet UIView *alertMessageView;
@property (strong, nonatomic) IBOutlet UIView *noCarsAvailableHolderView;
//@property (weak, nonatomic) IBOutlet UILabel *alertMessageText;
@property (strong, nonatomic) IBOutlet UILabel *noCarsAvailableLabel;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *nocarsAvailableTopSpaceToNavigationConstraint;



#pragma mark - exclusive toush enabled for all views

- (void) makeExclusiveTouchForViews:(NSArray*)views;

#pragma mark - mappin width and height constraints
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mapPinWidthConstraint;// actual 34
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mapPinHeightConstraint; //actual 48
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mapPinnToGoogleMapCenterXconstraint;//8

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *mapPinToGoogleMapCenterYconstraint;//-26


@end
