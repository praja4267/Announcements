//
//  addCardViewController.h
//  
//
//  Created by ActiveMac03 on 07/01/16.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"
#import "WebViewController.h"
#import "TPKeyboardAvoidingScrollView.h"

@protocol AddCardViewControllerDelegate<NSObject>
@optional
-(void)cardAddedFromWebViewWithMessage: (NSString *)message;
@end

@interface addCardViewController : UIViewController<UITextFieldDelegate,CustomIOSAlertViewDelegate, WebViewControllerDelegate>{
    CustomIOSAlertView *customAlertView;
}

@property NSString *strForCurrentPage;

@property(nonatomic, weak) id<AddCardViewControllerDelegate> addcardDelegate;
@property(nonatomic, weak) IBOutlet TPKeyboardAvoidingScrollView *tpScrlView;
@property (weak, nonatomic) IBOutlet UIButton *addCardBackBtn;
- (IBAction)addCardBackBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *addCardSaveBtn;
- (IBAction)addCardSaveBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *addCardNameTxt;
@property (strong, nonatomic) IBOutlet UITextField *addCardNumberTxt;

@property (weak, nonatomic) IBOutlet UIImageView *addCardImageIcon;
@property (weak, nonatomic) IBOutlet UITextField *addCardMonthTxt;
@property (strong, nonatomic) IBOutlet UITextField *addCardCVVTxt;

@property BOOL isFromOutStanding;

@end
