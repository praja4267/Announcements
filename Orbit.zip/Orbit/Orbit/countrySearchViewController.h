//
//  countrySearchViewController.h
//  
//
//  Created by ActiveMac03 on 29/12/15.
//
//

#import <UIKit/UIKit.h>

@interface countrySearchViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchDisplayDelegate,UITextFieldDelegate>
{
    
}
@property (strong, nonatomic) IBOutlet UIButton *MenuBtn;
- (IBAction)Menu:(id)sender;

@property (strong, nonatomic) IBOutlet UITableView *countryTableView;

@property NSString *screenStatus;
@end
