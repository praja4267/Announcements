//
//  loyalityViewController.h
//  
//
//  Created by ActiveMac03 on 24/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface loyalityViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

- (IBAction)menuBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *balanceLbl;
@property (weak, nonatomic) IBOutlet UITableView *loyalityTableView;

@property (weak, nonatomic) IBOutlet UIView *loyalityEmptyView;
@end
