//
//  FavouriteListVC.h
//  
//
//  Created by Active Mac06 on 24/11/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@protocol FavouriteListVCDelegate <NSObject>
- (void)selectedAddressDictionary : (NSDictionary*)addressDict sender: (id)sender;
@optional
-(void) deselectOriginButton;
-(void) deselectDestinationButton;
-(void) reloadTheDataOfNewLocationWithLattitude:(NSString*)lattitude andLongitude: (NSString*)longitude;

@end

@interface FavouriteListVC : UIViewController <UITableViewDataSource,UITableViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}
@property (nonatomic, weak) id<FavouriteListVCDelegate> favouritesDelegate;
@property NSString* addFavText;
@property NSString* addFavLat;
@property NSString* addFavLong;
@property BOOL isFav;
@property BOOL isDisplayAddFav;
@property (weak, nonatomic) IBOutlet UILabel *addFavLabel;
@property (weak, nonatomic) IBOutlet UIView *addFavView;
- (IBAction)addFavBackBtn:(id)sender;
@property (strong,nonatomic) NSString* strForCurrentPage;
@property (weak, nonatomic) IBOutlet UIView *favEmptyView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *imageTopSpaceConstraint;
@property (nonatomic, strong) NSString* searchingTextField;
@end
