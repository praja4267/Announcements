//
//  MenuWalletViewController.h
//  
//
//  Created by Active Mac06 on 08/12/15.
//
//

#import <UIKit/UIKit.h>

@interface MenuWalletViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *totalAmountLabel;

@property (strong, nonatomic) IBOutlet UIButton *changeAmountButton;

@property (strong, nonatomic) IBOutlet UIButton *addAmountToWalletButton;
@end
