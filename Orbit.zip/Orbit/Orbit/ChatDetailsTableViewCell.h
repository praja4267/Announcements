//
//  ChatDetailsTableViewCell.h
//  
//
//  Created by ActiveMac03 on 04/01/16.
//
//

#import <UIKit/UIKit.h>

@interface ChatDetailsTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *chatDataLabel;
@property (strong, nonatomic) IBOutlet UILabel *timeLabel;

@end
