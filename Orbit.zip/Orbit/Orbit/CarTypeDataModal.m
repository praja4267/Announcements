//
//  CarTypeDataModal.m
//  UberforXOwner
//
//  Created by Deep Gami on 14/11/14.
//  Copyright (c) 2014 Jigs. All rights reserved.
//

#import "CarTypeDataModal.h"

@implementation CarTypeDataModal
@synthesize catName,catTypeName,icon,id_,seating,baseFare,is_default,isSelected,price_per_unit_distance,price_per_unit_time,carType_count,basePrice,baseAfterPrice,baseKM,min_fare, map_icon, TimeKM, ios_cat_image;
@end
