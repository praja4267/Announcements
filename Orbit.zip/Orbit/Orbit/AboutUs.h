//
//  AboutUs.h
//  
//
//  Created by Active Mac06 on 16/12/15.
//
//

#import <UIKit/UIKit.h>
#import "CustomIOSAlertView.h"

@interface AboutUs : UIViewController <UITableViewDataSource,UITableViewDelegate,CustomIOSAlertViewDelegate>
{
    CustomIOSAlertView *customAlertView;
}

@end
