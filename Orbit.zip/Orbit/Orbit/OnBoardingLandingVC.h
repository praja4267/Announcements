//
//  OnBoardingLandingVC.h
//  
//
//  Created by Active Mac06 on 25/11/15.
//
//

#import <UIKit/UIKit.h>
#import "OnBoardSliderVC.h"
#import "CustomIOSAlertView.h"

@interface OnBoardingLandingVC : UIViewController<CustomIOSAlertViewDelegate>{
    CustomIOSAlertView *customAlertView;
}
@end
