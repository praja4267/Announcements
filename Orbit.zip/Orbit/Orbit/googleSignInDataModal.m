//
//  googleSignInDataModal.m
//  
//
//  Created by ActiveMac03 on 07/12/15.
//
//

#import "googleSignInDataModal.h"

@implementation googleSignInDataModal
@synthesize userEmail,userID,userName;
@end
