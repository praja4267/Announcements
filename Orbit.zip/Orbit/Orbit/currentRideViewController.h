//
//  currentRideViewController.h
//  
//
//  Created by ActiveMac03 on 05/01/16.
//
//

#import <UIKit/UIKit.h>
#import "TPFloatRatingView.h"
#import "CustomIOSAlertView.h"
#import <MapKit/MapKit.h>


@interface currentRideViewController : UIViewController<CustomIOSAlertViewDelegate,TPFloatRatingViewDelegate,CLLocationManagerDelegate > {
    CustomIOSAlertView *customAlertView;
}

@property NSString *requestID;

@property (weak, nonatomic) IBOutlet UIView *viewGoogleMap;

#pragma mark -Nav View page

@property (weak, nonatomic) IBOutlet UIView *currentNavigationView;
- (IBAction)currentBackBtn:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *backButton;

@property (weak, nonatomic) IBOutlet UITextField *currentSearchBar;
@property (weak, nonatomic) IBOutlet UILabel *lymoArrivingLbl;

#pragma mark - Destination View

@property (weak, nonatomic) IBOutlet UIView *currentDestinationView;
@property (weak, nonatomic) IBOutlet UITextField *currentDestinationSearchTxt;
@property (weak, nonatomic) IBOutlet UIView *destinationHolderView;


#pragma mark - StartRide View

@property (weak, nonatomic) IBOutlet UIView *currentStartRideView;
@property (weak, nonatomic) IBOutlet UIImageView *currentStartRideIcon;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideName;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideCarType;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideCarNumber;
@property (weak, nonatomic) IBOutlet TPFloatRatingView *currentStartRideRatingView;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideRating;
@property (strong, nonatomic) IBOutlet UIButton *currentLocationButton;


#pragma mark - StartRide Detail View

@property (weak, nonatomic) IBOutlet UIView *currentStartRideDetailBigView;
@property (weak, nonatomic) IBOutlet UIView *currentStartRideDetailView;
@property (weak, nonatomic) IBOutlet UIImageView *currentStartRideDetailIcon;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideDetailName;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideDetailCarType;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideDetailCarNumber;
@property (weak, nonatomic) IBOutlet TPFloatRatingView *currentStartRideDetailRatingView;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideDetailRating;
@property (weak, nonatomic) IBOutlet UIImageView *currentStartRideCancelIcon;
@property (weak, nonatomic) IBOutlet UILabel *currentStartRideCancelLbl;
@property (weak, nonatomic) IBOutlet UIView *currentStartRideDetailCallDriverView;
@property (weak, nonatomic) IBOutlet UIView *currentStartRideDetailCancelView;
@property (weak, nonatomic) IBOutlet UIView *currentStartRideDetailShareView;


#pragma mark - Driver call view

@property (weak, nonatomic) IBOutlet UIView *currentDriverCallBigView;
@property (weak, nonatomic) IBOutlet UILabel *currentDriverCallPhoneLbl;
- (IBAction)currentDriverCallBtn:(id)sender;
- (IBAction)currentDriverCallCancelBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *currentDriverCallView;

#pragma mark - Cancel Alert view

@property (weak, nonatomic) IBOutlet UIView *currentCancelAlertBigView;
@property (weak, nonatomic) IBOutlet UIView *currentCancelAlertView;
- (IBAction)currentCancelAlertYesBtn:(id)sender;
- (IBAction)currentCancelAlertNoBtn:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *currentCancelTableView;
@property (weak, nonatomic) IBOutlet UIButton *currentCancelAlertYesBtn;

@end
